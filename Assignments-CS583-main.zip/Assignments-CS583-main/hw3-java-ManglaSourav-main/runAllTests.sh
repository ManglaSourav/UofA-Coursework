#!/usr/bin/env bash

mvn test
