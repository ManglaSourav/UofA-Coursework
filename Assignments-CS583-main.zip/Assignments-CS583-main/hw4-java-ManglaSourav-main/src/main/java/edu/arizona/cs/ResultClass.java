package edu.arizona.cs;
import edu.arizona.cs.Document;

public class ResultClass {
    Document DocName;
    double docScore = 0;
}
