FIRSTNAME: Prathyusha
LASTNAME:  Butti
EMAILADDRESS: pbutti@email.arizona.edu
UNDERGRADUATE/MASTERS/PHD : M
TOOLS: Ghidra, gdb
TECHNIQUES : reverse engineering, gdb debugging, control flow graph analysis
TIME :  14 hours
DIFFICULTY : 8
CHALLENGES: It was difficult as I had to understand what was actually going on and how the obfuscated code works before even attempting to deobfuscate the code. As there was a lot of code to understand the core of the logic took a lot of time for me. 
COMMENTS: I enjoyed it. My first time deobfuscating the code was super interesting as well.


