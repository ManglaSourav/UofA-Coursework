#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include <math.h>

// Algorithm stats
int tableSize = std::pow(2, 21);
int totalWrites = 0;
int totalFaults = 0;
int totalAccesses = 0;

std::string delims{" ,"};
std::vector<std::string> fileContents;
int curInstruction = 0;

class PageEntry {
   public:
    // Constructor
    PageEntry() : frameNumber(-1), dirty(false), referenced(false), valid(false) {}

    // Member vars
    int frameNumber;
    bool dirty;
    bool referenced;
    bool valid;
};

int getPageNumber(std::string va) {
    char *end;
    return (strtol(va.c_str(), &end, 16) / std::pow(2, 13));
}

void OptimalReplace(PageEntry &entry, std::vector<PageEntry> &pt) {
    int instructionCount = 0;

    for (int i = curInstruction; i < fileContents.size(); i++) {
        instructionCount++;
        // Split the string apart using spaces and commas
        size_t beg;
        size_t pos = 0;
        std::vector<std::string> tokens;
        while ((beg = fileContents.at(i).find_first_not_of(delims, pos)) != std::string::npos) {
            pos = fileContents.at(i).find_first_of(delims, beg + 1);
            tokens.push_back(fileContents.at(i).substr(beg, pos - beg));
        }

        char *end;
        int va = strtol(tokens[1].c_str(), &end, 16);
        int pageNum = va / std::pow(2, 13);

        // Found a loaded page to evict
        if (pt.at(pageNum).valid) {
            pt.at(pageNum).referenced = false;
            pt.at(pageNum).valid = false;
            entry.frameNumber = pt.at(pageNum).frameNumber;
            pt.at(pageNum).frameNumber = -1;
            if (pt.at(pageNum).dirty) {
                totalWrites++;
                std::cout << "page fault - evict dirty" << std::endl;
            } else
                std::cout << "page fault - evict clean" << std::endl;

            entry.valid = true;
            entry.dirty = false;
            entry.referenced = false;

            return;
        }

        if (instructionCount > 1000) {
            entry.frameNumber = 0;
            if (entry.dirty) {
                totalWrites++;
                std::cout << "page fault - evict dirty" << std::endl;
            } else
                std::cout << "page fault - evict clean" << std::endl;

            entry.valid = true;
            entry.dirty = false;
            entry.referenced = false;

            return;
        }
    }
}

void pageFault(PageEntry &entry, std::vector<PageEntry> &pt, std::vector<int> &ft) {
    // Check if the page fault can be fixed with a fram load
    for (int i = 0; i < ft.size(); i++) {
        if (ft.at(i) == -1) {
            std::cout << "page fault - no evict" << std::endl;
            entry.valid = true;
            entry.frameNumber = i;
            ft.at(i) = i;
            break;
        }
    }

    // The frame table is full we need to evict a frame
    OptimalReplace(entry, pt);
}

bool executeOp(int pageNum, std::vector<PageEntry> &pt, std::vector<int> &ft) {
    if (pt.at(pageNum).valid) {
        std::cout << "hit" << std::endl;
        return false;
    } else
        pageFault(pt.at(pageNum), pt, ft);
    return true;
}

int main(int argc, char **argv) {
    // Control variables
    int numFrames{-1};
    std::string algType;
    std::ifstream traceFile;

    // Process arguments
    if (argc == 0)
        return -1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-n") == 0) {
            char *end;
            numFrames = strtol(argv[++i], &end, 10);
        } else if (strcmp(argv[i], "-a") == 0)
            algType = argv[++i];
        else
            traceFile.open(argv[i]);
    }

    // Construct the page table
    std::vector<PageEntry> pageTable(std::pow(2, 19));

    for (int i = 0; i < pageTable.size(); i++) {
        pageTable.at(i) = PageEntry();
    }

    // Construct the frame table
    std::vector<int> frameTable(numFrames, -1);

    // Read and process the trace file
    std::string line;
    while (getline(traceFile, line)) {
        if (line[0] == '=' || line[0] == '-')
            continue;
        fileContents.push_back(line);
    }

    for (std::string line : fileContents) {
        curInstruction++;

        // Split the string apart using spaces and commas
        size_t beg;
        size_t pos = 0;
        std::vector<std::string> tokens;
        while ((beg = line.find_first_not_of(delims, pos)) != std::string::npos) {
            pos = line.find_first_of(delims, beg + 1);
            tokens.push_back(line.substr(beg, pos - beg));
        }

        if (strcmp(tokens[0].c_str(), "I") == 0) {
            int pageNum = getPageNumber(tokens[1]);
            pageTable.at(pageNum).referenced = true;
            if (executeOp(pageNum, pageTable, frameTable))
                totalFaults++;
            totalAccesses++;
        } else if (strcmp(tokens[0].c_str(), "L") == 0) {
            int pageNum = getPageNumber(tokens[1]);
            pageTable.at(pageNum).referenced = true;
            if (executeOp(pageNum, pageTable, frameTable))
                totalFaults++;
            totalAccesses++;
        } else if (strcmp(tokens[0].c_str(), "S") == 0) {
            int pageNum = getPageNumber(tokens[1]);
            pageTable.at(pageNum).dirty = true;
            pageTable.at(pageNum).referenced = true;
            if (executeOp(pageNum, pageTable, frameTable))
                totalFaults++;
            totalAccesses++;
        } else if (strcmp(tokens[0].c_str(), "M") == 0) {
            int pageNum = getPageNumber(tokens[1]);
            pageTable.at(pageNum).dirty = true;
            pageTable.at(pageNum).referenced = true;
            if (executeOp(pageNum, pageTable, frameTable))
                totalFaults++;
            totalAccesses += 2;
        }
    }

    traceFile.close();

    // Print out the statistics
    std::cout << "Algorithm: " << algType << std::endl;
    std::cout << "Number of frames: " << numFrames << std::endl;
    std::cout << "Total memory accesses: " << totalAccesses << std::endl;
    std::cout << "Total page faults: " << totalFaults << std::endl;
    std::cout << "Total writes to disk: " << totalWrites << std::endl;
    std::cout << "Total size of page table: " << tableSize << " bytes" << std::endl;
    std::cout << std::endl;

    return 0;
}
