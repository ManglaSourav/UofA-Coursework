
"""
Author: Emilio Santa Cruz
Class: 452 @ Spring 2022
Professor: Dr. Misurda
Assignment: Project 4
Description: A simulation for page table entries and the handling of their
    page faults. Covers the OPT, clock, LRU, and NFU algorithms. After a
    selection of one via command line argument, it will simulate and as
    it is going, it will display onscreen the current action it is taking.
    After the simulation finishes, it will print a summary to screen
    displaying the statistics of running a simulation under that algorithm.
"""

import sys
from PTE import PTE
from Algorithms import *

"""
Gets, validates and returns the command line arguments. Exits if invalid.
Also gets, cleans and returns the lines from the chosen file.
Parameters: None
Pre-Conditions: Program is starting up
Post-Conditions: The simulation will begin
Return: the number of frames desired, chosen algorithm, and lines from file
"""
def getArgs():
    """
    if(len(sys.argv) != 6):
        print("FORMAT: vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>")
        exit(1)
    """
    numFrames = sys.argv[sys.argv.index("-n") + 1]
    mode = sys.argv[sys.argv.index("-a") + 1]
    fileName = sys.argv[sys.argv.index("-a") + 2]
    traceLines = []
    validStart = [" ", "I"]
    try:
        numFrames = int(numFrames)
        if(numFrames < 1):              # non-positive frames
            raise ValueError
        if(mode not in VALID_MODES):    # incorrect mode chosen
            raise
        traceFile = open(fileName, "r")
        for line in traceFile:
            if(line[0] not in validStart): # invalid line
                continue
            cleaned = line.strip()
            traceLines.append([cleaned[0], cleaned[1:].strip().split(",")[0]])
    except ValueError:
        print("numframes must be integer and positive")
        exit(1)
    except FileNotFoundError:
        print("File not found")
        exit(1)
    except Exception:
        print("mode must be opt, clock, lru or nfu")
        exit(1)

    return numFrames, mode, traceLines

"""
Sets up a dictionary to key PTE addresses to hold all future occurences of
    itself. Returns the dictionary when completed. Additionally fills out
    PTELookup with addresses to PTE objects.
Parameters: traceLines is the cleaned lines from the file, PTELookup is an
    external dictionary that will be filled by the function hold addresses to
    PTE objects
Pre-Conditions: OPT was the chosen algorithm
Post-Conditions: PTELookup is filled up with all unique addresses and PTETimes
    is filled with unique addresses to hold their occurences
Return: PTETimes is returned
"""
def futurePTE(traceLines, PTELookup):
    PTETimes = {}
    i = 0
    for line in traceLines:
        address = int(line[1], 16) // 8192
        if(address not in PTETimes):
            PTELookup[address] = PTE(address)
            PTELookup[address].valid = False
            PTETimes[address] = [i]
            
        else:
            PTETimes[address].append(i)
        i += 1
    
    return PTETimes

"""
The optimal algorithm that looks to the future to determine which page to
    evict. The farthest page or the first page with no future will be evicted.
Parameters: numFrames is the number of chosen frames for the simulation, 
    traceLines is the cleaned lines from the file, PTELookup is a dictionary
    containing the addresses to their respective PTE object
Pre-Conditions: The opt algorithm was chosen
Post-Conditions: A summary of the opt algoritm based on the given command line
    arguments will be returned with the number of accesses, faults and WTD.
Return: Returns accesses, faults and WTD that has been counted by the algorithm.
"""
def opt(numFrames, traceLines, PTELookup):
    opt = OPT(numFrames, futurePTE(traceLines, PTELookup))
    faults = 0
    accesses = 0
    inRAM = False
    for line in traceLines: # format: line[0] = I, L, S or M | line[1] = address
        action = line[0]
        address = int(line[1], 16) // 8192 # conversion
        currPTE = PTELookup[address]
        if(not PTELookup[address].valid): # not valid
            currPTE.valid = True
            currPTE.referenced = True
        else:                             # valid
            inRAM = True
            currPTE.referenced = True
            print("hit")
        if(action == "S"):
            currPTE.dirty = True
        elif(action == "M"):
            currPTE.dirty = True
            accesses += 1
        if(not inRAM):  # fault
            faults += 1
            opt.newPage(currPTE)
        else:           # hit
            opt.update(currPTE)
        accesses += 1
        inRAM = False
    
    return accesses, faults, opt.WTD
    
"""
The clock algorithm is the second chance algorithm with the difference being
    that a clock-like data structure is used.
Parameters: numFrames is the number of chosen frames for the simulation, 
    traceLines is the cleaned lines from the file, PTELookup is a dictionary
    containing the addresses to their respective PTE object
Pre-Conditions: Clock was chosen
Post-Conditions: A summary of the clock algoritm based on the given command line
    arguments will be returned with the number of accesses, faults and WTD.
Return: Returns accesses, faults and WTD that has been counted by the algorithm.
"""
def clock(numFrames, traceLines, PTELookup): # subtract referenced bit on second chance
    clock = Clock(numFrames)
    inRAM = False
    faults = 0
    currPTE = None
    accesses = 0
    i = 0
    for line in traceLines: # format: line[0] = I, L, S or M | line[1] = address
        action = line[0]
        address = int(line[1], 16) // 8192 # conversion
        if(address not in PTELookup):       # first time
            currPTE = PTE(address)
            PTELookup[address] = currPTE
        elif(not PTELookup[address].valid): # invalid
            currPTE = PTELookup[address]
            currPTE.valid = True
            currPTE.referenced = True
        else:                               # hit
            currPTE = PTELookup[address]
            inRAM = True
            currPTE.referenced = True
            print("hit")
        if(action == "S"):
            currPTE.dirty = True
        elif(action == "M"):
            currPTE.dirty = True
            accesses += 1
        if(not inRAM):
            faults += 1
            clock.newPage(currPTE)
        
        accesses += 1
        inRAM = False
    
    return accesses, faults, clock.WTD
    
            

"""
The LRU(least recently used) algorithm that evicts pages based on how recently
    used they were.
Parameters: numFrames is the number of chosen frames for the simulation, 
    traceLines is the cleaned lines from the file, PTELookup is a dictionary
    containing the addresses to their respective PTE object
Pre-Conditions: LRU was chosen
Post-Conditions: A summary of the LRU algoritm based on the given command line
    arguments will be returned with the number of accesses, faults and WTD.
Return: Returns accesses, faults and WTD that has been counted by the algorithm.
"""
def lru(numFrames, traceLines, PTELookup):
    lru = LRU(numFrames)
    inRAM = False
    faults = 0
    currPTE = 0
    accesses = 0
    for line in traceLines:
        action = line[0]
        address = int(line[1], 16) // 8192
        if(address not in PTELookup):
            currPTE = PTE(address)
            PTELookup[address] = currPTE
        elif(not PTELookup[address].valid):
            currPTE = PTELookup[address]
            currPTE.valid = True
        else:
            currPTE = PTELookup[address]
            inRAM = True
            print("hit")
        if(action == "S"):
            currPTE.dirty = True
        elif(action == "M"):
            currPTE.dirty = True
            accesses += 1
        if(not inRAM):
            faults += 1
            lru.newPage(currPTE)
        else:
            lru.update(currPTE)
        accesses += 1
        inRAM = False
    
    return accesses, faults, lru.WTD

"""
The NFU(Not Frequently Used) that evicts based on the least amount of uses
    since it becomes valid.
Parameters: numFrames is the number of chosen frames for the simulation, 
    traceLines is the cleaned lines from the file, PTELookup is a dictionary
    containing the addresses to their respective PTE object
Pre-Conditions: NFU was chosen
Post-Conditions: A summary of the NFU algoritm based on the given command line
    arguments will be returned with the number of accesses, faults and WTD.
Return: Returns accesses, faults and WTD that has been counted by the algorithm.
"""
def nfu(numFrames, traceLines, PTELookup):
    nfu = NFU(numFrames)
    inRAM = False
    faults = 0
    currPTE = None
    accesses = 0
    i = 0
    for line in traceLines: # format: line[0] = I, L, S or M | line[1] = address
        action = line[0]
        address = int(line[1], 16) // 8192
        if(address not in PTELookup):
            currPTE = PTE(address)
            PTELookup[address] = currPTE
        elif(not PTELookup[address].valid):
            currPTE = PTELookup[address]
            currPTE.valid = True
        else:
            currPTE = PTELookup[address]
            inRAM = True
            print("hit")
        if(action == "S"):
            currPTE.dirty = True
        elif(action == "M"):
            currPTE.dirty = True
            accesses += 1
        if(not inRAM):
            faults += 1
            nfu.newPage(currPTE)
        else:
            nfu.increment(currPTE)
        
        accesses += 1
        inRAM = False
    
    return accesses, faults, nfu.WTD

# global dictionary to emulate switch case to start simulation
VALID_MODES = {"opt":opt,
    "clock":clock,
    "lru":lru, 
    "nfu":nfu}

def main():
    numFrames, mode, traceLines = getArgs()
    
    PTELookup = {}
    accesses, pageFaults, writes = VALID_MODES[mode](numFrames, traceLines, PTELookup)

    print("Algorithm: %s" % mode)
    print("Number of frames:\t%d" % numFrames)
    print("Total memory accesses:\t%d" % accesses)
    print("Total page faults:\t%d" % pageFaults)
    print("Total writes to disk:\t%d" % writes)
    print("Total size of page table:\t%d" % (2 ** 32 / 8192 * 4) + " bytes")


main()