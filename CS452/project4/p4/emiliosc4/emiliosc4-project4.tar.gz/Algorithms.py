
"""
Author: Emilio Santa Cruz
Class: 452 @ Spring 2022
Professor: Dr. Misurda
Assignment: Project 4
Description: Contains the objects that will represent the methods that will
    run each algorithm. Contains the OPT, LRU, CLOCK and NFU algorithms.
"""

"""
Name: LRU
Description: Simulates the LRU algorithm by accepting PTE until full and 
    replacing the PTE that is first in the array, representative of the
    least used PTE. When a PTE is referenced, it will be move to the end
    of the array to represent it being the most recently used
Fields: frames is the array holding the valid PTEs
        WTD is counter for writing to disk
        frameNum is the max size of the frame
Constructor: Accepts a frameNum and assigns it to a self.frameNum and 
    initializes the other fields     
"""
class LRU:
    
    def __init__(self, frameNum):
        self.frames = []
        self.WTD = 0
        self.frameNum = frameNum
    
    """
    Updates the position of pte to most recent
    Parameters: pte is the PTE that was hit
    Pre-Conditions: A hit occurs
    Post-Conditions: pte is moved to the end of the array
    Return: None
    """
    def update(self, pte):
        for curr in self.frames:
            if(curr.address == pte.address):
                self.frames.remove(curr)
                self.frames.append(curr)
                break
    
    """
    Adds a page to the frame and evicts according to LRU is necessary
    Parameters: pte is the PTE to be added
    Pre-Conditions: pte is invalid and needs to be added
    Post-Conditions: pte is added to frames and potentially evicts another
    Return: None
    """
    def newPage(self, pte):
        if(len(self.frames) < self.frameNum):
            self.frames.append(pte)
            print("page fault - no eviction")
        else:
            if(self.frames[0].dirty):
                self.WTD += 1
                self.frames[0].dirty = False
                print("page fault - dirty eviction")
            else:
                print("page fault - clean eviction")
            self.frames[0].valid = False
            del self.frames[0]
            self.frames.append(pte)

"""
Name: NFU
Description: Simulates the NFU algorithm by accepting PTE until full and 
    replacing the PTE that has the least frequencies in the array, 
    representative of the least used PTE. When a PTE is referenced, 
    its frequency will be incremented
Fields: frequency is the dictionary holding the valid PTEs to their frequency
        WTD is counter for writing to disk
        frameNum is the max size of the frame
Constructor: Accepts a frameNum and assigns it to a self.frameNum and 
    initializes the other fields     
"""         
class NFU:
    def __init__(self, frameNum):
        self.frameNum = frameNum
        self.WTD = 0
        self.frequency = {}
    
    """
    Increments the frequency of a PTE that is valid
    Parameters: pte is the PTE that was hit
    Pre-Conditions: A hit occurs
    Post-Conditions: PTE's frequency is incremented
    Return: None
    """
    def increment(self, pte):
        self.frequency[pte] += 1
    
    """
    Adds a page to the frame and evicts according to NFU is necessary
    Parameters: pte is the PTE to be added
    Pre-Conditions: pte is invalid and needs to be added
    Post-Conditions: pte is added to frames and potentially evicts another
    Return: None
    """
    def newPage(self, pte):
        if(len(self.frequency) < self.frameNum):
            self.frequency[pte] = 1
            print("page fault - no eviction")
        else:
            min = -1
            minKey = None
            for key, val in self.frequency.items():
                if(min == -1):
                    min = val
                    minKey = key
                elif(val < min):
                    min = val
                    minKey = key
            if(minKey.dirty):
                minKey.dirty = False
                self.WTD += 1
                print("page fault - dirty eviction")
            else:
                print("page fault - clean eviction")
            minKey.valid = False
            del self.frequency[minKey]
            self.frequency[pte] = 1

"""
Name: Clock
Description: Simulates the clock algorithm by accepting PTE until full and 
    replacing the first PTE that is unreferenced. The unreferencing occurs
    while the current oldest is referenced, then unreferenced and the clocks'
    pointers are incremented
Fields: frames is the array holding the valid PTEs
        WTD is counter for writing to disk
        frameNum is the max size of the frame
        oldest is the current oldest in the clock
        newest is the current newest in the clock
        length is the current length of the clock
Constructor: Accepts a frameNum and assigns it to a self.frameNum and 
    initializes the other fields     
"""
class Clock:

    def __init__(self, frameNum):
        self.frames = []
        self.length = 0
        self.oldest = 0
        self.newest = 0
        self.WTD = 0
        for i in range(frameNum):
            self.frames.append(None)

    """
    Increments the clock hands' pointer
    Parameters: None
    Pre-Conditions: The algorithm removing a second chance or a new page has
        been added
    Post-Conditions: pte is moved to the end of the array
    Return: None
    """
    def increment(self):
        self.oldest = (self.oldest + 1) % len(self.frames)
        self.newest = (self.newest + 1) % len(self.frames)

    """
    Adds a page to the frame and evicts according to clock is necessary
    Parameters: pte is the PTE to be added
    Pre-Conditions: pte is invalid and needs to be added
    Post-Conditions: pte is added to frames and potentially evicts another
    Return: None
    """
    def newPage(self, pte):
        if(self.length == 0):
            self.frames[0] = pte
            self.length += 1
            print("page fault - no eviction")
        elif(self.length < len(self.frames)):
            self.newest += 1
            self.frames[self.newest] = pte
            self.length += 1
            print("page fault - no eviction")
        else:
            while(self.frames[self.oldest].referenced == True):
                self.frames[self.oldest].referenced = False
                self.increment()
            if(self.frames[self.oldest].dirty):
                self.WTD += 1
                print("page fault - dirty eviction")
            else:
                print("page fault - clean eviction")
            self.frames[self.oldest].valid = False
            self.frames[self.oldest].dirty = False
            self.frames[self.oldest] = pte
            self.increment()

"""
Name: OPT
Description: Simulates the OPT algorithm by accepting PTE until full and 
    replacing the PTE that is shows up farthest in the future or the first
    PTE that does not show up again.
Fields: frames is the dictionary holding the valid PTEs to its next occurence
        WTD is counter for writing to disk
        frameNum is the max size of the frame
        future is a dictionary holding addresses to their occurences
Constructor: Accepts a frameNum and assigns it to a self.frameNum and 
    initializes the other fields     
"""
class OPT:
    def __init__(self, frameNum, PTETimes):
        self.frames = {}
        self.WTD = 0
        self.frameSize = frameNum
        self.future = PTETimes
    
    """
    Updates the position of pte to most recent
    Parameters: pte is the PTE that was hit
    Pre-Conditions: A hit occurs
    Post-Conditions: pte's future pointer is incremented and self.frames
        associated value is replaced with the next future occurence
    Return: None
    """
    def update(self, pte):
        times = self.future[pte.address]
        pte.futureIndex += 1
        nextFuture = -1
        if(len(times) != pte.futureIndex):
            nextFuture = self.future[pte.address][pte.futureIndex]
        self.frames[pte] = nextFuture
    
    """
    Adds a page to the frame and evicts according to OPT is necessary
    Parameters: pte is the PTE to be added
    Pre-Conditions: pte is invalid and needs to be added
    Post-Conditions: pte is added to frames and potentially evicts another
    Return: None
    """
    def newPage(self, pte):
        pte.futureIndex += 1
        nextFuture = -1
        if(len(self.future[pte.address]) != pte.futureIndex):
            nextFuture = self.future[pte.address][pte.futureIndex]
        if(len(self.frames) < self.frameSize):
            self.frames[pte] = nextFuture
            print("page fault - no eviction")
        else:
            maxFound = []
            for currPTE, val in self.frames.items():
                if(val == -1): # not in the future
                    if(currPTE.dirty):
                        self.WTD += 1
                        currPTE.dirty = False
                    currPTE.valid = False
                    del self.frames[currPTE]
                    self.frames[pte] = nextFuture
                    return
                if(len(maxFound) == 0):
                    maxFound.append(currPTE)
                    maxFound.append(val)
                elif(maxFound[1] < val):
                    maxFound[0] = currPTE
                    maxFound[1] = val
            found = maxFound[0]
            found.valid = False
            if(found.dirty):
                self.WTD += 1
                found.dirty = False
                print("page fault - dirty eviction")
            else:
                print("page fault - clean eviction")
            del self.frames[found]
            self.frames[pte] = nextFuture
        
            