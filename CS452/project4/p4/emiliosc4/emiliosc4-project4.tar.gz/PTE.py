
"""
Author: Emilio Santa Cruz
Class: 452 @ Spring 2022
Professor: Dr. Misurda
Assignment: Project 4
Description: An object class that represents a Page Table Entry.
"""

"""
Fields: dirty means if the PTE is modified,
        referenced is used when it is used while in RAM,
        valid means if it is in RAM,
        address is address where it would be located,
        futureIndex is used in opt to serve as a pointer for future occurences
Constructor: accepts address for the address of each PTE
"""
class PTE:
    def __init__(self, address):
        self.dirty = False      # When written to (avoids lost modifications) write to disk when replaced
        self.referenced = True  # when used (read/written)
        self.valid = True       # in RAM
        self.address = address  # address assigned to
        self.futureIndex = 0    # used for opt to be a pointer for future occurences

    
