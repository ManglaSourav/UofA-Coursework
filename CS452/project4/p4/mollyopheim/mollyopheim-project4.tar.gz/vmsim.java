import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 *  Author: Molly Opheim
 *  Class: CSc 452
 *  Project: Project 4 Virtual Memory Simulator
 *  Description: vmsim.java simulates virtual memory with one of the four
 *  algorithms- opt, clock, lru, nfu
 *  page tables are 8kb and address space is 32 bits
 */

public class vmsim {
	public static void main(String[] args) throws IOException {

		// this program is run by typing the following into the command line
		// vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>
		if (args.length != 5) {
			System.out.println("please enter arguments in the form of vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
			return;
		}
		
		int numFrames = Integer.parseInt(args[1]);
		// array for what's currently in RAM
		PageTableEntry[] ramFrames = new PageTableEntry[numFrames];

		String algo = args[3];
		String fileName = args[4];

		// # of pages per address space is
		// 2^32/2^13 = 2^19
		PageTableEntry[] PageTableArray = new PageTableEntry[(int) Math.pow(2, 19)];
		// there are 4 bytes per page table entry and 2^19 entries in the page table
		long PageTableSize = ((int) Math.pow(2, 19)) * 4;

		BufferedReader reader = new BufferedReader(new FileReader(fileName));

		// determining which alogorithm method to go to
		if (algo.equals("opt")) {
			optAlgo(reader, PageTableArray, ramFrames, PageTableSize);
		} else if (algo.equals("clock")) {
			clockAlgo(reader, PageTableArray, ramFrames, PageTableSize);
		} else if (algo.equals("lru")) {
			lruAlgo(reader, PageTableArray, numFrames, PageTableSize);
		} else if (algo.equals("nfu")) {
			nfuAlgo(reader, PageTableArray, ramFrames, PageTableSize);
		} else {
			System.out.println("Please enter one of the following algorithms: OPT, Clock, LRU, NFU");
		}

		reader.close();


	}

	/**
	 * This method implement the optimal page replacement algorithm. This means we choose what is perfect, if we could
	 * see into the future. This is done by keeping a set of the pages from the future and choosing what to evict
	 * by using this knowledge
	 *
	 * @param reader - how we read in the lines from the file
	 * @param PageTableArray - keeps track of page table entries
	 * @param ramFrames - the page table entries in RAM
	 * @param PageTableSize - the size of the page table
	 * @throws IOException
	 */
	private static void optAlgo(BufferedReader reader, PageTableEntry[] PageTableArray, PageTableEntry[] ramFrames, long PageTableSize) throws IOException {

		for (int i = 0; i < PageTableArray.length; i++) {
			PageTableArray[i] = new PageTableEntry();
			PageTableArray[i].valid = false;
		}

		// for opt we store all the lines because we have to look ahead at future lines
		ArrayList<String> lines = new ArrayList<>();


		// vaddress is the virtual address
		long vaddress;
		// number of frames currently in RAM
		int curRamOccupancy = 0;
		// initializing page frame number
		int totalMemAccesses = 0;
		int totalPageFaults = 0;
		int totalWritesToDisk = 0;

		int oldest = 0;
		String currentLine;

		while ((currentLine = reader.readLine()) != null) {
			lines.add(currentLine);
		}

		for(int i = 0; i < lines.size(); i++) {
			// whether or not we should make an entry dirty based on I, S, M, or L
			boolean makeDirty = false;
			currentLine = lines.get(i);
			if (currentLine.charAt(0) == 'I' || currentLine.charAt(0) == ' ') {
				String[] lineInfo = currentLine.split("[ ,]");
				PageTableEntry curPage = null;
				for (int lineIndex = 0; lineIndex < lineInfo.length - 1; lineIndex++) {
					if (!(lineInfo[lineIndex].equals(""))) {

						if (lineInfo[lineIndex].equals("I")) {
							lineIndex++;
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						}
						if (lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M") || lineInfo[lineIndex].equals("L")) {
							if (lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M")) {
								makeDirty = true;
							}
							if (lineInfo[lineIndex].equals("M")) {
								totalMemAccesses += 1;
							}
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);

						}

						totalMemAccesses += 1;

						// page# = VA / PageSize
						// pages are 8 kb in size
						vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						long pageNum = vaddress / 8192;

						curPage = PageTableArray[(int) pageNum];
					}
				}

				// is in RAM
				if (curPage.valid) {
					if (makeDirty) {
						curPage.dirty = true;
					}
					curPage.reference = true;
					System.out.println("hit");
				} else {
					// not in RAM
					totalPageFaults++;
					curPage.dirty = makeDirty;

					// couldn't find the page but there's room in RAM
					if (curRamOccupancy < ramFrames.length) {
						curPage.valid = true;
						ramFrames[curRamOccupancy] = curPage;
						curPage.pageFrameNumber = curRamOccupancy;
						curRamOccupancy++;
						System.out.println("page fault - no eviction");
					} else {
						// no room in RAM
						// candidates for removal, they are no longer a candidate if we find it at a
						// future page
						HashSet<Integer> candidates = new HashSet<>();
						for(int candidateCount = 0; candidateCount < ramFrames.length; candidateCount++) {
							candidates.add(candidateCount);
						}
						int j = 0;
						while(candidates.size() > 1) {
							j++;
							if(!((i + j) >= lines.size()-1)) {
								String futureLine = lines.get(i + j);
								if(futureLine.charAt(0) == 'I' || futureLine.charAt(0) == ' ') {
									vaddress = Long.parseLong(futureLine.substring(3, 11), 16);
									long pageNum = vaddress / 8192;
									PageTableEntry futurePage = PageTableArray[(int) pageNum];
									if(futurePage.valid) {
										// this means we don't want to remove this page
										candidates.remove(futurePage.pageFrameNumber);
									} else {
										continue;
									}
								}
							} else {
								break;
							}
						}
						// there is only one candidate for removal left, so we remove it
						for(Integer evictPageNumber: candidates) {
							PageTableEntry evict = ramFrames[evictPageNumber];
							if (evict.dirty) {
								System.out.println("page fault - evict dirty");
								totalWritesToDisk++;
							} else {
								System.out.println("page fault - evict clean");
							}
							curPage.valid = true;
							curPage.pageFrameNumber = evict.pageFrameNumber;
							ramFrames[evictPageNumber] = curPage;
							// reset evict
							evict.dirty = false;
							evict.valid = false;
							evict.reference = false;
							evict.pageFrameNumber = -1;
							break;
						}
					}
				}
			}
		}
		System.out.println("Algorithm: OPT");
		System.out.println("Number of frames: " + ramFrames.length);
		System.out.println("Total memory accesses: " + totalMemAccesses);
		System.out.println("Total page faults: " + totalPageFaults);
		System.out.println("Total writes to disk: " + totalWritesToDisk);
		System.out.println("Total size of page table: " + PageTableSize);
	}

	/**
	 * This method implements the better version of the second change algorithm. We keep track of the oldest entry and
	 * use the reference bit to evict the oldest unreferenced entry
	 *
	 * @param reader - how we read in the lines from the file
	 * @param PageTableArray - keeps track of page table entries
	 * @param ramFrames - the page table entries in RAM
	 * @param PageTableSize - the size of the page table
	 * @throws IOException
	 */
	private static void clockAlgo(BufferedReader reader, PageTableEntry[] PageTableArray, PageTableEntry[] ramFrames, long PageTableSize) throws IOException {
		// first we need to initialize the page table array
		for (int i = 0; i < PageTableArray.length; i++) {
			PageTableArray[i] = new PageTableEntry();
			PageTableArray[i].valid = false;
		}

		// vaddress is the virtual address
		long vaddress;
		// number of frames currently in RAM
		int curRamOccupancy = 0;
		// initializing page frame number
		int totalMemAccesses = 0;
		int totalPageFaults = 0;
		int totalWritesToDisk = 0;

		int oldest = 0;
		String currentLine;

		while ((currentLine = reader.readLine()) != null) {

			// whether or not we need to make the page dirty based on I, S, M, or L
			boolean makeDirty = false;
			if (currentLine.charAt(0) == 'I' || currentLine.charAt(0) == ' ') {

				String[] lineInfo = currentLine.split("[ ,]");
				PageTableEntry curPage = null;
				for (int lineIndex = 0; lineIndex < lineInfo.length - 1; lineIndex++) {
					if (!(lineInfo[lineIndex].equals(""))) {

						if (lineInfo[lineIndex].equals("I")) {
							lineIndex++;
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						}
						if (lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M") || lineInfo[lineIndex].equals("L")) {
							if(lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M")) {
								makeDirty = true;
							}
							if(lineInfo[lineIndex].equals("M")) {
								totalMemAccesses += 1;
							}
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);

						}

						totalMemAccesses += 1;
						// page# = VA / PageSize
						// pages are 8 kb in size
						vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						long pageNum = vaddress / 8192;
						curPage = PageTableArray[(int) pageNum];
					}
				}

				// is in RAM
				if (curPage.valid) {
					if (makeDirty) {
						curPage.dirty = true;
					}
					curPage.reference = true;
					System.out.println("hit");
				} else {
					// not in RAM
					totalPageFaults++;
					curPage.dirty = makeDirty;
					curPage.valid = true;
					// the page we're looking for is not in RAM but ram is not full
					if (curRamOccupancy < ramFrames.length) {
						ramFrames[curRamOccupancy] = curPage;
						curPage.pageFrameNumber = curRamOccupancy;
						curRamOccupancy++;
						System.out.println("page fault - no eviction");
					} else {
						// we start pointing at the oldest and find the oldest unreferenced, resetting the reference
						while (ramFrames[oldest].reference) {
							ramFrames[oldest].reference = false;
							oldest++;
							if (oldest >= ramFrames.length) {
								oldest = 0;
							}
						}
						PageTableEntry evict = ramFrames[oldest];
						if (evict.dirty) {
							System.out.println("page fault - evict dirty");
							totalWritesToDisk++;
						} else {
							System.out.println("page fault - evict clean");
						}
						curPage.pageFrameNumber = evict.pageFrameNumber;
						ramFrames[oldest] = curPage;
						oldest++;
						if (oldest >= ramFrames.length) {
							oldest = 0;
						}
						// reset evict
						evict.dirty = false;
						evict.valid = false;
						evict.reference = false;
						evict.pageFrameNumber = -1;
					}
				}
			}
		}
		System.out.println("Algorithm: Clock");
		System.out.println("Number of frames: " + ramFrames.length);
		System.out.println("Total memory accesses: " + totalMemAccesses);
		System.out.println("Total page faults: " + totalPageFaults);
		System.out.println("Total writes to disk: " + totalWritesToDisk);
		System.out.println("Total size of page table: " + PageTableSize);
	}

	/**
	 * This method implements the lru algorithm which evicts the last recently used page
	 *
	 * @param reader - how we read in the lines from the file
	 * @param PageTableArray - keeps track of page table entries
	 * @param numFrames - the page table entries in RAM
	 * @param PageTableSize - the size of the page table
	 * @throws IOException
	 */
	private static void lruAlgo(BufferedReader reader, PageTableEntry[] PageTableArray, int numFrames, long PageTableSize) throws IOException {
		// first we need to initialize the page table array
		for (int i = 0; i < PageTableArray.length; i++) {
			PageTableArray[i] = new PageTableEntry();
			PageTableArray[i].valid = false;
		}

		// the frames of ram made up of page table entries
		ArrayList<PageTableEntry> ramFrames = new ArrayList<>();

		// vaddress is the virtual address
		long vaddress;

		int totalMemAccesses = 0;
		int totalPageFaults = 0;
		int totalWritesToDisk = 0;

		int oldest = -1;
		String currentLine;
		//String currentLine = reader.readLine();
		while ((currentLine = reader.readLine()) != null) {

			boolean makeDirty = false;
			if (currentLine.charAt(0) == 'I' || currentLine.charAt(0) == ' ') {

				String[] lineInfo = currentLine.split("[ ,]");
				PageTableEntry curPage = null;
				for (int lineIndex = 0; lineIndex < lineInfo.length - 1; lineIndex++) {
					if (!(lineInfo[lineIndex].equals(""))) {

						if (lineInfo[lineIndex].equals("I")) {
							lineIndex++;
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						}
						if (lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M") || lineInfo[lineIndex].equals("L")) {
							if(lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M")) {
								makeDirty = true;
							}
							if(lineInfo[lineIndex].equals("M")) {
								totalMemAccesses += 1;
							}
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						}

						totalMemAccesses += 1;

						// page# = VA / PageSize
						// pages are 8 kb in size
						vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						long pageNum = vaddress / 8192;
						curPage = PageTableArray[(int) pageNum];
					}
				}

				// is in RAM
				if (curPage.valid) {
					if (makeDirty) {
						curPage.dirty = true;
					}
					System.out.println("hit");
					ramFrames.remove(curPage);
					ramFrames.add(0, curPage);
				} else {
					// not in RAM
					totalPageFaults++;
					curPage.dirty = makeDirty;
					curPage.valid = true;
					// there's room in ram to add the page
					if (ramFrames.size() < numFrames) {
						curPage.pageFrameNumber = ramFrames.size();
						ramFrames.add(0, curPage);
						System.out.println("page fault - no eviction");
					// no room in ram to add the page
					} else {
						// last recently used in the last added to the ramFrames
						PageTableEntry evict = ramFrames.remove(ramFrames.size() - 1);
						if (evict.dirty) {
							System.out.println("page fault - evict dirty");
							totalWritesToDisk++;
						} else {
							System.out.println("page fault - evict clean");
						}
						curPage.pageFrameNumber = evict.pageFrameNumber;
						ramFrames.add(0, curPage);

						// reset evict
						evict.dirty = false;
						evict.valid = false;
						evict.reference = false;
						evict.pageFrameNumber = -1;
					}
				}
			}
		}
		System.out.println("Algorithm: LRU");
		System.out.println("Number of frames: " + numFrames);
		System.out.println("Total memory accesses: " + totalMemAccesses);
		System.out.println("Total page faults: " + totalPageFaults);
		System.out.println("Total writes to disk: " + totalWritesToDisk);
		System.out.println("Total size of page table: " + PageTableSize);
	}

	/**
	 * This method implements the nfu algorithm which evicts the page which has the lowest referenced count since loaded
	 *
	 * @param reader - how we read in the lines from the file
	 * @param PageTableArray - keeps track of page table entries
	 * @param ramFrames - the page table entries in RAM
	 * @param PageTableSize - the size of the page table
	 * @throws IOException
	 */
	private static void nfuAlgo(BufferedReader reader, PageTableEntry[] PageTableArray, PageTableEntry[] ramFrames, long PageTableSize) throws IOException {
// first we need to initialize the page table array
		for (int i = 0; i < PageTableArray.length; i++) {
			PageTableArray[i] = new PageTableEntry();
			PageTableArray[i].valid = false;
		}

		// map page frame number to reference count
		HashMap<Integer, Integer> ref_count = new HashMap<>();

		// vaddress is the virtual address
		long vaddress;
		// number of frames currently in RAM
		int curRamOccupancy = 0;
		// initializing page frame number
		int pageFrameNumber = 0;
		int totalMemAccesses = 0;
		int totalPageFaults = 0;
		int totalWritesToDisk = 0;

		int oldest = -1;
		String currentLine;
		while ((currentLine = reader.readLine()) != null) {
			boolean makeDirty = false;
			if (currentLine.charAt(0) == 'I' || currentLine.charAt(0) == ' ') {

				String[] lineInfo = currentLine.split("[ ,]");
				PageTableEntry curPage = null;
				for (int lineIndex = 0; lineIndex < lineInfo.length - 1; lineIndex++) {
					if (!(lineInfo[lineIndex].equals(""))) {

						if (lineInfo[lineIndex].equals("I")) {
							lineIndex++;
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						}
						if (lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M") || lineInfo[lineIndex].equals("L")) {
							if(lineInfo[lineIndex].equals("S") || lineInfo[lineIndex].equals("M")) {
								makeDirty = true;
							}
							if(lineInfo[lineIndex].equals("M")) {
								totalMemAccesses += 1;
							}
							lineIndex++;
							vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						}

						totalMemAccesses += 1;

						// page# = VA / PageSize
						// pages are 8 kb in size
						vaddress = Long.parseLong(lineInfo[lineIndex], 16);
						long pageNum = vaddress / 8192;
						curPage = PageTableArray[(int) pageNum];
					}
				}

				// is in RAM
				if (curPage.valid) {
					if (makeDirty) {
						curPage.dirty = true;
					}
					curPage.reference = true;
					ref_count.put(curPage.pageFrameNumber, ref_count.get(curPage.pageFrameNumber) + 1);
					System.out.println("hit");
				} else {
					// not in RAM
					totalPageFaults++;
					curPage.dirty = makeDirty;
					curPage.valid = true;
					// there's room in ram to add the page
					if (curRamOccupancy < ramFrames.length) {
						ramFrames[curRamOccupancy] = curPage;
						curPage.pageFrameNumber = curRamOccupancy;
						ref_count.put(curRamOccupancy, 0);
						curRamOccupancy++;
						System.out.println("page fault - no eviction");
					} else {
						int smallest_idx = 0;
						int smallest_ref = ref_count.get(0);
						for (int i = 1; i < ramFrames.length; i++) {
							if (ref_count.get(i) < smallest_ref) {
								smallest_ref = ref_count.get(i);
								smallest_idx = i;
							}
						}

						// ram frame with smallest index is to be evicted
						PageTableEntry evict = ramFrames[smallest_idx];
						ref_count.put(smallest_idx, 0);

						if (evict.dirty) {
							System.out.println("page fault - evict dirty");
							totalWritesToDisk++;
						} else {
							System.out.println("page fault - evict clean");
						}
						curPage.pageFrameNumber = evict.pageFrameNumber;
						ramFrames[smallest_idx] = curPage;
						// Reset evict
						evict.dirty = false;
						evict.valid = false;
						evict.reference = false;
						evict.pageFrameNumber = -1;
					}
				}
			}
		}
		System.out.println("Algorithm: NFU");
		System.out.println("Number of frames: " + ramFrames.length);
		System.out.println("Total memory accesses: " + totalMemAccesses);
		System.out.println("Total page faults: " + totalPageFaults);
		System.out.println("Total writes to disk: " + totalWritesToDisk);
		System.out.println("Total size of page table: " + PageTableSize);
	}
}

/*
The page table entry class represents a page table entry
a page table entry consists of protection, a dirty bit, reference bit, valid bit, and
page frame number
 */
class PageTableEntry {
	// protection
	// dirty bit
	boolean dirty;

	// reference bit
	boolean reference;

	// valid bit - whether or not in RAM
	boolean valid;

	// page frame number - the location the page table entry is at in RAM
	int pageFrameNumber;

	// constructor for when we make a new page table entry
	public PageTableEntry() {
		dirty = false;
		reference = false;
		valid = false;
		pageFrameNumber = -1;
	}

}
