'''
CSC 452 Project 4: Virtual Memory Simulator
Danny Ryngler
April 7, 2022
'''
import os
import argparse
from collections import OrderedDict

class Page:
    '''
    Class to represent a page in the page tbale
    '''
    def __init__(self):
        self.dirty = False
        self.referenced = False
        self.valid = False

class RAM:
    '''
    Class to represent RAM
    isFree(): check if space for frame in ram
    getFrame(): return fram at idx
    setFrame(): set frame at idx
    '''
    def __init__(self, numFrames):
        self.frames = [None] * numFrames
        self.numFrames = numFrames
        self.open = 0
    
    def isFree(self):
        return self.open < self.numFrames
    
    def getFrame(self, idx):
        return self.frames[idx]
    
    def setFrame(self, pageNum, idx = None):
        if idx == None:
            idx = self.open
        self.frames[idx] = pageNum
        self.open += 1

class LRUCache:
    '''
    LRU cache for lru algorithm
    get(): get item in cache
    space(): check if cache is full or not
    pop(): return LRU item in cache
    put(): put a new item into cache
    '''
    def __init__(self, capacity):
        self.cache = OrderedDict()
        self.capacity = capacity

    def get(self, key):
        if key not in self.cache:
            return -1
        else:
            self.cache.move_to_end(key)
            return self.cache[key]
    
    def space(self):
        if len(self.cache) > self.capacity:
            return False
        return True
    
    def pop(self):
        return self.cache.popitem(last = False)
        return key, self.cache[key]

    def put(self, key, value):
        self.cache[key] = value
        self.cache.move_to_end(key)
        if len(self.cache) > self.capacity:
            self.cache.popitem(last = False)


PAGESIZE = (2**10*8) # 8 KB

def main(args):

    numberOfPages = int((2**32)/PAGESIZE)
    numbefOfFrames = args.n
    algo = args.a

    pageTable = [None] * numberOfPages
    ram = RAM(int(numbefOfFrames))

    traceFile = args.f
    if not os.path.isfile(traceFile):
        print('File not found.')
        return

    instructions = readFile(traceFile)
    if algo == "opt":
        memAccess, pageFaults, writes = opt(instructions, pageTable, ram)
    elif algo == "clock":
        memAccess, pageFaults, writes = clock(instructions, pageTable, ram)
    elif algo == "lru":
        memAccess, pageFaults, writes = lru(instructions, pageTable, ram)
    elif algo == "nfu":
        memAccess, pageFaults, writes = nfu(instructions, pageTable, ram)
    else:
        print(f"{algo} is not a valid algorithm")
        return

    print(f"Algorithm: {algo}")
    print(f"Number of frames: {numbefOfFrames}")
    print(f"Total memory accesses: {memAccess}")
    print(f"Total page faults: {pageFaults}")
    print(f"Total writes to disk: {writes}")
    filled = sum([1 for e in pageTable if e is not None])
    print(f"Total size of page table: {filled * (32 / 8)} bytes")

def readFile(traceFile):
    '''
    Parse "I" (instruction) and "L” (load), "S” (store) or "M” (modify)
    from a tracefile

    traceFile: File to parse
    Returns an array of tuples of (Instruction type, Memory Address)
    '''
    res = []
    tFile = open(traceFile)
    for line in tFile:
        if line[0] == ' ':
            comma = line.index(',')
            res.append((line[1], int(line[2:comma].strip(), 16)))
        elif line[0] == 'I':
            comma = line.index(',')
            res.append((line[0], int(line[1:comma].strip(), 16)))
    return res

def opt(instructions, pageTable, ram):
    '''
    Simulate  what  the  optimal  page  replacement  algorithm  would  choose  if  it  had  perfect 
    knowledge of the future.

    instructions: list of instructions from trace file
    pageTable: pageTable to hold pages
    ram: RAM with set number of frames
    '''
    memAccess, pageFaults, writes = len(instructions), 0, 0

    # build hashtable with times a virtual address is used
    memTime = {}
    for timeStep, instruction in enumerate(instructions):
        itype, va = instruction
        pageNum = va // PAGESIZE
        if pageNum in memTime:
            memTime[pageNum].append(timeStep)
        else:
            memTime[pageNum] = [timeStep]
    
    for timeStep, instruction in enumerate(instructions):
        itype, va = instruction
        pageNum = va // PAGESIZE
        offSet = va % PAGESIZE

        entry = pageTable[pageNum]
        if entry is None:
            entry = Page()
            pageTable[pageNum] = entry
        
        # page fault -> need to put into ram
        if entry.valid:
            print("hit")
        else:
            pageFaults += 1

            if ram.isFree():
                print("page fault – no eviction")
                ram.setFrame(pageNum)
            else:
                toRemove = 0
                fTime = 0
                for fIdx in range(ram.numFrames):
                    pg = ram.getFrame(fIdx)
                    pgTime = memTime[pg]
                    nTime = 0
                    for idx, uTime in enumerate(pgTime):
                        if uTime > timeStep:
                            nTime = uTime
                            break
                        if idx == len(pgTime) -1 and timeStep > uTime:
                            nTime = float('inf')
                    if nTime > fTime:
                        toRemove = fIdx
                        fTime = nTime         

                removePageNum = ram.getFrame(toRemove)
                removePage = pageTable[removePageNum]
                if removePage.dirty:
                    print("page fault – evict dirty")
                    writes += 1
                else:
                    print("page fault – evict clean")

                removePage.valid = False
                removePage.dirty = False

                # insert new Page into ram (pageNum)
                ram.setFrame(pageNum, toRemove)
          
        entry.valid = True
        if itype == 'M' or itype == 'S':
            entry.dirty = True 

    return memAccess, pageFaults, writes


def clock(instructions, pageTable, ram):
    '''
    Use the better implementation of the second-chance algorithm

    instructions: list of instructions from trace file
    pageTable: pageTable to hold pages
    ram: RAM with set number of frames
    '''
    memAccess, pageFaults, writes, clock = len(instructions), 0, 0, 0

    for timeStep, instruction in enumerate(instructions):
        itype, va = instruction
        pageNum = va // PAGESIZE
        offSet = va % PAGESIZE

        entry = pageTable[pageNum]
        if entry is None:
            entry = Page()
            pageTable[pageNum] = entry
        
        # page fault -> need to put into ram
        if entry.valid:
            entry.referenced = True
            print("hit")
        else:
            pageFaults += 1

            if ram.isFree():
               print("page fault – no eviction")
               ram.setFrame(pageNum)
            else:
                toKick = None
                while (True):
                    clock %= ram.numFrames

                    pn = ram.getFrame(clock)
                    if not pageTable[pn].referenced:
                        toKick = pageTable[pn]
                        break
                    
                    pageTable[pn].referenced = False
                    clock += 1
                if toKick.dirty:
                    print("page fault – evict dirty")
                    writes += 1
                else:
                    print("page fault – evict clean")

                toKick.valid = False
                toKick.dirty = False
                toKick.referenced = False

                ram.setFrame(pageNum, clock)
        entry.valid = True
        entry.referenced = True
        if itype == 'M' or itype == 'S':
            entry.dirty = True 

    return memAccess, pageFaults, writes

def lru(instructions, pageTable, ram):
    '''
    Evict the least recently used page 

    instructions: list of instructions from trace file
    pageTable: pageTable to hold pages
    ram: RAM with set number of frames
    '''
    memAccess, pageFaults, writes = len(instructions), 0, 0

    cache = LRUCache(ram.numFrames)

    for timeStep, instruction in enumerate(instructions):
        itype, va = instruction
        pageNum = va // PAGESIZE
        offSet = va % PAGESIZE

        entry = pageTable[pageNum]
        if entry is None:
            entry = Page()
            pageTable[pageNum] = entry
        
        # page fault -> need to put into ram
        if entry.valid:
            entry.referenced = True
            print("hit")
        else:
            pageFaults += 1

            if ram.isFree():
               print("page fault – no eviction")
               ram.setFrame(pageNum)
               cache.put(pageNum, ram.open - 1)
            else:
                pn, fIdx = cache.pop()
                toKick = ram.getFrame(fIdx)
                toKick = pageTable[toKick]
                if toKick.dirty:
                    print("page fault – evict dirty")
                    writes += 1
                else:
                    print("page fault – evict clean")

                toKick.valid = False
                toKick.dirty = False
                toKick.referenced = False
                ram.setFrame(pageNum, fIdx)
                cache.put(pageNum, fIdx)

        entry.valid = True
        entry.referenced = True
        if itype == 'M' or itype == 'S':
            entry.dirty = True 

    return memAccess, pageFaults, writes

def nfu(instructions, pageTable, ram):
    '''
    Evict the page whose referenced count (frequency of use) since loaded is the lowest

    instructions: list of instructions from trace file
    pageTable: pageTable to hold pages
    ram: RAM with set number of frames 
    '''
    memAccess, pageFaults, writes = len(instructions), 0, 0

    referenceCount = {}

    for timeStep, instruction in enumerate(instructions):
        itype, va = instruction
        pageNum = va // PAGESIZE
        offSet = va % PAGESIZE

        entry = pageTable[pageNum]
        if entry is None:
            entry = Page()
            pageTable[pageNum] = entry
        
        if pageNum in referenceCount:
            if entry.referenced:
                referenceCount[pageNum] += 1
        else:
            if entry.referenced:
                referenceCount[pageNum] = referenceCount.get(pageNum, 0) + 1
            else:
                referenceCount[pageNum] = 0

        # page fault -> need to put into ram
        if entry.valid:
            entry.referenced = True
            print("hit")
        else:
            pageFaults += 1

            if ram.isFree():
               print("page fault – no eviction")
               ram.setFrame(pageNum)
            else:
                minFreqIdx = 0
                minFreq = float('inf')
                for i in range(ram.numFrames):
                    pn = ram.getFrame(i)
                    if referenceCount[pn] < minFreq:
                        minFreqIdx = i
                        minFreq = referenceCount[pn]

                toKick = ram.getFrame(minFreqIdx)
                toKick = pageTable[toKick]
                if toKick.dirty:
                    print("page fault – evict dirty")
                    writes += 1
                else:
                    print("page fault – evict clean")
                    
                toKick.valid = False
                toKick.dirty = False
                toKick.referenced = False
                ram.setFrame(pageNum, minFreqIdx)

        entry.valid = True
        entry.referenced = True
        if itype == 'M' or itype == 'S':
            entry.dirty = True 
            
    return memAccess, pageFaults, writes

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='VM Simulator')
    parser.add_argument('-n', help='frame count')
    parser.add_argument('-a', help='algorithm: opt/clock/fifo/rand')
    parser.add_argument('f', help='tracefile')
    args = parser.parse_args()
    main(args)