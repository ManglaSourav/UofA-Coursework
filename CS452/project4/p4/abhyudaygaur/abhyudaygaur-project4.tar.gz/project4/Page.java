// class for page table entry
public class Page {     
    boolean valid;
    boolean dirty;
    boolean reference;
    int index = 0;
    int frame = 0;
    int age = 0;

    public Page() {
        this.valid = false
        this.dirty = false;
        this.reference = false;
        this.index = 0;
        this.frame = 0;
        this.age = 0;
    }
    // copy constructor
    public Page(Page data) {
        this.valid = data.valid;
        this.dirty = data.dirty;
        this.reference = data.reference;
        this.index = data.index;
        this.frame = data.frame;
        this.age = data.age;
    }
}