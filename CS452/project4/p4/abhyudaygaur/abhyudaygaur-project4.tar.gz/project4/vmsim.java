/* Author: Flynn Gaur
 * Class: CSC 452, Spring 22
 * Instructor: Dr. Misurda
 * Project 4: Virtual Memory Simulator: compares the results of four different algorithms
 *            on traces of memory references. Collects statistics about its performance
 *            such as the number of page faults that occur and the number of dirty frames
 *            that had to be written back to disk.
 *            cmd: vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>
 *
*/

import java.io.*;
import java.util.*;

public class vmsim {
    public int writes = 0;
    public ArrayList<String> pageTable;
    public int pageTableSize = 0;
    public BufferedReader buff = null;
    public int memAccess = 0;
    public ArrayList<String> opt;  
    public ArrayList<String> hex;
    public int[] frameArr;
    public String traceFile = "";

    public static void main(String[] args) throws IOException {

        String algInput = "";
        int numframes = 0;
        // read through user input command
        for(int i=0; i<args.length; i++) {
            if(args[i].equals("-n")) 
                numFrames = Integer.parseInt(args[i+1]);
            else if (args[i].equals("-a"))
                algInput = args[i+1];
            else if (i==args.length-1)
                traceFile = args[i];
        }

        pageTable = new ArrayList<>();
        //2^12 = max pages
        int maxPages = (int)Math.pow(2,12);          
        for(int i=0; i<maxPages; i++) {
            Page data = new Page();
            pageTable.add(i, data);
        }
        String [] readLine = null;
        hex = new ArrayList<>();
        opt = new ArrayList<>();
        buff = new BufferedReader(new FileReader(traceFile));
        while(buff.ready()) {
            readLine = buff.readLine().split(" ");
            hex.add(readLine[0]);
            opt.add(readLine[1]);
            memAccess++;
        }
        frameArray = new int[numFrames];
        for(int i=0;i<numFrames;i++) {
            frameArray[i] = -1;
        }

        // algo pick
        if(algInput.equals("opt")){
            opt(numFrames);
        }
        else if (algInput.equals("clock")){
            clock(numFrames);
        }
        else if(algInput.equals("LRU")){
            lru(numFrames);
        }
        else if(algInput.equals("NFU")){
            nfu(numFrames);
        }

        System.out.println("Algorithm: " + algInput);
        System.out.println("Number of frames: \t" + numFrames);
        System.out.println("Total memory accesses: \t" + memAccess);
        System.out.println("Total page faults: \t" + pageFaults);
        System.out.println("Total writes to disk: \t" + writes);
        System.out.println("Total size of page table: \t" + pageTableSize);
    }

    public static void opt(int numFrames) {
        for(int i=0; i<hex.size(); i++) {
            // hex to dec
            int pageNum = Integer.decode("0x" + hex.get(i).substring(0,5));
            int currFrame = 0;
            Page data = pageTable.get(pageNum);
            data.age = memAccess;
            data.index = pageNum;
            data.reference = true;
            if (opt.get(i).equals("W"))
                // mark dirty
                data.dirty = true;
            if (!data.valid) {
                pageFaults++;
                if (currFrame < numFrames) {
                    frameArr[currFrame] = pageNum;
                    data.frame = currFrame;
                    currFrame++;
                    data.valid = true;
                }
                else {
                    int evictFrame = 0;
                    int last = 0;
                    for (int j=0; j<frameArr.length; j++){
                        if (frameArr[j]==-1){
                            evictFrame = frameArr[j];
                            break;
                        }
                        else{
                            if(last < pageTable.get(frameArr[j]).age) {
                                last = pageTable.get(frameArr[j]).age;
                                evictFrame = frameArr[j];
                            }
                        }
                    }
                    Page evictPage = pageTable.get(evictFrame);
                    if(evictPage.dirty)
                        writes++;
                    frameArr[evictPage.frame] = data.index;
                    data.frame = evictPage.frame;
                    data.valid = true;
                    evictPage.dirty = false;
                    evictPage.reference = false;
                    evictPage.valid = false;
                    evictPage.frame = -1;
                    pageTable.set(evictFrame, evictPage);
                    pageTableSize++;
                }
            }
            pageTable.set(pageNum, data);
            memAccess++;
        }
    }

    public static void clock(int numFrames) {
        int clockFlag = 0;
        for (int i=0; i<hex.size(); i++) {
            // hex to dec
            int pageNum = Integer.decode("0x" + hex.get(i).substring(0,5));
            Page data = pageTable.get(pageNum);
            data.index = pageNum;
            data.reference = false;
            int currFrame = 0;
            if (opt.get(i).equals("W"))
                data.dirty = true;
            if (!data.valid) {
                pageFaults++;
                if (currFrame < numFrames) {
                    frameArr[currFrame] = pageNum;
                    data.frame = currFrame;
                    data.valid = true;
                    currFrame++;
                }
                else {
                    int evictFrame = 0;
                    boolean check = true;
                    while (check) {
                        if (!pageTable.get(frameArr[clockFlag].reference)) {
                            check = false;
                            evictFrame = frameArr[clockFlag];
                        }
                        else {
                            pageTable.get(frameArr[clockFlag]).ref = false;
                        }
                        clockFlag++;
                    }
                    Page ePage = pageTable.get(evictFrame);
                    if (ePage.dirty) 
                        writes++;
                    frameArr[ePage.frame] = data.index;
                    data.frame = ePage.frame;
                    data.valid = true;
                    ePage.dirty = false;
                    ePage.reference = false;
                    ePage.valid = false;
                    pageTable.set(evictFrame, ePage);
                    pageTableSize++;
                }
            }
            pageTable.set(pageNum, data);
            memAccess++;
        }
    }

    public static void lru(int numFrames) {
    int clockFlag = 0;
    for (int i=0; i<hex.size(); i++) {
        // hex to dec
        int pageNum = Integer.decode("0x" + hex.get(i).substring(0,5));
        Page data = pageTable.get(pageNum);
        data.index = pageNum;
        data.reference = false;
        int currFrame = 0;
        if (opt.get(i).equals("W"))
            data.dirty = true;
        if (!data.valid) {
            pageFaults++;
            if (currFrame < numFrames) {
                frameArr[currFrame] = pageNum;
                data.frame = currFrame;
                data.valid = true;
                currFrame++;
            }
            else {
                int evictFrame = 0;
                boolean check = true;
                while (check) {
                    if (!pageTable.get(frameArr[clockFlag].reference)) {
                        check = false;
                        evictFrame = frameArr[clockFlag];
                    }
                    else {
                        pageTable.get(frameArr[clockFlag]).ref = false;
                    }
                    clockFlag++;
                }
                Page ePage = pageTable.get(evictFrame);
                if (ePage.dirty) 
                    writes++;
                frameArr[ePage.frame] = data.index;
                data.frame = ePage.frame;
                data.valid = true;
                ePage.dirty = false;
                ePage.reference = false;
                ePage.valid = false;
                pageTable.set(evictFrame, ePage);
                pageTableSize++;
            }
        }
        pageTable.set(pageNum, data);
        memAccess++;
        }
    }

    public static void nfu(int numFrames) {
    //    int clockFlag = 0;
    //     for (int i=0; i<hex.size(); i++) {
    //         // hex to dec
    //         int pageNum = Integer.decode("0x" + hex.get(i).substring(0,5));
    //         Page data = pageTable.get(pageNum);
    //         data.index = pageNum;
    //         data.reference = false;
    //         int currFrame = 0;
    //         if (opt.get(i).equals("W"))
    //             data.dirty = true;
    //         if (!data.valid) {
    //             pageFaults++;
    //             if (currFrame < numFrames) {
    //                 frameArr[currFrame] = pageNum;
    //                 data.frame = currFrame;
    //                 data.valid = true;
    //                 currFrame++;
    //             }
    //             else {
    //                 int evictFrame = 0;
    //                 boolean check = true;
    //                 while (check) {
    //                     if (!pageTable.get(frameArr[clockFlag].reference)) {
    //                         check = false;
    //                         evictFrame = frameArr[clockFlag];
    //                     }
    //                     else {
    //                         pageTable.get(frameArr[clockFlag]).ref = false;
    //                     }
    //                     clockFlag++;
    //                 }
    //                 Page ePage = pageTable.get(evictFrame);
    //                 if (ePage.dirty) 
    //                     writes++;
    //                 frameArr[ePage.frame] = data.index;
    //                 data.frame = ePage.frame;
    //                 data.valid = true;
    //                 ePage.dirty = false;
    //                 ePage.reference = false;
    //                 ePage.valid = false;
    //                 pageTable.set(evictFrame, ePage);
    //                 pageTableSize++;
    //             }
    //         }
    //         pageTable.set(pageNum, data);
    //         memAccess++;
    //     }
    // } 
}
