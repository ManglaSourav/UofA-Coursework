public class PageTable {

	TableEntry[] tableEntries;

	public PageTable() {
		int tableSize = 2 << (32 - 13 - 1); //2 ^ 32 / 8KB
		this.tableEntries = new TableEntry[tableSize];
	}

	public TableEntry[] getTableEntries() {
		return tableEntries;
	}

	public static class TableEntry {
		boolean dirty = false;
		boolean valid = false;
		int referenced = 0;
	}
}
