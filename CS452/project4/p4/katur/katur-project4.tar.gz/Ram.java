public class Ram {

	int[] frames;
	int size;
	int index;

	public Ram(int size) {
		frames = new int[size];
		for(int i = 0; i < size; i++)
			frames[i] = -1;
		this.size = size;
		index = 0;
	}

	public int[] getFrames() {
		return frames;
	}
}
