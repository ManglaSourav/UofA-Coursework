/**
 * @author Carter Boyd
 * @detail This program is designed to simulate the virtual memory using 4 different algorithms to show the amount of
 * page faults, writes to disk, and accesses to memory that exist with every algorithm.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class vmsim {

	static final int EIGHT_KB = 2 << 12;
	static final String OUTPUT = """
			Algorithm: %s
			Number of frames:\t%s
			Total memory accesses:\t%d
			Total page faults:\t%d
			Total writes to disk:\t%d
			Total size of page table:\t%d bytes
			""";
	static final String HIT = "hit";
	static final String PAGE_FAULT_NO_EVICT = "page fault – no eviction";
	static final String PAGE_FAULT_CLEAN = "page fault – evict clean";
	static final String PAGE_FAULT_DIRTY = "page fault – evict dirty";

	public static void main(String[] args) {
		if (args.length != 3)
			System.err.println("Incorrect usage, vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
		ArrayList<Tuple> instructionList = parseData(args[2]);
		Ram ram = new Ram(Integer.parseInt(args[0]));
		PageTable table = new PageTable();
		Data results = pickAlgorithm(args[1], instructionList, ram, table);
		System.out.format(OUTPUT, args[1], args[0], results.totalMemoryAccesses,
				results.totalPageFaults, results.totalWritesToDisk, 2 << (32 - 13 - 1));
	}

	/**
	 * takes the users input and determines what algorithm to run
	 *
	 * @param algorithm       the algorithm the user picked
	 * @param instructionList the Tuple pair of the instruction as well as the address
	 * @param ram             teh RAM array
	 * @param table           the page table
	 * @return the data
	 */
	private static Data pickAlgorithm(String algorithm, ArrayList<Tuple> instructionList, Ram ram, PageTable table) {
		switch (algorithm) {
			case "OPT" -> {
				return optimal(instructionList, ram, table);
			}
			case "Clock" -> {
				return clock(instructionList, ram, table);
			}
			case "LRU" -> {
				return leastRecentlyUsed(instructionList, ram, table);
			}
			case "NFU" -> {
				return notFrequentlyUsed(instructionList, ram, table);
			}
			default -> {
				System.err.println(algorithm + " is not one of the valid algorithms");
				System.exit(1);
			}
		}
		return null;
	}

	/**
	 * the not frequently used algorithm is designed to replace page numbers in RAM that are not frequently reference,
	 * any time a page is reference in this algorithm the reference will go up by 1, when it is time to replace a page
	 * the index in ram to be replaced will be the page that has the lowest amount of references
	 *
	 * @param file  the tuple pair information that all the
	 * @param ram   the ram array for the instructions
	 * @param table the page table
	 * @return the amount of memory accesses, page faults, and page writes
	 */
	private static Data notFrequentlyUsed(ArrayList<Tuple> file, Ram ram, PageTable table) {
		Data nFUData = new Data();
		for(int i = 0; i < file.size(); i++) {
			nFUData.totalMemoryAccesses++;
			int pageNumber = getPage(file.get(i).address);
			PageTable.TableEntry pageTableEntry = table.getTableEntries()[pageNumber];
			if (pageTableEntry == null) {
				pageTableEntry = new PageTable.TableEntry();
				table.getTableEntries()[pageNumber] = pageTableEntry;
			}
			if (pageTableEntry.valid) {
				pageTableEntry.referenced++;
				System.out.println(HIT);
			} else {
				nFUData.totalPageFaults++;
				if (ram.index != ram.size) {
					ram.frames[ram.index++] = pageNumber;
					System.out.println(PAGE_FAULT_NO_EVICT);
				} else {
					int frameToReplace = 0;
					int lowestCount = 0;
					for(int j = 0; j < ram.size; j++) {
						if (table.getTableEntries()[ram.frames[j]].referenced < lowestCount) {
							lowestCount = table.getTableEntries()[ram.frames[j]].referenced;
							frameToReplace = j;
						}
					}
					PageTable.TableEntry removedPage = table.getTableEntries()[ram.frames[frameToReplace]];
					if (removedPage.dirty) {
						System.out.println(PAGE_FAULT_DIRTY);
						nFUData.totalWritesToDisk++;
					} else {
						System.out.println(PAGE_FAULT_CLEAN);
					}
					removedPage.dirty = false;
					removedPage.valid = false;
					ram.frames[frameToReplace] = pageNumber;
				}
			}
			pageTableEntry.valid = true;
			pageTableEntry.referenced = 1;
			if (file.get(i).instruction == 'M' || file.get(i).instruction == 'S') {
				pageTableEntry.dirty = true;
			}
		}
		return nFUData;
	}

	/**
	 * the least recently used algorithm will replace the RAM index of the least recently used, it will store the
	 * instructions of that specific page number and look at all the RAM indices to determine which one is used the least
	 *
	 * @param file  the tuple pair information that all the
	 * @param ram   the ram array for the instructions
	 * @param table the page table
	 * @return the amount of memory accesses, page faults, and page writes
	 */
	private static Data leastRecentlyUsed(ArrayList<Tuple> file, Ram ram, PageTable table) {
		Data lRUData = new Data();
		HashMap<Integer, Integer> indexes = new HashMap<>();
		for(int i = 0; i < file.size(); i++) {
			lRUData.totalMemoryAccesses++;
			int pageNumber = getPage(file.get(i).address);
			PageTable.TableEntry pageTableEntry = table.getTableEntries()[pageNumber];

			if (!indexes.containsKey(pageNumber))
				indexes.put(pageNumber, null);
			indexes.put(pageNumber, i);

			if (pageTableEntry == null) {
				pageTableEntry = new PageTable.TableEntry();
				table.getTableEntries()[pageNumber] = pageTableEntry;
			}
			if (pageTableEntry.valid) {
				System.out.println(HIT);
			} else {
				lRUData.totalPageFaults++;
				if (ram.index != ram.size) {
					ram.frames[ram.index++] = pageNumber;
					System.out.println(PAGE_FAULT_NO_EVICT);
				} else {
					int frameToReplace = 0;
					int farthest = 0;
					for(int j = 0; j < ram.size; j++) {
						if (indexes.get(ram.frames[j]) > farthest) {
							farthest = indexes.get(ram.frames[j]);
							frameToReplace = j;
						}
					}
					PageTable.TableEntry removedPage = table.getTableEntries()[ram.frames[frameToReplace]];
					if (removedPage.dirty) {
						System.out.println(PAGE_FAULT_DIRTY);
						lRUData.totalWritesToDisk++;
					} else {
						System.out.println(PAGE_FAULT_CLEAN);
					}
					removedPage.dirty = false;
					removedPage.valid = false;
					ram.frames[frameToReplace] = pageNumber;
				}
			}
			pageTableEntry.valid = true;
			pageTableEntry.referenced = 1;
			if (file.get(i).instruction == 'M' || file.get(i).instruction == 'S') {
				pageTableEntry.dirty = true;
			}
		}
		return lRUData;
	}

	/**
	 * The clock algorithm is taking an array of the RAM and circling around it until it finds an unreferenced page,
	 * every page it finds that is referenced will lose its referenced status
	 *
	 * @param file  the tuple pair information that all the
	 * @param ram   the ram array for the instructions
	 * @param table the page table
	 * @return the amount of memory accesses, page faults, and page writes
	 */
	private static Data clock(ArrayList<Tuple> file, Ram ram, PageTable table) {
		Data clockData = new Data();
		int clockIndex = 0;
		for(int i = 0; i < file.size(); i++) {
			clockData.totalMemoryAccesses++;
			int pageNumber = getPage(file.get(i).address);
			PageTable.TableEntry pageTableEntry = table.getTableEntries()[pageNumber];
			if (pageTableEntry == null) {
				pageTableEntry = new PageTable.TableEntry();
				table.getTableEntries()[pageNumber] = pageTableEntry;
			}
			if (pageTableEntry.valid) {
				pageTableEntry.referenced = 1;
				System.out.println(HIT);
			} else {
				clockData.totalPageFaults++;
				if (ram.index != ram.size) {
					ram.frames[ram.index++] = pageNumber;
					System.out.println(PAGE_FAULT_NO_EVICT);
				} else {
					PageTable.TableEntry removedPage;
					while(true) {
						if (clockIndex == ram.size) {
							clockIndex = 0;
						}
						int potentialEvictPageNumber = ram.frames[clockIndex];
						if (table.getTableEntries()[potentialEvictPageNumber].referenced == 1) {
							table.getTableEntries()[potentialEvictPageNumber].referenced = 0;
							clockIndex++;
						} else {
							removedPage = table.getTableEntries()[potentialEvictPageNumber];
							break;
						}
					}
					if (removedPage.dirty) {
						System.out.println(PAGE_FAULT_DIRTY);
						clockData.totalWritesToDisk++;
					} else {
						System.out.println(PAGE_FAULT_CLEAN);
					}
					removedPage.valid = false;
					removedPage.dirty = false;
					removedPage.referenced = 0;
					ram.frames[clockIndex] = pageNumber;
					clockIndex++;
				}
			}
			pageTableEntry.valid = true;
			pageTableEntry.referenced = 1;
			if (file.get(i).instruction == 'M' || file.get(i).instruction == 'S') {
				pageTableEntry.dirty = true;
			}
		}
		return clockData;
	}

	/**
	 * The opitmal algorithm is the only one that is unusable since it has the ability to see which instructions are
	 * next to pick from, it is also the one that should produce the least amount of page faults since it will know
	 * which page number will not be used for a while
	 *
	 * @param file  the tuple pair information that all the
	 * @param ram   the ram array for the instructions
	 * @param table the page table
	 * @return the amount of memory accesses, page faults, and page writes
	 */
	private static Data optimal(ArrayList<Tuple> file, Ram ram, PageTable table) {
		Data optimalData = new Data();
		HashMap<Integer, ArrayList<Integer>> map = createDict(file);
		for(int i = 0; i < file.size(); i++) {
			optimalData.totalMemoryAccesses++;
			int pageNumber = getPage(file.get(i).address);
			PageTable.TableEntry pageTableEntry = table.getTableEntries()[pageNumber];
			if (pageTableEntry == null) {
				pageTableEntry = new PageTable.TableEntry();
				table.getTableEntries()[pageNumber] = pageTableEntry;
			}
			if (pageTableEntry.valid) {
				System.out.println(HIT);
			} else {
				optimalData.totalPageFaults++;
				if (ram.index != ram.size) {
					ram.frames[ram.index++] = pageNumber;
					System.out.println(PAGE_FAULT_NO_EVICT);
				} else {
					int bestFrameToRemove = 0;
					int farthestUseTime = 0;
					for(int j = 0; j < ram.size; j++) {
						int pageInRam = ram.frames[j];
						ArrayList<Integer> pageAccessTimes = map.get(pageInRam);
						int nextUsedTime = 0;
						for(int k = 0; k < pageAccessTimes.size(); k++) {
							int usedTime = pageAccessTimes.get(k);
							if (usedTime > i) {
								nextUsedTime = usedTime;
								break;
							}
							if (k == pageAccessTimes.size() - 1 && i > usedTime) {
								nextUsedTime = Integer.MAX_VALUE;
							}
						}
						if (nextUsedTime > farthestUseTime) {
							bestFrameToRemove = j;
							farthestUseTime = nextUsedTime;
						}
					}
					int pageNumberToRemove = ram.frames[bestFrameToRemove];
					PageTable.TableEntry pageToRemove = table.getTableEntries()[pageNumberToRemove];
					if (pageToRemove.dirty) {
						optimalData.totalWritesToDisk++;
						System.out.println(PAGE_FAULT_DIRTY);
					} else {
						System.out.println(PAGE_FAULT_CLEAN);
					}
					pageToRemove.valid = false;
					pageToRemove.dirty = false;
					ram.getFrames()[bestFrameToRemove] = pageNumber;
				}
			}
			pageTableEntry.valid = true;
			if (file.get(i).instruction == 'M' || file.get(i).instruction == 'S') {
				pageTableEntry.dirty = true;
			}
		}
		return optimalData;
	}

	/**
	 * converts the file information into a dictionary mapping all the page numbers to their places in the file
	 *
	 * @param file the tuple pair information that all the
	 * @return a hash map of all the page numbers and where they are in the file
	 */
	private static HashMap<Integer, ArrayList<Integer>> createDict(ArrayList<Tuple> file) {
		HashMap<Integer, ArrayList<Integer>> map = new HashMap<>();
		for(int i = 0; i < file.size(); i++) {
			int pageNumber = getPage(file.get(i).address);
			if (!map.containsKey(pageNumber))
				map.put(pageNumber, new ArrayList<>());
			map.get(pageNumber).add(i);
		}
		return map;
	}

	/**
	 * takes the address and converts it into decimal formatting and then divides it by the size of each page
	 *
	 * @param address the hexadecimal
	 * @return the page number
	 */
	private static int getPage(String address) {
		return (int) (Long.parseLong(address, 16) / EIGHT_KB);
	}

	/**
	 * takes the data from the file and takes the instructions and the address for the tuple
	 *
	 * @param fileName the name of where the .trace file is
	 * @return an array list of all the addresses and their instructions
	 */
	private static ArrayList<Tuple> parseData(String fileName) {
		ArrayList<Tuple> list = new ArrayList<>();
		try {
			File file = new File(fileName);
			BufferedReader steam = new BufferedReader(new FileReader(file));
			String line;
			while((line = steam.readLine()) != null) {
				if (line.charAt(0) == 'I') {
					list.add(new Tuple(line.charAt(0), line.substring(3, 11)));
				} else if (line.charAt(1) == 'S' || line.charAt(1) == 'M' || line.charAt(1) == 'L') {
					list.add(new Tuple(line.charAt(1), line.substring(3, 11)));
				}
			}
			steam.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * a simple class that holds the instructions and the addresses
	 */
	private static class Tuple {
		private final char instruction;
		private final String address;

		Tuple(char instruction, String address) {
			this.instruction = instruction;
			this.address = address;
		}
	}

	/**
	 * a simple class to hold the specific integer numbers for the end report
	 */
	private static class Data {
		int totalMemoryAccesses = 0;
		int totalPageFaults = 0;
		int totalWritesToDisk = 0;
	}
}
