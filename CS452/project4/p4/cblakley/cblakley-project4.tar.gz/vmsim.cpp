/* Name: Cole Blakley
   Course: CSC 452
   Description: This program simulates several virtual memory page replacement algorithms
     with a user-provided number of frames of RAM, then prints performance statistics
     about the selected algorithm.

     To build the program, run `make`.
*/
#include <iostream>
#include <fstream>
#include <string>
#include <optional>
#include <vector>
#include <list>
#include <unordered_set>
#include <unordered_map>
#include <cstdint>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <memory>

const uint32_t PageSize = 8192; // in bytes

enum class PageReplaceMethod {
    OPT, Clock, LRU, NFU
};

// Print function for the PageReplaceMethod enum
static
std::ostream& operator<<(std::ostream& stream, PageReplaceMethod algorithm)
{
    switch(algorithm) {
    case PageReplaceMethod::OPT:
        return stream << "opt";
    case PageReplaceMethod::Clock:
        return stream << "clock";
    case PageReplaceMethod::LRU:
        return stream << "lru";
    default:
        return stream << "nfu";
    }
}

// Statistics for a page replacement algorithm
struct MemoryStats {
    PageReplaceMethod algorithm;
    const char* trace_file;
    uint32_t frame_count;
    size_t total_mem_accesses = 0;
    size_t total_page_faults = 0;
    size_t total_writes_to_disk = 0;
    size_t page_table_size = 0;

    MemoryStats(PageReplaceMethod algorithm, const char* trace_file, uint32_t frame_count)
        : algorithm(algorithm), trace_file(trace_file), frame_count(frame_count) {}
};

enum class AccessKind {
    Load, // Includes loading instructions/loading data
    Store,
    Modify
};

// Represents a single memory access by the user program
struct MemAccess {
    uint32_t v_address;
    AccessKind kind;

    MemAccess(uint32_t v_address, AccessKind kind)
        : v_address(v_address), kind(kind) {}
};

// Represents a page of virtual memory
struct PageEntry {
    uint32_t frame;
    // The number of times this page has been accessed so far
    uint64_t count = 0;
    unsigned char flags = 0;

    void clear_flags() { flags = 0; }
    // True if currently loaded in RAM
    bool is_valid() const { return flags & 0b00000001; }
    // True if needs to be written to swap space
    bool is_dirty() const { return (flags & 0b00000010) >> 1; }
    // True if this page has been accessed by the program recently
    bool is_referenced() const { return (flags & 0b00000100) >> 2; }
    void set_valid()   { flags |= 0b00000001; }
    void set_dirty()   { flags |= 0b00000010; }
    void set_referenced()   { flags |= 0b00000100; }
    void unset_referenced() { flags &= 0b11111011; }
};

// Represents a frame in RAM. Initially unoccupied and not associated with a page
struct FrameEntry {
    uint32_t page;
    bool is_valid = false;
};

// Remove the given page number from a list. Assumes the page number only
// appears once.
static
void remove_page_from_queue(std::list<uint32_t>& queue, uint32_t page_num)
{
    auto match = std::find(queue.begin(), queue.end(), page_num);
    assert(match != queue.end());
    queue.erase(match);
}

// Interface for the various page replacement algorithms
class PageReplacer {
public:
    virtual ~PageReplacer() = default;

    // Returns the number of bytes in the page table given the
    // number of entries in the page table
    virtual size_t page_table_size(size_t) const = 0;
    // Called when a given, in-RAM page number is accessed
    virtual void on_valid_RAM_access(uint32_t) {}
    // Return the page number of the currently in-RAM page to evict
    virtual uint32_t find_evicted_page(uint32_t) = 0;
    // Called when a given, not-in-RAM page number is first loaded into RAM.
    // Called after find_evicted_page() is.
    virtual void on_page_load(uint32_t) {}
};

// Evict the page that will next be needed furthest in the future
class OPTReplacer : public PageReplacer {
    const std::unordered_map<uint32_t, std::vector<size_t>>& m_access_history;
    const std::vector<FrameEntry>& m_frame_table;
public:
    OPTReplacer(const std::unordered_map<uint32_t, std::vector<size_t>>& access_history,
                const std::vector<FrameEntry>& frame_table)
        : m_access_history(access_history), m_frame_table(frame_table) {}

    size_t page_table_size(size_t entry_count) const override
    {
        // Frame number (4 bytes) and valid bit (1 byte)
        return entry_count * 5;
    }

    // access_num is the index in the access history (e.g. the program's first
    // memory access has an access_num of 0)
    uint32_t find_evicted_page(uint32_t access_num) override
    {
        // Evict the page that will next be used farthest in the future
        // The access number at which the evicted page is next needed
        size_t farthest_access;
        bool valid_match = false;
        uint32_t evicted_page_num = 0;
        for(uint32_t i = 0; i < m_frame_table.size(); ++i) {
            const FrameEntry& entry = m_frame_table[i];
            if(!entry.is_valid)
                continue;
            auto match = m_access_history.find(entry.page);
            assert(match != m_access_history.end());
            const std::vector<size_t>& access_list = match->second;
            // The access list will be in sorted order, so can use
            // binary search to locate next element >= access_num
            auto next_access = std::lower_bound(access_list.begin(),
                                                access_list.end(),
                                                access_num);
            if(next_access == access_list.end()) {
                // Found a page that is never accessed after this point
                // in execution; won't find a better match
                evicted_page_num = entry.page;
                valid_match = true;
                break;
            } else if(valid_match && *next_access > farthest_access) {
                // Found a page that is next accessed further forward
                // than what we've seen so far
                evicted_page_num = entry.page;
                farthest_access = *next_access;
            } else if(!valid_match && next_access != access_list.end()) {
                // Initial candidate page to evict
                evicted_page_num = entry.page;
                farthest_access = *next_access;
                valid_match = true;
            }
        }
        assert(valid_match);
        return evicted_page_num;
    }
};

// Evict the next unreferenced page in a circular queue
class ClockReplacer : public PageReplacer {
    std::list<uint32_t> m_recently_used_pages;
    std::vector<PageEntry>& m_page_table;
    std::list<uint32_t>::iterator m_hand;
    std::optional<std::list<uint32_t>::iterator> m_evicted_slot;
public:
    explicit
    ClockReplacer(std::vector<PageEntry>& page_table)
        : m_page_table(page_table), m_hand(m_recently_used_pages.end()) {}

    size_t page_table_size(size_t entry_count) const override
    {
        // Frame number (4 bytes), valid bit and referenced bit (1 byte)
        return entry_count * 5;
    }

    void on_valid_RAM_access(uint32_t page_num) override
    {
        m_page_table[page_num].set_referenced();
    }

    void on_page_load(uint32_t page_num) override
    {
        m_page_table[page_num].set_referenced();
        if(m_evicted_slot.has_value()) {
            // Replace evicted page's slot with the new page
            *m_evicted_slot.value() = page_num;
            m_evicted_slot.reset();
        } else {
            m_recently_used_pages.push_back(page_num);
        }
    }

    uint32_t find_evicted_page(uint32_t) override
    {
        assert(!m_recently_used_pages.empty());
        uint32_t evict_page_num = 0;
        bool found_match = false;
        do {
            if(m_hand == m_recently_used_pages.end()) {
                m_hand = m_recently_used_pages.begin();
            }
            uint32_t page_num = *m_hand;
            PageEntry& entry = m_page_table[page_num];
            if(entry.is_referenced()) {
                entry.unset_referenced();
            } else {
                evict_page_num = page_num;
                found_match = true;
                // When on_page_load() is called with the new page,
                // this position will get overwritten with the new page
                m_evicted_slot = m_hand;
            }
            ++m_hand;
        } while(!found_match);
        return evict_page_num;
    }
};

// Evict the page that was accessed least recently
class LRUReplacer : public PageReplacer {
    // Contains list of recently used page numbers; front is most
    // recently used, back is least recently used
    std::list<uint32_t> m_recently_used_pages;
public:
    size_t page_table_size(size_t entry_count) const override
    {
        // Frame number (4 bytes) and 64-bit counter (8 bytes)
        return entry_count * 12;
    }

    void on_valid_RAM_access(uint32_t page_num) override
    {
        remove_page_from_queue(m_recently_used_pages, page_num);
        m_recently_used_pages.push_front(page_num);
    }

    void on_page_load(uint32_t page_num) override
    {
        m_recently_used_pages.push_front(page_num);
    }

    uint32_t find_evicted_page(uint32_t) override
    {
        // Evict the least recently used page
        assert(!m_recently_used_pages.empty());
        uint32_t evicted_page_num = m_recently_used_pages.back();
        m_recently_used_pages.pop_back();
        return evicted_page_num;
    }
};

// Evict the page that has least number of references
class NFUReplacer : public PageReplacer {
    std::vector<PageEntry>& m_page_table;
    const std::vector<FrameEntry>& m_frame_table;
public:
    NFUReplacer(std::vector<PageEntry>& page_table,
                const std::vector<FrameEntry>& frame_table)
        : m_page_table(page_table), m_frame_table(frame_table) {}

    size_t page_table_size(size_t entry_count) const override
    {
        // Frame number (4 bytes) and 64-bit counter (8 bytes)
        return entry_count * 12;
    }

    void on_valid_RAM_access(uint32_t page_num) override
    {
        ++m_page_table[page_num].count;
    }

    void on_page_load(uint32_t page_num) override
    {
        ++m_page_table[page_num].count;
    }

    uint32_t find_evicted_page(uint32_t) override
    {
        uint32_t evicted_page_num = 0;
        uint64_t min_evict_count = 0;
        bool valid_match = false;
        for(uint32_t i = 0; i < m_frame_table.size(); ++i) {
            const FrameEntry& entry = m_frame_table[i];
            if(!entry.is_valid)
                continue;
            if(!valid_match) {
                evicted_page_num = entry.page;
                min_evict_count = m_page_table[entry.page].count;
                valid_match = true;
            } else if(m_page_table[entry.page].count < min_evict_count) {
                evicted_page_num = entry.page;
                min_evict_count = m_page_table[entry.page].count;
            }
        }
        assert(valid_match);
        m_page_table[evicted_page_num].count = 0;
        return evicted_page_num;
    }
};

struct PageTable {
    // Maps page numbers to frame numbers
    std::vector<PageEntry> m_page_table;
    // Maps frame numbers to page numbers
    std::vector<FrameEntry> m_frame_table;
    // An object that handles evicting pages/book-keeping for virtual memory
    std::unique_ptr<PageReplacer> m_page_replacer;

    // Contains the page numbers of all pages currently cached on disk
    std::unordered_set<uint32_t> m_swap_space;
    size_t m_empty_frame_count;
    MemoryStats& m_stats;

    // Sets-up the page table and related data structures
    PageTable(MemoryStats& stats,
              const std::unordered_map<uint32_t, std::vector<size_t>>& access_history)
        : m_empty_frame_count(stats.frame_count), m_stats(stats)
    {
        m_page_table.resize(4294967296u / PageSize);
        m_frame_table.resize(stats.frame_count);

        switch(stats.algorithm) {
        case PageReplaceMethod::OPT:
            m_page_replacer = std::make_unique<OPTReplacer>(access_history, m_frame_table);
            break;
        case PageReplaceMethod::Clock:
            m_page_replacer = std::make_unique<ClockReplacer>(m_page_table);
            break;
        case PageReplaceMethod::LRU:
            m_page_replacer = std::make_unique<LRUReplacer>();
            break;
        case PageReplaceMethod::NFU:
            m_page_replacer = std::make_unique<NFUReplacer>(m_page_table, m_frame_table);
            break;
        }

        stats.page_table_size = m_page_replacer->page_table_size(m_page_table.size());
    }

    // Given a page number, clear its entry in the page table,
    // swapping to disk if needed
    void clear_page_entry(uint32_t page_num)
    {
        PageEntry& entry = m_page_table[page_num];
        if(entry.is_dirty()) {
            // Page doesn't have an up-to-date copy in swap space, so need to
            // write it to disk
            ++m_stats.total_writes_to_disk;
            m_swap_space.insert(page_num);
            std::cout << "page fault - evict dirty\n";
        } else {
            std::cout << "page fault - evict clean\n";
        }
        entry.clear_flags();
    }

    // Return the frame number to be used by a new page. Could be a previously
    // empty frame or a reclaimed frame.
    uint32_t find_frame(size_t access_num)
    {
        uint32_t frame_num = 0;
        if(m_empty_frame_count > 0) {
            // Use an empty frame if possible
            bool found_match = false;
            for(uint32_t i = 0; i < m_frame_table.size(); ++i) {
                if(!m_frame_table[i].is_valid) {
                    frame_num = i;
                    found_match = true;
                    break;
                }
            }
            assert(found_match);
            --m_empty_frame_count;
            std::cout << "page fault - no eviction\n";
        } else {
            // Couldn't find an empty frame, so have to evict page
            uint32_t evicted_page_num = m_page_replacer->find_evicted_page(access_num);
            frame_num = m_page_table[evicted_page_num].frame;
            clear_page_entry(evicted_page_num);
        }
        return frame_num;
    }

    // Simulate a memory access to some virtual address. access_num is provided
    // in case the OPT page replacement algorithm is used
    void access(uint32_t v_address, AccessKind kind, size_t access_num)
    {
        uint32_t page_num = v_address / PageSize;
        PageEntry& entry = m_page_table[page_num];
        ++m_stats.total_mem_accesses;
        if(kind == AccessKind::Modify) {
            ++m_stats.total_mem_accesses;
        }

        if(entry.is_valid()) {
            // Page is already loaded in RAM
            if(kind == AccessKind::Store || kind == AccessKind::Modify) {
                // Will immediately write to this page, so no longer an up-to-date
                // version in swap space
                entry.set_dirty();
            }
            std::cout << "hit\n";
            m_page_replacer->on_valid_RAM_access(page_num);
        } else {
            // Page we want isn't in RAM, so need to find an unused frame,
            // or swap a used frame out
            ++m_stats.total_page_faults;
            entry.frame = find_frame(access_num);
            entry.set_valid();
            // Now the frame number is mapped to a new page number
            m_frame_table[entry.frame].page = page_num;
            m_frame_table[entry.frame].is_valid = true;
            m_page_replacer->on_page_load(page_num);
            if(m_swap_space.find(page_num) != m_swap_space.end()) {
                // Page we want is in swap space, so load it
                if(kind == AccessKind::Store || kind == AccessKind::Modify) {
                    // Will immediately write to this page, so disk version will no
                    // longer be up-to-date
                    entry.set_dirty();
                }
            } else {
                // Page we want isn't in swap space
                // Mark as dirty so we know to write it to disk if/when we swap it
                if(kind == AccessKind::Store || kind == AccessKind::Modify) {
                    // Will immediately write to this page, so disk version will no
                    // longer be up-to-date
                    entry.set_dirty();
                }
            }
        }
    }
};

// Given a line of text, extract the base16 address out of it.
// Returns an empty optional if failed to parse.
static
std::optional<uint32_t> parse_address(const std::string& line)
{
    auto addr_start = line.begin()+3;
    auto addr_end = std::find(addr_start, line.end(), ',');
    if(addr_end == line.end() || addr_end <= addr_start)
        return {};
    std::string addr_str(addr_start, addr_end);
    try {
        return {std::stoul(addr_str, nullptr, 16)};
    } catch(const std::exception&) {
        // Failed to convert address to an integer
        return {};
    }
}

// Given a trace file, extract all memory accesses out of it,
// storing them into a list. This enables us to only parse the
// trace file once and re-scan the accesses as needed.
static
std::vector<MemAccess>
parse_mem_accesses(std::ifstream& trace_file)
{
    std::vector<MemAccess> accesses;
    std::string line;
    while(trace_file) {
        std::getline(trace_file, line);
        if(line.size() < 13)
            continue;

        AccessKind access_kind;
        if(line[0] == 'I' && line[1] == ' ' && line[2] == ' ') {
            access_kind = AccessKind::Load;
        } else if(line[0] == ' ' && line[2] == ' ') {
            char kind = line[1];
            if(kind == 'L') {
                access_kind = AccessKind::Load;
            } else if(kind == 'S') {
                access_kind = AccessKind::Store;
            } else if(kind == 'M') {
                access_kind = AccessKind::Modify;
            } else {
                continue;
            }
        } else {
            continue;
        }
        std::optional<uint32_t> maybe_address = parse_address(line);
        if(!maybe_address.has_value())
            continue;
        uint32_t address = maybe_address.value();

        accesses.emplace_back(address, access_kind);
    }
    return accesses;
}

// Create a map that contains, for each page number, a list of the points
// in program execution (represented by the memory access number) in which
// that page is required to be in RAM.
static
std::unordered_map<uint32_t, std::vector<size_t>>
gather_access_history(const std::vector<MemAccess>& mem_accesses)
{
    size_t i = 0;
    std::unordered_map<uint32_t, std::vector<size_t>> access_points;
    for(auto[v_address, _] : mem_accesses) {
        uint32_t page_num = v_address / PageSize;
        if(auto access_list = access_points.find(page_num); access_list != access_points.end()) {
            access_list->second.push_back(i);
        } else {
            access_points.emplace(page_num, std::vector<size_t>{i});
        }
        ++i;
    }
    return access_points;
}

// Simulate virtual memory as if running the program using the list of memory
// accesses and applying them in order
static
void run_trace(const std::vector<MemAccess>& mem_accesses, PageTable& page_table)
{
    size_t i = 0;
    for(auto[v_address, access_kind] : mem_accesses) {
        page_table.access(v_address, access_kind, i);
        ++i;
    }
}

// Usage information for mis-entered command line usage
static
void print_usage()
{
    std::cerr << "Usage: vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>\n";
}

// Print out statistics about the algorithm used, its performance
static
void print_summary(const MemoryStats& stats)
{
    std::cout << "Algorithm: " << stats.algorithm
              << "\nNumber of frames:         " << stats.frame_count
              << "\nTotal memory accesses:    " << stats.total_mem_accesses
              << "\nTotal page faults:        " << stats.total_page_faults
              << "\nTotal writes to disk:     " << stats.total_writes_to_disk
              << "\nTotal size of page table: " << stats.page_table_size
              << " bytes\n";
}

// Parse command-line parameters. Returns an empty optional if failed to parse.
static
std::optional<MemoryStats> get_params(int argc, char** argv)
{
    if(argc < 6) {
        return {};
    }
    if(strcmp(argv[1], "-n") != 0 || strcmp(argv[3], "-a") != 0) {
        return {};
    }
    PageReplaceMethod algorithm;
    if(strcmp(argv[4], "opt") == 0) {
        algorithm = PageReplaceMethod::OPT;
    } else if(strcmp(argv[4], "clock") == 0) {
        algorithm = PageReplaceMethod::Clock;
    } else if(strcmp(argv[4], "lru") == 0) {
        algorithm = PageReplaceMethod::LRU;
    } else if(strcmp(argv[4], "nfu") == 0) {
        algorithm = PageReplaceMethod::NFU;
    } else {
        return {};
    }
    const char* trace_file = argv[5];
    const char* frame_count_str = argv[2];

    if(!std::all_of(frame_count_str, frame_count_str+strlen(frame_count_str), isdigit)) {
        return {};
    }

    uint32_t frame_count;
    try {
        frame_count = std::stoul(frame_count_str);
    } catch(const std::exception&) {
        // Failed to convert frame count to an integer
        return {};
    }

    return MemoryStats(algorithm, trace_file, frame_count);
}


int main(int argc, char** argv)
{
    std::optional<MemoryStats> maybe_stats = get_params(argc, argv);
    if(!maybe_stats.has_value()) {
        print_usage();
        return 1;
    }
    MemoryStats& stats = maybe_stats.value();

    std::ifstream trace_file(stats.trace_file);
    if(!trace_file) {
        std::cerr << "Error: could not open trace file: " << stats.trace_file << "\n";
        return 1;
    }

    std::vector<MemAccess> mem_accesses = parse_mem_accesses(trace_file);
    std::unordered_map<uint32_t, std::vector<size_t>> access_history;
    if(stats.algorithm == PageReplaceMethod::OPT) {
        // Only need to compute the access history if using OPT
        access_history = gather_access_history(mem_accesses);
    }
    PageTable page_table(stats, access_history);
    run_trace(mem_accesses, page_table);
    print_summary(stats);

    return 0;
}
