 /* File: vmsim.c
 *
 * Author: Zachary Taylor
 * NetID: ztaylor
 * Class: CSC 452
 * Assignment: P4
 *
 * Uses a trace file to simulate the virtural memory of a machine.
 *	Reads a the given trace file and uses the given number of frames to
 *	run several different algorithms, opt, clock, lru, and nfu.
 *
 * I am having a strange Segfault error that occurs after my program runs
 * its last line of code in main.  the gdb points to the last } of my lru
 * function and the program seems to run just fine besides that. 
 */
#define  _POSIX_C_SOURCE 200809L
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct Command{
	char command;
	int address;
	int size;
	int line;
	struct Page* page;
	struct Command* next;
	struct Command* nextPageCommand;
}Command;
typedef struct Page{
	struct Command* head;
	struct Command* tail;
	struct Page* next;
	struct Page* prev;
	
	int freq;
	int frame;
	int valid;
	int dirty;
	int ref;
	int pageNum;
}Page;
struct Page* clockHead;
struct Page* clockTail;
struct Page ** pageTable;
struct Page ** frameTable;
struct Command* head;
struct Command* tail;
struct Command* OGhead;
int frames;
int accesses;
int faults;
int writes;
const int chunkSize = pow(2, 13);
const double pageTableSize = pow(2, 32);
const int tableSize = pageTableSize / chunkSize;


/* Purpose: creates a command struct using the address and command symbol,
 *		and the line the command is from
 *	
 * Params: command is a character for the type of command being executed for that line
 *		address is an unsigned int for the area in memory that the command was saved in
 *		line is an int for the location in the trace file the command is from
 */
void commandMaker(char command, unsigned int address, int size, int line){
	struct Command* new = (struct Command*) malloc(sizeof(struct Command));
	if(head == NULL){
		OGhead = new;
		head = new;
		head->command = command;
		head->address = address;
		head->size = size;
		head->line = line;
		head->next = NULL;
		head->nextPageCommand = NULL;
		head->page = pageTable[address/chunkSize];
		if(head->page->head == NULL){
			head->page->head = head;
			head->page->tail = head;
		}else{
			head->page->tail->nextPageCommand = head;
			head->page->tail = head->page->tail->nextPageCommand;
		}
		tail = head;
	}else{
		tail->next = new;
		new->command = command;
		new->address = address;
		new->size = size;
		new->line = line;
		new->next = NULL;
		new->nextPageCommand = NULL;
		new->page = pageTable[address/chunkSize];
		if(new->page->head == NULL){
			new->page->head = new;
			new->page->tail = new;
		}else{
			new->page->tail->nextPageCommand = new;
			new->page->tail = new->page->tail->nextPageCommand;
		}
		tail = new;
	}
}
/* Purpose: reads out the important details from the trace file
 *	
 * Params: file is the filestream that we are reading from
 */
void fileCleaner(FILE *file){
	char* buffer = (char *) malloc(sizeof(char)*15);;
	char* breaks;
	char command;
	unsigned int address;
	int size = 1;
	int line = 0;
	size_t buffsz = 0;
	while(getline(&buffer, &buffsz, file) > 0){
		if(buffer[0] == 'I'){
			sscanf(buffer, "%c %s,%d",&command, breaks, &size);
			address = (int)strtol(breaks,NULL,16);
			commandMaker(command,address,size,line);
		}else if(buffer[1] == 'S' || buffer[1] == 'L' || buffer[1] == 'M'){
			sscanf(buffer, " %c %s,%d",&command, breaks, &size);
			address = (int)strtol(breaks,NULL,16);
			commandMaker(command,address,size,line);
		}
		line++;
	}
	// free(buffer);
}
/* Purpose: Finds the index of an empty frame from the frame table if one exists
 *	
 * Returns: the index of the empty frame if it exists otherwise -1 to indicate
 *		all frames are full
 */
int findEmptyFrame(){
	for(int i = 0; i < frames; i++){
		if(frameTable[i] == NULL){
			return i;
		}
	}
	return -1;
}
/* Purpose: Runs the optimal method of evicting pages from the frame table
 *	
 */
void opt(){
	int frame;
	int distance = 0;
	int i;
	while(head != NULL){
		distance = 0;
		printf("%u: ",head->address);
		if(head->page->valid != 1){
			printf("page fault - ");
			faults++;
			frame = findEmptyFrame();
			if(frame >= 0){
				printf("no eviction");
				frameTable[frame] = head->page;
				frameTable[frame]->valid = 1;
				head->page->frame = frame;
			}else{
				//evict page that will be used last
				for(i = 0; i < frames; i++){
					if(frameTable[i]->head == NULL){
						//found page with no more commands
						frame = i;
						break;
					}else{
						//find page thats next command is furthest from current line
						if(frameTable[i]->head->line - head->line >= distance){
							distance =  frameTable[i]->head->line - head->line;
							frame = i;
						}
					}
				}
				if(frameTable[frame]->dirty == 1){
					writes++;
					frameTable[frame]->dirty = 0;
					printf("evict dirty");
				}else{
					printf("evict clean");
				}
				frameTable[frame]->frame = -1;
				frameTable[frame]->valid = 0;
				frameTable[frame] = head->page;
				frameTable[frame]->frame = frame;
				frameTable[frame]->valid = 1;
			}
		}else{
			printf("hit");
		}
		if(head->command == 'M' || head->command == 'S'){
			head->page->dirty = 1;
		}
		if(head->command == 'M'){
			accesses++;
		}
		accesses++;
		head->page->head = head->nextPageCommand;
		head = head->next;
		printf("\n");
	}
}
/* Purpose: Runs the Clock algorithm on the list of commands found in head
 *	
 */
void clock(){
	int clockCount = 0;
	while(head != NULL){
		printf("%u: ",head->address);
		if(head->page->valid != 1){
			faults++;
			printf("page fault - ");
			if(clockHead == NULL){
				printf("no eviction");
				clockHead = head->page;
				clockCount++;
				clockTail = clockHead;
				clockHead->next = clockTail;
				clockHead->prev = clockTail;
			}else if(clockCount < frames){
				printf("no eviction");
				clockTail->next = head->page;
				clockHead->prev = head->page;
				head->page->prev = clockTail;
				head->page->next = clockHead;
				clockTail = head->page;
				clockCount++;
			}else{
				while(clockHead->ref != 0){
					clockHead->ref = 0;
					clockHead = clockHead->next;
				}
				if(clockHead->dirty == 1){
					clockHead->dirty = 0;
					writes++;
					printf("evict dirty");
				}else{
					printf("evict clean");
				}
				clockHead->valid = 0;
				head->page->next = clockHead->next;
				head->page->prev = clockHead->prev;
				clockHead->prev->next = head->page;
				clockHead->next->prev = head->page;
				clockHead = head->page->next;
			}
			
		}else{
			printf("hit");
		}
		
		if(head->command == 'M' || head->command == 'S'){
			head->page->dirty = 1;
		}
		if(head->command == 'M'){
			accesses++;
		}
		accesses++;
		head->page->valid = 1;
		head->page->ref = 1;
		head = head->next;
		printf("\n");
	}
}
/* Purpose: Runs a Not Frequently Used algorithm on our list of commands
 *	
 */
void nfu(){
	int frame;
	int freq;
	int i;
	while(head != NULL){
		printf("%u: ",head->address);
		if(head->page->valid != 1){
			faults++;
			printf("page fault - ");
			frame = findEmptyFrame();
			if(frame >= 0){
				printf("no eviction");
				frameTable[frame] = head->page;
				frameTable[frame]->valid = 1;
				head->page->frame = frame;
			}else{
				freq = frameTable[0]->freq;
				frame = 0;
				for(i = 1; i < frames; i++){
					if(frameTable[i]->freq < freq){
						freq = frameTable[i]->freq;
						frame = i;
					}
				}
				if(frameTable[frame]->dirty == 1){
					writes++;
					frameTable[frame]->dirty = 0;
					printf("evict dirty");
				}else{
					printf("evict clean");
				}
				frameTable[frame]->freq = 0;
				frameTable[frame]->frame = -1;
				frameTable[frame]->valid = 0;
				frameTable[frame] = head->page;
				frameTable[frame]->frame = frame;
				frameTable[frame]->valid = 1;
			}
		}else{
			printf("hit");
		}
		if(head->command == 'M' || head->command == 'S'){
			head->page->dirty = 1;
		}
		if(head->command == 'M'){
			accesses++;
		}
		accesses++;
		head->page->freq++;
		head = head->next;
		printf("\n");
	}
				
}
/* Purpose: runs a Least Recently Used algorithm
 *	
 */
void lru(){
	int frame;
	int oldest = 0;
	int i;
	while(head != NULL){
		oldest = 0;
		printf("%u: ",head->address);
		if(head->page->valid != 1){
			faults++;
			printf("page fault - ");
			frame = findEmptyFrame();
			if(frame >= 0){
				printf("no eviction");
				frameTable[frame] = head->page;
				frameTable[frame]->valid = 1;
				head->page->frame = frame;
			}else{
				for(i = 0; i < frames; i++){
					//Using freq in the page struct to track what line number the page was last used on
					if(head->line - frameTable[i]->freq > oldest){
						oldest = head->line - frameTable[i]->freq;
						frame = i;
					}
				}
				if(frameTable[frame]->dirty == 1){
					writes++;
					frameTable[frame]->dirty = 0;	
					printf("evict dirty");
				}else{
					printf("evict clean");
				}
				frameTable[frame]->frame = -1;
				frameTable[frame]->valid = 0;
				frameTable[frame] = head->page;
				frameTable[frame]->frame = frame;
				frameTable[frame]->valid = 1;
			}
		}else{
			printf("hit");
		}
		if(head->command == 'M' || head->command == 'S'){
			head->page->dirty = 1;
		}
		if(head->command == 'M'){
			accesses++;
		}
		accesses++;
		head->page->freq = head->line;
		head = head->next;
		printf("\n");
	}
}
int main(int argc, char **argv){
	head = NULL;
	frames = atoi(argv[2]);
	frameTable = (Page**)malloc(sizeof(struct Page*)*frames);
	for(int i = 0; i < frames; i++){
		frameTable[i] = NULL;
	}
	pageTable = (Page**)malloc(sizeof(struct Page*) * tableSize);
	for(int i = 0; i < tableSize; i++){
		pageTable[i] = (Page*) malloc(sizeof(struct Page));
		pageTable[i]->head = NULL;
		pageTable[i]->valid = 0;
		pageTable[i]->dirty = 0;
		pageTable[i]->ref = 0;
		pageTable[i]->freq = 0;
		pageTable[i]->frame = -1;
		pageTable[i]->pageNum = i;
	}
	accesses = 0;
	faults = 0;
	writes = 0;
	FILE* file = fopen(argv[5], "r");
	if(file == NULL){
		printf("ERROR!");
		return 1;
	}
	fileCleaner(file);
	fclose(file);
	if(strcmp(argv[4], "opt") == 0){
		opt();
	}else if(strcmp(argv[4], "clock") == 0){
		clock();
	}else if(strcmp(argv[4], "lru") == 0){
		lru();
	}else if(strcmp(argv[4], "nfu") == 0){
		nfu();
	}else{
		printf("error in arg 4\n");
	}
	
	printf("Algorithm: %s\nNumber of frames: %d\nTotal memory accesses: %d\nTotalPageFaults: %d\nTotal writes to disk: %d\nTotal size of page table: %d bytes\n", argv[4], frames, accesses, faults, writes, tableSize * 4);
	// free(frameTable);
	// free(pageTable);
	// while(OGhead != NULL){
		// Command* prev = OGhead;
		// OGhead = OGhead->next;
		// free(prev);
	// }
}