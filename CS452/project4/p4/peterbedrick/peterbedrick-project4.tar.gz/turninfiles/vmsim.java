/**
 *
 * Author: Peter Bedrick
 * Course: CSC452
 * Instructor: Misurda
 * File: vmsim.java
 * Purpose: 
 *
 */

import java.io.*;
import java.util.*;

public class vmsim {

	public static int faults = 0;
	public static int writes = 0;

	public static void main(String[] args) {
		if(args.length != 5) {
			System.out.println("Invalid arguments");
			return;
		}
		if(!args[0].toLowerCase().equals("-n")) {
			System.out.println("Invalid arguments: " + args[0]);
			return;
		}
		if(!args[2].toLowerCase().equals("-a")) {
			System.out.println("Invalid arguments: " + args[2]);
			return;
		}
		int frames = 0;
		try {
        		frames = Integer.parseInt( args[1] );	
    		} catch( NumberFormatException e ) {
			System.out.println("Invalid arguments: " + args[1]);
        		return;
    		}
		BufferedReader file = null;
		try {
			file = new BufferedReader(new FileReader(args[4]));
		} catch(IOException e) {
			System.out.println("File not found: " + args[4]);
			return;
		}
		List<String[]> writeLines = new ArrayList<String[]>();
		int totalSize = 0;
		int accesses = 0;
		while(true) {
                        String line = "";
			try {
				line = file.readLine();
			} catch(IOException e) {
				System.out.println("Can't read line");
				return;
			}
			if(line == null) {
				break;
			}
                        String[] arr = line.trim().split("\\s+|\\,");
                        if((arr[0].equals("I") || arr[0].equals("L") || arr[0].equals("M") || arr[0].equals("S")) && arr.length == 3) {
                       		if(arr[0].equals("S") || arr[0].equals("M")) {
                        		writeLines.add(arr);
				}
				totalSize += Integer.parseInt(arr[2]);
				accesses++;
				if(arr[0].equals("M")) {
					accesses++;
				}
			}
                }
		if(args[3].toLowerCase().equals("opt")) {
			opt(writeLines, frames);
		} else if(args[3].toLowerCase().equals("clock")) {
			clock(writeLines, frames);
		} else if(args[3].toLowerCase().equals("lru")) {
			lru(writeLines, frames);
		} else if(args[3].toLowerCase().equals("nfu")) {
			nfu(writeLines, frames);
		} else {
			System.out.println("Invalid arguments: " + args[3]);
			return;
		}
		System.out.println("Algorithm: " + args[3]);
		System.out.println("Number of frames: " + frames);
		System.out.println("Total memory accesses: " + accesses);
		System.out.println("Total page faults: " + faults);
		System.out.println("Total writes to disk: " + writes);
		System.out.println("Total size of page table: " + totalSize + " bytes");
	}

	static String predict(List<String[]> lines, HashSet<String> pgs, int index) {
		String res = "";
		int farthest = index;
		for(String p : pgs) {
			int j = 0;
			for(j = index; j < lines.size(); j++) {
				if(p.equals(lines.get(j)[1])) {
					if(j > farthest) {
						farthest = j;
						res = p;
					}
					break;
				}
			}
			if(j == lines.size()) {
				return p;
			}
		}
		return res;
	}

	static void opt(List<String[]> lines, int f) {
		HashSet<String> pgs = new HashSet<>();
		for(int i = 0; i < lines.size(); i++) {
			if(pgs.contains(lines.get(i)[1])) {
				writes++;
				continue;
			}
			if(pgs.size() < f) {
				pgs.add(lines.get(i)[1]);
				faults++;
			} else {
				String j = predict(lines, pgs, i + 1);
				pgs.remove(j);
				pgs.add(lines.get(i)[1]);
				faults++;
			}
		}
	}

	static void clock(List<String[]> lines, int f) {
		int p = 0;
		ArrayList<String> pgs = new ArrayList<String>();
		ArrayList<Boolean> bools = new ArrayList<Boolean>();
		for(String[] pg : lines) {
			if(pgs.contains(pg[1])) {
				bools.set(pgs.indexOf(pg[1]), true);
				writes++;
			} else {
				if(pgs.size() < f) {
					pgs.add(pg[1]);
					bools.add(false);
				}
				while(true) {
					if(bools.get(p)) {
						bools.set(p, false);
					} else {
						pgs.set(p, pg[1]);
						break;
					}
					p = (p + 1) % f;
				}
				p = (p + 1) % f;
				faults++;
			}
		}
	}

	static void lru(List<String[]> lines, int f) {
	        ArrayList<String> stack = new ArrayList<>(f);
	        for(String[] i : lines) {
	            	if(!stack.contains(i[1])) { 
	            		if(stack.size() == f) {
			                stack.remove(0);
	        		        stack.add(f-1,i[1]);
	        		} else {
	                		stack.add(i[1]);
				}
	                	faults++;
	            	} else {
	                	stack.remove(i[1]);
	                	stack.add(i[1]);
				writes++;
	            	}
	        }
	}

	static void nfu(List<String[]> lines, int f) {
		ArrayList<String> stack = new ArrayList<>(f);
                for(String[] i : lines) {
                        if(!stack.contains(i[1])) {
                                if(stack.size() == f) {
                                        stack.remove(new Random().nextInt(stack.size()));
                                        stack.add(f-1,i[1]);
                                } else {
                                        stack.add(i[1]);
                                }
                                faults++;
                        } else {
                                stack.remove(i[1]);
                                stack.add(i[1]);
                                writes++;
                        }
                }
	}

}
