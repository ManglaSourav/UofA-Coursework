import java.util.Arrays;

/**
 * Keep a pointer on an array that points to the frame that was
 * loaded furthest back in time. It will be the candidate for eviction.
 * If its reference count is zero, it will be evicted and swapped out
 * with the new page taking its place. Otherwise, it's reference count
 * will be set to zero, so that the next time we see it, it will be evicted
 * if it hasn't been referenced since.
 */
public class ClockPageTable extends PageTable {
  int hand;
  int[] validPages; // mapping frame numbers to their inhabiting page

  public ClockPageTable(int numFrames) {
    super(numFrames);
    hand = 0;
    validPages = new int[numFrames];
    Arrays.fill(validPages, -1);
  }

  private void advanceHand() {
    hand = (hand + 1) % numFrames;
  }

  // starting from the oldest (by load, not reference),
  // scan for a page that has no references (gotten its second chance)
  // and evict it
  @Override
  int evict(int newPageNum) {
    int originalPos = hand;
    do {
      PageTableEntry oldPage = getEntry(validPages[hand]);
      if (oldPage.getReferences() == 0) {
        // replace the oldPage in the clock, with the page that's taking its place
        validPages[hand] = newPageNum;
        advanceHand();
        return oldPage.getFrame();
      } else {
        // give this page a second chance,
        // next time we reach it, if it hasn't been referenced, then evict it
        advanceHand();
        oldPage.resetReferences();
      }
    } while (hand != originalPos);

    return hand;
    // if there are no unreferenced pages, then evict the oldest referenced page
  }

  // routine to perform until there are no more frames to hand out.
  // logic for evicting page faults is in evict()
  @Override
  void onPageFaultNoEvict(int pageNum) {
    validPages[hand] = pageNum;
    advanceHand();
    // once frames are all handed out, hand will be 0
  }

  @Override
  void onAccess(int frameNumber) {
    // NOP
  }
}
