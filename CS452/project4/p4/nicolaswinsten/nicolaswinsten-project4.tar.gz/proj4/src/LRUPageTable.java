/**
 * Find the page that hasn't been accessed in the longest time for eviction
 */

public class LRUPageTable extends PageTable {
  Integer[] lastTimeFrameAccessed; // map frame numbers to the time they were accessed
  public LRUPageTable(int numFrames) {
    super(numFrames);
    lastTimeFrameAccessed = new Integer[numFrames];
  }

  // evict the page that was last accessed the longest time ago
  @Override
  int evict(int dummy) {
    int besti = 0;
    for (int i = 1; i < numFrames; i++) {
      besti = preferred(i, besti);
    }
    lastTimeFrameAccessed[besti] = numMemAccesses;
    return besti;
  }

  @Override
  void onPageFaultNoEvict(int pageNum) {
    // NOP
  }

  @Override
  void onAccess(int frameNumber) {
    lastTimeFrameAccessed[frameNumber] = numMemAccesses;
  }

  // return the frame we'd prefer to evict based on when it was last used
  private int preferred(int frame1, int frame2) {
    if (lastTimeFrameAccessed[frame1] < lastTimeFrameAccessed[frame2])
      return frame1;
    else return frame2;
  }
}
