/**
 * Find the page with the lowest reference count for eviction
 */

public class NFUPageTable extends PageTable {

  public NFUPageTable(int numFrames) {
    super(numFrames);
  }

  // scan for the page that has been referenced the least since
  // it has been loaded (preferring a non-dirty frame)
  @Override
  protected int evict(int dummy) {
    int besti = 0;
    for (int i = 1; i < numFrames; i++)
      besti = preferred(i, besti);
    return besti;
  }

  @Override
  void onPageFaultNoEvict(int pageNum) {
    // NOP
  }

  @Override
  void onAccess(int frameNumber) {
    // NOP
  }

  // return whether we'd prefer to evict frame1 over frame2
  private int preferred(int frame1, int frame2) {
    PageTableEntry page1 = getEntry(frameToPageNum[frame1]);
    PageTableEntry page2 = getEntry(frameToPageNum[frame2]);
    if (page1.getReferences() == page2.getReferences()) {
      // if both pages are have been used equally then pick page 1 if it is clean
      return page1.isDirty() ? frame2 : frame1;
    } else if (page1.getReferences() < page2.getReferences())
      return frame1;
    else return frame2;
    // otherwise pick page1's frame if it has been used less
  }
}
