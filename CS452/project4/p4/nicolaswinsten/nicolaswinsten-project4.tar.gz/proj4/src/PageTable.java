import java.util.*;

public abstract class PageTable {
  private int nextAvailableFrame = 0;
  protected int numMemAccesses = 0;
  private int numPageFaults = 0;
  private int numWritesToDisk = 0;
  PageTableEntry[] table; // map page numbers to PageTableEntries
  final int frameSize = 8192; // in bytes (8KB)
  final int pageTableSize = 524288; // number of pages 2^32 / frameSize
  Integer[] frameToPageNum; // map frameNumbers to the page number that is using it

  final int numFrames; // total number of page frames

  public PageTable(int numFrames) {
    this.numFrames = numFrames;
    table = new PageTableEntry[pageTableSize]; // 2^32 / 8000
    Arrays.setAll(table, n -> new PageTableEntry());
    frameToPageNum = new Integer[numFrames];
    Arrays.fill(frameToPageNum, null);
  }

  protected PageTableEntry getEntry(int pageNum) {
    return table[pageNum];
  }

  // update an entry's frame number (and update the inverse table's entry)
  protected void changeEntryFrame(int pageNum, int frameNumber) {
    // set the given page entry to the given frame number
    PageTableEntry entry = getEntry(pageNum);
    entry.setFrame(frameNumber);
    entry.setDirty(false);
    entry.resetReferences();

    // evict the page currently using that frame
    if (frameToPageNum[frameNumber] != null) {
      PageTableEntry evictedPage = getEntry(frameToPageNum[frameNumber]);
      evictedPage.setValid(false);
    }

    // mark that this frameNumber is being used
    frameToPageNum[frameNumber] = pageNum;
  }

  // return the preferred frame number to evict
  abstract int evict(int newPageNum);

  // take action depending when a pageFault occurs when accessing the given virtual page
  // and when there is a frame available
  // (only used by ClockPageTable)
  abstract void onPageFaultNoEvict(int pageNum);

  // action taken when a certain page frame is accessed
  abstract void onAccess(int frameNumber);

  final void handle(MemAccess action) {
    numMemAccesses++;
    if (action.type() == Instr.MODIFY) numMemAccesses++; // M instructions count as a LOAD + STORE
    int pageNum = toPageNum(action.vaddr());
    PageTableEntry entry = getEntry(pageNum);
    boolean isRamFull = nextAvailableFrame == numFrames;
    if (entry.isValid()) { // hit, no page fault
      System.out.println("hit");
    } else if (!isRamFull) { // page fault without eviction
      System.out.println("page fault - no eviction");
      numPageFaults++;
      onPageFaultNoEvict(pageNum);
      // just assign the next available frame to this entry
      changeEntryFrame(pageNum, nextAvailableFrame);
      nextAvailableFrame++;
    } else { // page fault with eviction and maybe write evicted frame to disk
      numPageFaults++;
      if (entry.isDirty()) {
        numWritesToDisk++;
        System.out.println("page fault - evict dirty");
      } else System.out.println("page fault - evict clean");
      int evictedFrame = evict(pageNum);
      changeEntryFrame(pageNum, evictedFrame);
    }
    if (!entry.isDirty()) entry.setDirty(action.type().isDirty());
    entry.setValid(true);
    entry.incReferences();
    onAccess(entry.getFrame());
  }

  // cast the virtualAddr memory to an index in the page table
  final protected int toPageNum(long virtualAddr) {
    return (int)(virtualAddr >> 13); // page size is 8KB
  }

  final public void printState() {
    System.out.println("Number of frames: " + numFrames);
    System.out.println("Total memory accesses: " + numMemAccesses);
    System.out.println("Total page faults: " + numPageFaults);
    System.out.println("Total writes to disk: " + numWritesToDisk);
    System.out.printf("Total size of page table: %d bytes\n",
            pageTableSize*10 + numFrames*4);
    // number of page entries * size of entry
    // number of frames * sizeof(int) for mapping frames to their current page
  }
}
