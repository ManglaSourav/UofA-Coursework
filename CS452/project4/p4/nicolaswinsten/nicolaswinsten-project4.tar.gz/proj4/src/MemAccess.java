public record MemAccess (Instr type, long vaddr, int size) {}
