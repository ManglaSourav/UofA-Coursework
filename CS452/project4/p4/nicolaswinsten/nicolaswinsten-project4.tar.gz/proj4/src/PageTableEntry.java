public class PageTableEntry {
  public int getReferences() {
    return references;
  }

  public boolean isDirty() {
    return dirty;
  }

  public boolean isValid() {
    return valid;
  }

  public int getFrame() {
    return frame;
  }

  public void resetReferences() {
    this.references = 0;
  }

  public void incReferences() {
    this.references++;
  }

  public void setDirty(boolean dirty) {
    this.dirty = dirty;
  }

  public void setValid(boolean valid) {
    this.valid = valid;
  }

  public void setFrame(int frame) {
    this.frame = frame;
  }

  private int references;
  private boolean dirty;
  private boolean valid;
  private int frame;
  public PageTableEntry() {
    valid = false;
    references = 0;
    dirty = false;
    frame = -1;
  }
}
