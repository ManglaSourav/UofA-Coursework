public enum Instr {
  LOAD, MODIFY, STORE, FETCH;

  public boolean isDirty() {
    return this == MODIFY || this == STORE;
  }
}
