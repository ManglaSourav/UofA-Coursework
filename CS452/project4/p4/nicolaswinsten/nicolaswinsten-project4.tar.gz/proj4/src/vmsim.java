import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class vmsim {
    // get the argument that immediately follows the given arg
    static private Optional<String> getopt(String opt, String[] args) {
        int i = Arrays.asList(args).indexOf(opt);
        if (i == -1 || i == args.length - 1) return Optional.empty();
        return Optional.of(args[i+1]);
    }

    static private Optional<Long> parseHex(String str) {
        try {
            return Optional.of(Long.decode(str));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    static private Optional<Integer> parseInt(String str) {
        try {
            return Optional.of(Integer.parseInt(str));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    private static final Pattern r = Pattern.compile("([ISLM])\\s+([ABCDEFabcdef\\d]{8}),(\\d+)");
    // parse a memory access line in the trace file to MemAccess record
    static private Optional<MemAccess> toMemAccess(String line) {
        Matcher m = r.matcher(line.strip());
        if (m.matches()) {
            Optional<Instr> type = Optional.ofNullable(
                switch(m.group(1)) {
                    case "I" -> Instr.FETCH;
                    case "S" -> Instr.STORE;
                    case "L" -> Instr.LOAD;
                    case "M" -> Instr.MODIFY;
                    default -> null;
                }
            );
            Optional<Long> vaddr = parseHex("0x" + m.group(2));
            Optional<Integer> size = parseInt(m.group(3));
            if (type.isEmpty() || vaddr.isEmpty() || size.isEmpty()) return Optional.empty();
            return Optional.of(new MemAccess(type.get(), vaddr.get(), size.get()));
        } else return Optional.empty();
    }

    private static IllegalArgumentException cliError() {
        System.out.println("Expected use:");
        System.out.println("java vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
        return new IllegalArgumentException();
    }

    public static void main(String[] args) throws FileNotFoundException {
        int numFrames = getopt("-n", args).flatMap(vmsim::parseInt).orElseThrow(vmsim::cliError);
        String algo = getopt("-a", args).orElseThrow(vmsim::cliError);
        if (args.length != 5) throw cliError();
        String traceFilename = args[args.length - 1]; // last arg should be trace file

        BufferedReader reader = new BufferedReader(new FileReader(traceFilename));
        List<MemAccess> memAccesses = reader.lines().map(vmsim::toMemAccess)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .toList();

        PageTable pageTable = switch (algo) {
            case "opt" -> new OptPageTable(numFrames, new ArrayList<>(memAccesses));
            case "lru" -> new LRUPageTable(numFrames);
            case "nfu" -> new NFUPageTable(numFrames);
            case "clock" -> new ClockPageTable(numFrames);
            default -> throw cliError();
        };

        memAccesses.forEach(pageTable::handle);

        System.out.println("Algorithm: " + algo);
        pageTable.printState();
    }
}
