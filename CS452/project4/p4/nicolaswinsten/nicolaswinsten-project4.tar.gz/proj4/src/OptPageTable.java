import java.util.*;

/**
 * Evict the page that won't be used until furthest in the future
 */
public class OptPageTable extends PageTable {
  private int instrNumber;
  // map the pageNum to every time it will be referenced in the future
  private Map<Integer, Queue<Integer>> pageFutureReferences;


  // the optimum page replacement algorithm will evict a page that will never be used again
  // (or if no such page, then scan for the page that will not be used until furthest in the future)
  public OptPageTable(int numFrames, List<MemAccess> instrs) {
    super(numFrames);
    instrNumber = 0;
    // store all the times that each page is referenced
    pageFutureReferences = new HashMap<>();
    int i = 0;
    for (MemAccess ma: instrs) {
      Integer pageNum = toPageNum(ma.vaddr());
      if (!pageFutureReferences.containsKey(pageNum))
        pageFutureReferences.put(pageNum, new LinkedList<>(Collections.singleton(i)));
      Queue<Integer> refs = pageFutureReferences.get(pageNum);
      refs.add(i);
      i++;
    }
  }

  // inspect the currently used pages, and find one that won't be referenced again.
  // otherwise use the page that won't be referenced for the longest
  @Override
  int evict(int dummy) {
    int bestFrameSoFar = 0;
    for (int i = 0; i < frameToPageNum.length; i++) {
      Integer pageNum = frameToPageNum[i];
      Queue<Integer> refs = pageFutureReferences.get(pageNum);
      while(true) {
        if (refs.isEmpty())
          return i; // return this page's frame since it will never be referenced again
        if (refs.peek() <= instrNumber)
          refs.remove();
        else break;
      }
      bestFrameSoFar = preferred(bestFrameSoFar, i);
    }
    // return the frame that holds the page that won't be referenced until furthest in the future
    return bestFrameSoFar;
  }

  // returns the frame we'd prefer to evict
  // inspects the current page in each frame, and chooses based on
  // which page won't be referenced until the furthest in the future
  private int preferred(int frame1, int frame2) {
    Integer nextRef1 = pageFutureReferences.get(frameToPageNum[frame1]).peek();
    Integer nextRef2 = pageFutureReferences.get(frameToPageNum[frame2]).peek();
    if (nextRef1 == null) return frame1;
    else if (nextRef2 == null) return frame2;
    else if (nextRef1 > nextRef2) return frame1;
    else return frame2;
  }

  @Override
  void onPageFaultNoEvict(int pageNum) {
    // NOP
  }

  // track which instruction we're on
  @Override
  void onAccess(int frameNumber) {
    instrNumber++;
  }
}
