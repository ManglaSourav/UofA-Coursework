from collections import defaultdict
import sys
'''
Author: Austin Connick
File: vssim.py
Purpose: this program sims page replacement algorithms
         OPT, Clock, LRU, NFU
'''

#32-bit address space
#8kb page size
number_of_frames = 8
page_table_array = []
frame_array = []
table32 = []
frame_of_number = 8
'''
class used to show a entry in the page table
'''
class pageEntry:
    def __init__(self,dirty_bit,reference_bit,valid_bit,page_number,frame_number):
        self.dirty_bit = dirty_bit
        self.reference_bit =reference_bit
        self.valid_bit = valid_bit
        self.page_number = page_number
        self.frame_number = frame_number
    def set_dirty_bit(self, bit):
        self.dirty_bit = bit
    def set_reference(self, bit):
        self.reference_bit = bit
    def set_valid_bit(self, bit):
        self.valid_bit = bit
    def set_frame_number(self, bit):
        self.frame_number = bit
    def set_reference_bit(self, bit):
        self.reference_bit = bit

'''
build_file reads in a file and returns list of 
instruction type and address
'''
def build_file(trace):
    clean_file = []
    fp = open(trace)
    for i in fp:
        i = i.strip()
        k = i.split(" ")
        if k[0] == 'I' or k[0] == 'S' or k[0] == 'M' or k[0] == 'L':
            l = []
            #k = " ".join(k)
            #k = k.split(" ")
            l.append(k[0])
            if len(k) > 2:
                k.pop(1)
            o = k[1].split(",")
            l.append(o[0])
            clean_file.append(l)
    return clean_file
#nmber of pages = (2^32)/((2^3)*(2^10))
# each element * 4 for 32 bit address space
'''
build_page_table prefills a list with pageEntrys
with each entry 8kb in a 32 bit address space
''' 
def build_page_table():
    k = (2 ** 32) / ((2 ** 3) * (2 ** 10))
    for i in range(int(k)):
        page_table_array.append(pageEntry(0,0,0,i,-1))
#mmu
'''
find_page returns the index of a page in the page table
'''
def find_page(va):
    frame_number = -1
    x = int(va / ((2 ** 3) * (2 ** 10)))
    #offset
    #page = page_table_array[x]
    #find frame number
    return x
'''
prints end of program stats
'''
def print_stats(alg_name,num_of_frames,memory_acc,page_faults,writes,page_table_size):
    print("Algorithm: "+alg_name+"\nNumber of frames: "+str(num_of_frames)+"\nTotal memory accesses: "+str(memory_acc)+"\nTotal page faults: "+str(page_faults)+"\nTotal writes to disk: "+str(writes)+"\nTotal size of page table: "+str(page_table_size))
def build_frame(number_of_frames):
    for i in range(number_of_frames):
        frame_array.append(0)
'''
clock takes in a list created from the trace file and runs the clock
algorithm using a circle queue to hold frames
'''
def clock(instruct):
    # if the page is not in mem add to mem 
    memory_acc = 0
    page_faults = 0
    writes = 0
    page_table_size = 0
    alg_name = 'Clock'
    q_index = 0
    frame_buff = 0
    first_pages = 0
    Q = []
    frames = []
    used_page = {}
    for i in instruct:
        g = '0x'+ str(i[1])
        a = int(g,16)
        page = find_page(a)
        used_page[page] = 0
        if i[0] == "I": #read
            memory_acc += 1
        elif i[0] == "L": #mem acces
            memory_acc += 1
        elif i[0] == "S": #write
            memory_acc += 1
            the_page.dirty_bit = 1
        elif i[0] == "M": #both
            memory_acc += 1
            the_page.dirty_bit = 1
        the_page = page_table_array[page]
        if the_page.frame_number < 0: # if page is not loaded
            if len(Q) < number_of_frames:
                page_faults += 1
                the_page.set_frame_number(first_pages)
                Q.append(the_page)
                frames.append(the_page)
                first_pages += 1
                print("page fault - no eviction")
            else: #find page to remove
                page_faults += 1
                for k in range(len(Q)+1): 
                    if Q[q_index].reference_bit == 1:
                        Q[q_index].set_reference_bit(0)
                        if q_index >= number_of_frames - 1:
                            q_index = 0
                        else: 
                            q_index += 1
                    elif Q[q_index].reference_bit == 0:
                        the_page.set_frame_number(Q[q_index].frame_number)
                        Q[q_index].set_frame_number(-1)
                        Q[q_index] = the_page
                        if q_index >= number_of_frames - 1:
                            q_index = 0
                        else: 
                            q_index += 1
                        break
                    
                    if the_page.dirty_bit == 1:
                        writes += 1
                        the_page.set_dirty_bit(0)
                        print("page fault - evict dirty")
                    else:
                        print("page fault - evict clean")
        else: #page is loaded
            for o in Q:
                if o == the_page:
                    o.set_reference_bit(1)
                    break       
                
    page_table_size = len(used_page.keys()) * 8192
    print_stats(alg_name,number_of_frames,memory_acc,page_faults,writes,page_table_size)
'''
LRU takes in a list of created from the trace file
and runs the LRU algorithm using queue to evict 
the least recently used frame
'''
def LRU(instruct):
    memory_acc = 0
    page_faults = 0
    writes = 0
    page_table_size = 0
    alg_name = 'LRU'
    first_pages = 0
    Q = []
    frames = []
    used_page = {}
    for i in instruct:
        g = '0x'+ str(i[1])
        a = int(g,16)
        page = find_page(a)
        used_page[page] = 0
        the_page = page_table_array[page]
        if i[0] == "I": #read
            afa =1
            memory_acc += 1
        elif i[0] == "L": #mem acces
            memory_acc += 1
        elif i[0] == "S": #write
            memory_acc += 1
            the_page.dirty_bit = 1
        elif i[0] == "M": #both
            memory_acc += 1
            the_page.dirty_bit = 1
        if the_page.frame_number < 0: # if page is not loaded
            if len(Q) < number_of_frames:
               page_faults += 1
               the_page.set_frame_number(first_pages)
               Q.append(the_page)
               frames.append(the_page)
               first_pages += 1
               print("page fault - no eviction")
            else: #no room in starting frame must remove one
                page_faults += 1
                least_used_page = Q.pop(0)
                frames[least_used_page.frame_number] = the_page #add page to old pages slot
                the_page.set_frame_number(least_used_page.frame_number)
                Q.append(the_page) #push page onto q
                least_used_page.set_frame_number(-1) # remove frame slot
                if least_used_page.dirty_bit == 1:
                    writes += 1
                    least_used_page.set_dirty_bit(0)
                    print("page fault - evict dirty")
                else:
                    print("page fault - evict clean")
        elif the_page.frame_number >= 0: # the page is loaded
                index = Q.index(the_page)
                Q.pop(index)
                Q.append(the_page)
                print("hit")
    page_table_size = len(used_page.keys()) * 8192
    print_stats(alg_name,number_of_frames,memory_acc,page_faults,writes,page_table_size)

'''
NFU takes in a list created from the trace file
and runs the nfu evict the page with the lowest refernce count
'''
def NFU(instruct):
    memory_acc = 0
    page_faults = 0
    writes = 0
    page_table_size = 0
    alg_name = 'NFU'
    first_frame = 0
    first_pages = 0
    used_page = {}
    frames = []
    for i in instruct:
        g = '0x'+ str(i[1])
        a = int(g,16)
        page = find_page(a)
        used_page[page] = 0
        the_page = page_table_array[page]
        if i[0] == "I": #read
            afa = 1
            memory_acc += 1
        elif i[0] == "L": #mem acces
            memory_acc += 1
        elif i[0] == "S": #write
            memory_acc += 1
            the_page.dirty_bit = 1
        elif i[0] == "M": #both
            memory_acc += 1
            the_page.dirty_bit = 1
        if the_page.frame_number < 0: #if page is not loaded
            if len(frames) < number_of_frames:#if frames has a open slot
                page_faults += 1
                the_page.set_frame_number(first_pages)
                #print(the_page.frame_number)
                cur_bit = the_page.reference_bit
                new_bit = cur_bit + 1
                the_page.set_reference_bit(new_bit)#increment referenced count
                frames.append(the_page)
                first_pages += 1
                print("page fault - no eviction")
            else: # no slote must remove page
                page_faults += 1
                page_to_remove = frames[0]
                #print(the_page.frame_number)
                for k in frames:
                    if page_to_remove.reference_bit > k.reference_bit:
                        page_to_remove = k
                if page_to_remove.dirty_bit == 1:
                    writes += 1
                    page_to_remove.set_dirty_bit(0)
                    print("page fault - evict dirty")
                else:
                    print("page fault - evict clean")
                the_page.set_frame_number(page_to_remove.frame_number)
                frames[page_to_remove.frame_number] = the_page
                page_to_remove.set_frame_number(-1)
                page_to_remove.set_reference_bit(0)
        else: #the page is loaded
            cur_bit = the_page.reference_bit # update ref bit
            new_bit = cur_bit + 1
            the_page.set_reference_bit(new_bit)
            print("hit")
    page_table_size = len(used_page.keys()) * (2 ** 13)
    print_stats(alg_name,number_of_frames,memory_acc,page_faults,writes,page_table_size)
'''
OPT takes in a list created from the trace file
and runs runs the opt algorithm, opt first uses a map
of page number maped to all point they are used in the future
it then find the frame refrence farthest in the future to remove
'''
def OPT(instruct):
    memory_acc = 0
    page_faults = 0
    writes = 0
    page_table_size = 0
    alg_name = 'OPT'
    first_frame = 0
    first_pages = 0
    frames = []
    the_future = {}
    time_in_the_future = 0
    the_future = defaultdict(list)
    for w in instruct:
        g = '0x'+ str(w[1])
        a = int(g,16)
        page = find_page(a)
        the_future[page].append(time_in_the_future)
        time_in_the_future += 1 
    cur_location = 0
    for i in instruct:
        
        g = '0x'+ str(i[1])
        a = int(g,16)
        page = find_page(a)
        the_page = page_table_array[page]
        if the_page.frame_number < 0: #if page is not loaded
            if len(frames) < number_of_frames:#if frames has a open slot
                page_faults += 1
                the_page.set_frame_number(first_pages)
                frames.append(the_page)
                first_pages += 1
                print("page fault - no eviction")
                if i[0] == "I": #read
                    memory_acc += 1
                elif i[0] == "L": #mem acces
                    memory_acc += 1
                elif i[0] == "S": #write
                    memory_acc += 1
                    the_page.dirty_bit = 1
                elif i[0] == "M": #both
                    memory_acc += 1
                    the_page.dirty_bit = 1
            else: #find page to remove
                #find farthest in the future
                page_faults += 1
                page_to_remove = frames[0]
                page_to_remove_last = 0
                for h in frames:
                    if not the_future[h.page_number]: #page is never used
                        page_to_remove = h
                        break
                    else:
                        for u in range(len(the_future[h.page_number])):
                            if the_future[h.page_number][0] <= cur_location:
                                del the_future[h.page_number][0]
                            else:
                                break
                    if not the_future[h.page_number]: #page is never used
                        page_to_remove = h
                        break
                    elif the_future[h.page_number][0] > page_to_remove_last:
                        page_to_remove = h
                        page_to_remove_last = the_future[h.page_number][0]
                if page_to_remove.dirty_bit == 1:
                    writes += 1
                    page_to_remove.set_dirty_bit(0)
                    print("page fault - evict dirty")
                else:
                    print("page fault - evict clean")
                the_page.set_frame_number(page_to_remove.frame_number)
                frames[page_to_remove.frame_number] = the_page
                page_to_remove.set_frame_number(-1)
                if i[0] == "I": #read
                    memory_acc += 1
                elif i[0] == "L": #mem acces
                    memory_acc += 1
                elif i[0] == "S": #write
                    memory_acc += 1
                    the_page.dirty_bit = 1
                elif i[0] == "M": #both
                    memory_acc += 1
                    the_page.dirty_bit = 1
        else: #page is loaded
            print("hit")
            if i[0] == "I": #read
                memory_acc += 1
            elif i[0] == "L": #mem acces
                memory_acc += 1
            elif i[0] == "S": #write
                memory_acc += 1
                the_page.dirty_bit = 1
            elif i[0] == "M": #both
                memory_acc += 1
                the_page.dirty_bit = 1
        cur_location += 1
    page_table_size = len(the_future.keys()) * 8192
    print_stats(alg_name,number_of_frames,memory_acc,page_faults,writes,page_table_size)
'''
main reads in command line args 
and prefills pagetable and starts the algorithm
indicated by the command and sets the frame size 
'''
def main():
    
    argl = len(sys.argv)
    arg = sys.argv
    if argl < 6:
        print("invalid commands")
        exit(-1)
    if arg[1] == '-n':
        global number_of_frames 
        number_of_frames = int(arg[2])
        if arg[3] == '-a':
            if arg[4] == 'opt':
                a = build_file(arg[5])
                build_page_table()
                OPT(a)
            elif arg[4] == 'clock':
                a = build_file(arg[5])
                build_page_table()
                clock(a)
            elif arg[4] == 'lru':
                a = build_file(arg[5])
                build_page_table()
                LRU(a)
            elif arg[4] == 'nfu':
                a = build_file(arg[5])
                build_page_table()
                NFU(a)
            else:
                print('invalid algorithm name')
                exit(-1)
if __name__=="__main__":
    main()
