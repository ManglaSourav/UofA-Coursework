import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class vmsim {
	private static List<Character> basicDataCommand = Arrays.asList(new Character[] { 'I', 'M', 'S', 'L' });
	private static int TABLE_SIZE = (int) Math.pow(2, 32 - 11);
	private static int PAGE_SIZE = 2048;
	private static int PAGE_ENTRY_SIZE = 4;
	private static int memoryAccess = 0;
	private static int pageFault = 0;
	private static int writeToDisk = 0;

	static class PageTableEntry {
		boolean dirty;
		boolean valid;
		boolean ref;
		int frame;

		public PageTableEntry() {
			this.dirty = false;
			this.valid = false;
			this.ref = true;
			this.frame = -1;
		}

		public void evict() {
			this.dirty = false;
			this.valid = false;
			this.ref = true;
			this.frame = -1;
		}
	}

	public static void main(String[] args) {
		PageTableEntry[] pageTable = new PageTableEntry[TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; i++) {
			pageTable[i] = new PageTableEntry();
		}
		if (args.length != 5 || !args[0].equals("-n") || !args[2].equals("-a")) {
			System.out.println("Invalid Inputs!");
			System.exit(1);
		}
		int frames = 0;
		try {
			frames = Integer.parseInt(args[1]);
		} catch (NumberFormatException nfe) {
			System.out.println("Invalid Inputs!");
			System.exit(1);
		}

		String algorithm = args[3];
		Scanner input = null;
		try {
			input = new Scanner(new File(args[4]));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		int[] memory = new int[frames];
		switch (algorithm) {
		case "opt":
			opt(input, pageTable, memory, frames);
			break;
		case "clock":
			clock(input, pageTable, memory, frames);
			break;
		case "lru":
			lru(input, pageTable, memory, frames);
			break;
		case "nfu":
			nfu(input, pageTable, memory, frames);
			break;
		default:
			System.out.println("Invalid Inputs!");
			System.exit(1);
		}
		System.out.printf(
				"Algorithm: %s\n" + "Number of frames: %d\n" + "Total memory accesses: %d\n" + "Total page faults: %d\n"
						+ "Total writes to disk: %d\n" + "Total size of page table: %d bytes\n",
				algorithm, frames, memoryAccess, pageFault, writeToDisk, TABLE_SIZE * PAGE_ENTRY_SIZE);
	}

	private static void processOperation(PageTableEntry entry, String operation) {
		if (operation.equals("M")) {
			entry.dirty = true;
			memoryAccess += 2;
		} else {
			memoryAccess++;
			if (operation.equals("S")) {
				entry.dirty = true;
			}
		}
	}

	private static void opt(Scanner input, PageTableEntry[] pageTable, int[] ram, int frames) {
		int pageSoFar = 0;
		int oldestIndex = 0;
		HashMap<Integer, TreeSet<Integer>> pageMap = new HashMap<Integer, TreeSet<Integer>>();
		ArrayList<Object[]> pageList = new ArrayList<Object[]>();
		int temp = 1;
		while (input.hasNextLine()) {
			String line = input.nextLine();
			if (line.length() == 0 || !(basicDataCommand.contains(line.charAt(0)))) {
				continue;
			}
			String[] command = line.split("\\s+|,");
			String operation = command[0];
			long address = Long.parseLong(command[1], 16);
			int tableIndex = (int) (address / PAGE_SIZE);
			if (pageMap.get(tableIndex) == null) {
				pageMap.put(tableIndex, new TreeSet<Integer>());
			}
			pageMap.get(tableIndex).add(temp);
			pageList.add(new Object[] { tableIndex, operation, line });
			temp++;
		}
		input.close();
		temp = 1;
		for (Object[] step : pageList) {
			int tableIndex = (int) step[0];
			String operation = (String) step[1];
			String line = (String) step[2];
			PageTableEntry entry = pageTable[tableIndex];
			if (entry.valid) {
				System.out.println(line + " hit");
				entry.ref = true; 
			} else {
				pageFault++;
				if (pageSoFar >= frames) { 
					int pageFarthest = -1;
					int maximum = -1;
					for (int page : ram) {
						int next;
						if (pageMap.get(page).isEmpty()) {
							next = -1;
							break;
						} else {
							next = pageMap.get(page).first();
							while (next <= temp) {
								pageMap.get(page).remove(next);
								if (pageMap.get(page).isEmpty()) {
									next = -1;
									break;
								} else {
									next = pageMap.get(page).first();
								}
							}
						}
						if (next == -1) { 
							pageFarthest = page;
							break;
						}
						if (next > maximum) {
							pageFarthest = page;
							maximum = next;
						}
					}
					PageTableEntry entryEvict;
					if (pageFarthest == -1) {
						entryEvict = pageTable[ram[0]];
					} else {
						entryEvict = pageTable[pageFarthest];
					}
					entry.frame = entryEvict.frame;
					entry.valid = true;
					if (entryEvict.dirty) {
						writeToDisk++;
						System.out.println(line + " (page fault - evict dirty)");
					} else {
						System.out.println(line + " (page fault - evict clean)");
					}
					entryEvict.evict();
					ram[entry.frame] = tableIndex;
				} else { 
					System.out.println(line + " (page fault - no eviction)");
					entry.valid = true;
					entry.frame = pageSoFar;
					ram[pageSoFar] = tableIndex;
					pageSoFar++;
				}
			}
			processOperation(entry, operation);
			temp++;
		}

	}

	private static void clock(Scanner input, PageTableEntry[] pageTable, int[] ram, int frames) {
		int pageSoFar = 0;
		int oldestIndex = 0;
		while (input.hasNextLine()) {
			String line = input.nextLine();
			if (line.length() == 0 || !(basicDataCommand.contains(line.charAt(0)))) {
				continue;
			}
			String[] command = line.split("\\s+|,");
			String operation = command[0];
			long address = Long.parseLong(command[1], 16);
			int tableIndex = (int) (address / PAGE_SIZE);
			PageTableEntry entry = pageTable[tableIndex];
			if (entry.valid) {
				System.out.println(line + " hit");
				entry.ref = true; 
			} else {
				pageFault++;
				if (pageSoFar >= frames) { 
					int indexEvict = ram[oldestIndex];
					PageTableEntry entryEvict = pageTable[indexEvict];
					while (entryEvict.ref) {
						entryEvict.ref = false;
						oldestIndex++;
						if (oldestIndex >= ram.length) {
							oldestIndex = 0;
						}
						indexEvict = ram[oldestIndex];
						entryEvict = pageTable[indexEvict];
					}
					entry.frame = entryEvict.frame;
					entry.valid = true;
					if (entryEvict.dirty) {
						writeToDisk++;
						System.out.println(line + " (page fault - evict dirty)");
					} else {
						System.out.println(line + " (page fault - evict clean)");
					}
					entryEvict.evict();
					ram[oldestIndex] = tableIndex;
					oldestIndex++;
					if (oldestIndex >= ram.length) {
						oldestIndex = 0;
					}
				} else { 
					System.out.println(line + " (page fault - no eviction)");
					entry.valid = true;
					entry.frame = pageSoFar;
					ram[pageSoFar] = tableIndex;
					pageSoFar++;
				}
			}
			processOperation(entry, operation);
		}
		input.close();
	}

	private static void lru(Scanner input, PageTableEntry[] pageTable, int[] ram, int frames) {
		int pageSoFar = 0;
		int oldestIndex = 0;
		ArrayList<Integer> lru = new ArrayList<>(frames);
		int count = 0;
		while (input.hasNextLine()) {
			String line = input.nextLine();
			if (line.length() == 0 || !(basicDataCommand.contains(line.charAt(0)))) {
				continue;
			}
			String[] command = line.split("\\s+|,");
			String operation = command[0];
			long address = Long.parseLong(command[1], 16);
			int tableIndex = (int) (address / PAGE_SIZE);
			PageTableEntry entry = pageTable[tableIndex];
			if (entry.valid) {
				System.out.println(line + " hit");
			} else {
				pageFault++;
				if (pageSoFar >= frames) { 
					int indexEvict;
					if (!lru.contains(tableIndex)) {
						if (lru.size() == frames) {
							indexEvict = lru.get(0);
							oldestIndex = frames-1;
							lru.remove(0);
							lru.add(frames-1, tableIndex);
						} else {
							indexEvict = -1;
							oldestIndex = count;
							lru.add(count, tableIndex);
							++count;
						}
					} else {
						indexEvict = tableIndex;
						lru.remove((Object) tableIndex);
						oldestIndex = lru.size();
						lru.add(lru.size(), tableIndex);
					}
					if (indexEvict == -1) {
						continue;
					}
					PageTableEntry entryEvict = pageTable[indexEvict];
					entry.frame = entryEvict.frame;
					entry.valid = true;
					if (entryEvict.dirty) {
						writeToDisk++;
						System.out.println(line + " (page fault - evict dirty)");
					} else {
						System.out.println(line + " (page fault - evict clean)");
					}
					entryEvict.evict();
					ram[oldestIndex] = tableIndex;
				} else { 
					System.out.println(line + " (page fault - no eviction)");
					entry.valid = true;
					entry.frame = pageSoFar;
					ram[pageSoFar] = tableIndex;
					pageSoFar++;
				}
			}	
			processOperation(entry, operation);
		}
		input.close();
	}

	private static void nfu(Scanner input, PageTableEntry[] pageTable, int[] ram, int frames) {
		int pageSoFar = 0;
		while (input.hasNextLine()) {
			String line = input.nextLine();
			if (line.length() == 0 || !(basicDataCommand.contains(line.charAt(0)))) {
				continue;
			}
			String[] command = line.split("\\s+|,");
			String operation = command[0];
			long address = Long.parseLong(command[1], 16);
			int tableIndex = (int) (address / PAGE_SIZE);
			PageTableEntry entry = pageTable[tableIndex];
			if (entry.valid) {
				System.out.println(line + " hit");
			} else {
				if (pageSoFar >= frames) {

				} else { 
					System.out.println(line + " (page fault - no eviction)");
					entry.valid = true;
					entry.frame = pageSoFar;
					ram[pageSoFar] = tableIndex;
					pageSoFar++;
					pageFault++;
				}
			}
			processOperation(entry, operation);
		}
		input.close();
	}
}