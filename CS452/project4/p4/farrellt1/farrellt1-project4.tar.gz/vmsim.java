/**
 * Author: Tristan Farrell
 * Course: CSC 452 - Operating Systems
 * Description: This program simulates a page replacement algorithm 
 * which is usually handled by the Operating System. We test four different
 * algorithms so we can compare the results.
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class vmsim {
    public static int writes = 0;
    public static int faults = 0;
    /**
     * The main file checks the console arugments and then calls the
     * corresponding algorithm and prints the summary statistics.
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException{
        if(args.length < 5){
            System.out.println("Missing Arguments");
            return;
        }

        String nflag     = args[0];
        String frames    = args[1];
        String aflag     = args[2];
        String algo      = args[3].toLowerCase();
        String tracefile = args[4];
        Integer numframes;
        BufferedReader file;

        if(!nflag.equals("-n")){
            System.out.println("Missing -n flag");
            return;
        }
        try{
            numframes = Integer.parseInt(frames);
        }catch(NumberFormatException e){
            System.out.println("Invalid frame number input");
            return;
        }
        if(!aflag.equals("-a")){
            System.out.println("Missing -a flag");
            return;
        }else if(!algo.equals("opt") && !algo.equals("clock") && !algo.equals("lru") && !algo.equals("nfu")){
            System.out.println("Invalid Algorithm choice: "+algo);
            return;
        }
        try{
            file = new BufferedReader(new FileReader(tracefile));
        }catch (IOException e){
            System.out.println("File Not Found!");
            return;
        }

        ArrayList<String> pages = new ArrayList<String>();
        int totalSize = 0;
        int accesses = 0;

        while(true){
            String line = file.readLine();
            if(line == null){
                break;
            }

            String[] elems = line.trim().split("\\s+|\\,");
            if(elems.length == 3 && (elems[0].equals("I") || elems[0].equals("L") || elems[0].equals("S") || elems[0].equals("M"))){
                totalSize += Integer.parseInt(elems[2]);
                accesses += 1;
                if(elems[0].equals("M")){
                    accesses+=1;
                }
                if(elems[0].equals("S") || elems[0].equals("M")){
                    pages.add(elems[1]);
                }
            }
        }
        file.close();
        if(algo.equals("opt")){
            opt(pages, numframes);
        }
        else if(algo.equals("clock")){
            clock(pages, numframes);
        }
        else if(algo.equals("lru")){
            lru(pages, numframes);
        }
        else if(algo.equals("nfu")){
            nfu(pages, numframes);
        }
        System.out.printf("Algorithm: %s\n", algo);
        System.out.printf("Number of frames: %d\n", numframes);
        System.out.printf("Total memory accesses: %d\n", accesses);
        System.out.printf("Total page faults: %d\n", faults);
        System.out.printf("Total writes to disk: %d\n", writes);
        System.out.printf("Total size of page table: %d bytes\n", totalSize);
    }
    
    /**
     * This is the function to predict which page to replace
     * @param pages array list of strings all pages from tracefile
     * @param frame hash set of the current frame
     * @param index index of the current page
     * @return a string of the page to be replaced
     */
    public static String predict(ArrayList<String> pages, 
        HashSet<String> frame, int index){
        String res = "";
        int far = index;
        for(String f: frame){
            int j;
            for(j = index; j<pages.size(); j++){
                if(f.equals(pages.get(j))){
                    if(j > far){
                        far = j;
                        res = f;
                    }
                    break;
                }
            }
            if(j == pages.size()){
                return f;
            }
        }
        return res;

    }

    /**
     * This is the optimal (OPT) page replacement algorithm
     * @param pages array list of strings all pages from tracefile
     * @param numframes and int of number of frames
     */
    public static void opt(ArrayList<String> pages, int numframes){
        HashSet<String> frame = new HashSet<>();
        for(int i=0; i<pages.size(); i++){
            if(frame.contains(pages.get(i))){
                writes++;
                System.out.println(pages.get(i)+" - hit");
                continue;
            }
            if(frame.size() < numframes){
                frame.add(pages.get(i));
                System.out.println(pages.get(i)+" - page fault - no eviction");
                faults++;
            }else{
                String j = predict(pages, frame, i+1);
                frame.remove(j);
                frame.add(pages.get(i));
                System.out.println(pages.get(i)+" - page fault - evict drity");
                faults++;
            }
        }
    }

    /**
     * This is the least recently used (LRU) page replacement algorithm
     * @param pages array list of strings all pages from tracefile
     * @param numframes and int of number of frames
     */
    public static void lru(ArrayList<String> pages, int numframes){
        ArrayList<String> frame = new ArrayList<String>();
        for(String pg : pages){
            if(!frame.contains(pg)){
                if(frame.size() == numframes){
                    frame.remove(0);
                    frame.add(pg);
                    System.out.println(pg+" - page fault - evict drity");
                }else{
                    frame.add(pg);
                    System.out.println(pg+" - page fault - no eviction");
                }
                faults++;
            }else{
                frame.remove(pg);
                frame.add(pg);
                writes++;
                System.out.println(pg+" - hit");
            }
        }
    }

    /**
     * This is the not frequently used (NRU) page replacement algorithm
     * @param pages array list of strings all pages from tracefile
     * @param numframes and int of number of frames
     */
    public static void nfu(ArrayList<String> pages, int numframes){
        HashMap<String, Integer> frequency = new HashMap<String, Integer>();
        for(String pg : pages){
            if(!frequency.containsKey(pg)){
                frequency.put(pg, 0);
            }
            frequency.replace(pg, frequency.get(pg)+1);
        }

        ArrayList<String> frame = new ArrayList<String>();
        for(String pg : pages){
            if(!frame.contains(pg)){
                if(frame.size() == numframes){
                    int val = 0;
                    String res = "";
                    for(String f : frame){
                        int freq = frequency.get(f);
                        if(freq < val || val == 0){
                            val = freq;
                            res = f;
                        }
                    }
                    frame.remove(res);
                    frame.add(pg);
                    System.out.println(pg+" - page fault - evict drity");
                }else{
                    frame.add(pg);
                    System.out.println(pg+" - page fault - no eviction");
                }
                faults++;
            }else{
                frame.remove(pg);
                frame.add(pg);
                writes++;
                System.out.println(pg+" - hit");
            }
        }
    }

    /**
     * This is the clock (second chance) page replacement algorithm
     * @param pages array list of strings all pages from tracefile
     * @param numframes and int of number of frames
     */
    public static void clock(ArrayList<String> pages, int numframes){
        String[] frame = new String[numframes];
        Arrays.fill(frame, "");
        boolean[] repeat = new boolean[numframes];
        int ptr = 0;
        for(int i=0; i<pages.size(); i++){
            boolean replace = true;
            for(int j=0; j<numframes; j++){
                if(frame[j].equals(pages.get(i))){
                    repeat[j] = true;
                    replace = false;
                }
            }
            if(replace){
                while(true){
                    if(!repeat[ptr]){
                        if(frame[ptr].isEmpty()){
                            System.out.println(pages.get(i)+" - page fault - no eviction");
                        }else{
                            System.out.println(pages.get(i)+" - page fault - evict drity");
                        }
                        frame[ptr] = pages.get(i);
                        ptr = (ptr+1)%numframes;
                        break;
                    }
                    repeat[ptr] = false;
                    ptr = (ptr+1)%numframes;
                }
                faults++;
            }else{
                writes++;
                System.out.println(pages.get(i)+" - hit");
            }
        }
    }

}
