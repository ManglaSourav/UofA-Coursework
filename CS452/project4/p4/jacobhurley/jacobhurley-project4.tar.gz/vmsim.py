#!/usr/bin/env python3

import sys, getopt, re



# returns page number, using 13 because 2^13 = 8kb
def getPgNm(VA):
    return VA >> 13

# dont care about right now
def offset(Va, PgSz):
    return (VA & 0x00001FFF)

# physical address = (frame#*pageSize) + offset
def getPA(frameNum):
    return (frameNum << 13)

def getFrameNum(pageNum):
    return pageTable[pageNum]

def setFrameNum(pageNum, frame):
    global alg, pageTable, numFrames, frameList
    pageTable[pageNum] = [0,1,1,frame] # index 0 is dirty bit, index 1 is referenced bit, index 2 is valid bit, index 3 is frame number
    if(alg == "opt"):
        global optPgList, optIndex
        if(len(frameList) != 0):
            optPgList[frame] = pageNum
        else:
            optPgList[optIndex] = pageNum
    elif(alg == "clock"):
        global clockList, currentInd
        if(len(frameList) != 0):
            clockList[frame] = pageTable[pageNum]
        else:
            clockList[currentInd%numFrames] = pageTable[pageNum]
            currentInd+=1
    elif(alg == "lru"):
        global clockCycle, LRUList
        if(len(frameList) != 0):
            LRUList[frame] = pageTable[pageNum]
        else:
            LRUList.append(pageTable[pageNum])
    elif(alg == "nfu"):
        global nfuReplace, nfuList
        if(len(frameList) != 0):
            nfuList[frame] = pageTable[pageNum]
        else:
            nfuList[nfuReplace] = pageTable[pageNum]

def listSearch(tempList, value):
    for i in range(0,len(tempList)):
        if(i == value):
            return i
    return -1

def schedule(alg, pageNum):
    global numFrames, diskWrites
    if(alg == "opt"):
        global optPgList, Lines, optIndex
        tempArray = optPgList.copy()
        tempLineCounter = 0
        for line in Lines[lineNum+1:]:
            if(line[0] != "I" and line[1] != "S" and line[1] != "L" and line[1] != "M"):
                continue
            if(len(tempArray) == 1 or tempLineCounter == 50):
                break
            parse = re.split('\s|,', line)
            pageNum = getPgNm(int(parse[2],16))
            index = listSearch(tempArray,pageNum)
            if(index != -1):
                tempArray.pop(index)
            tempLineCounter+=1
        evict = pageTable[tempArray[0]]
        tempFrame = evict[3]
        if(evict[0] == 1):
            diskWrites += 1
            evict[0] = 0
        evict[2] = 0
        optIndex = optPgList.index(tempArray[0])
        setFrameNum(pageNum, tempFrame)
            
    elif(alg == "clock"):
        global currentInd, clockList
        tempFrame = 0
        while(clockList[currentInd%numFrames][1] == 1):
            clockList[currentInd%numFrames][1] = 0
            currentInd+=1
        tempFrame = clockList[currentInd%numFrames][3]
        if(clockList[currentInd%numFrames][0] == 1):
            diskWrites+=1 # if dirty we must write to disk
            clockList[currentInd%numFrames][0] = 0
        clockList[currentInd%numFrames][2] = 0
        setFrameNum(pageNum, tempFrame)
    elif(alg == "lru"):
        global clockCycle, LRUList
        evict = LRUList.pop(0)
        tempFrame = evict[3]
        if(evict[0] == 1):
            diskWrites += 1
            evict[0] = 0
        evict[2] = 0
        setFrameNum(pageNum, tempFrame)
    elif(alg == "nfu"):
        global nfuList, nfuReplace
        tempMax = (2 << 16)
        minIndex = 0
        for i in range(0,len(nfuList)):
            if(nfuList[i][1] < tempMax):
                tempMax = nfuList[i][i]
                minIndex = i
        evict = nfuList[minIndex]
        nfuReplace = minIndex
        tempFrame = evict[3]
        if(evict[0] == 1):
            diskWrites += 1
            evict[0] = 0
        evict[2] = 0
        setFrameNum(pageNum, tempFrame)

def main(argv):
    if(len(argv) < 5):
        return
    # total # of pages = VA size / page size
    totalPgs = 0xFFFFFFFF >> 13
    global pageTable
    global frame
    global currentInd
    global numFrames
    global memAcc, pageFaults, diskWrites, alg, clockCycle, frameList, nfuList, nfuReplace, optPgList, Lines, lineNum, optIndex
    nfuReplace = 0
    currentInd = 0
    pageTable = [None] * totalPgs
    pgTableSz = 4194304
    numFrames = int(argv[1]) # ram
    frameList = [*range(0,numFrames)]
    frame = 0
    alg = argv[3]
    global clockList, LRUList
    clockList = [None] * numFrames
    LRUList = [None] * numFrames
    nfuList = [None] * numFrames
    optPgList = [None] * numFrames
    file = argv[4]
    clockCycle = 0
    memAcc = 0
    pageFaults = 0
    diskWrites = 0
    file1 = open(file, 'r')
    Lines = file1.readlines()
    curPageNum = 0
    lineNum = 0
    for line in Lines:
        if(line[0] == "I" or line[1] == "S" or line[1] == "L" or line[1] == "M"):
            memAcc += 1
            if(line[1] == "M"):
                memAcc += 1
            parse = re.split('\s|,', line)
                                                    #print(parse[2]) # parse[2] is all virtual address spaces. parse[0] or parse[1] are instruction
            pageNum = getPgNm(int(parse[2],16))
            curPageNum = pageNum
            frameNum = getFrameNum(pageNum)
            if(frameNum == None and len(frameList) != 0):
                pageFaults+=1
                frame = frameList[0]
                setFrameNum(pageNum, frame)
                frameList.pop(0)
                if(line[1] == "M" or line[1] == "S"):
                    pageTable[pageNum][0] = 1
            elif(frameNum == None and len(frameList) == 0): # if all frames are used and VA is not in RAM
                pageFaults+=1
                schedule(alg, pageNum)
                if(line[1] == "M" or line[1] == "S"):
                    pageTable[pageNum][0] = 1
            elif(frameNum != None): # if instruction has been called before
                if(line[1] == "M" or line[1] == "S"):
                    frameNum[0] = 1
                if(frameNum[2] == 0):
                    pageFaults+=1 # VA is not loaded in Ram still and we must fetch it
                    schedule(alg, pageNum)
                else:
                    #if(alg == "lru"):
                        #temp = LRUList.pop(LRUList.index(frameNum))
                        #LRUList.append(temp)
                    if(alg != "nfu"):
                        frameNum[1] = 1
                    else:
                        frameNum[1] += 1
                    continue # VA is in RAM still and we must not do anything to use it
        lineNum +=1
        print(len(Lines) - lineNum)



    



    print("Algorithm: " + alg)
    print("Number of frames:\t" + str(numFrames))
    print("Total memory accesses:\t" + str(memAcc))
    print("Total page faults:\t" + str(pageFaults))
    print("Total writes to disk:\t" + str(diskWrites))
    print("Total size of page table:\t" + str(pgTableSz) + " bytes")
    file1.close()
    return




if __name__ == "__main__":
   main(sys.argv[1:])