/*
 *
 * @author: Oliver Lester
 * @description: This program will simulate virtual memory. It will do so by taking in a trace 
 * 	file, which contains many virtual addresses, and simulating the process of paging. There 
 * 	are four different page replacement algorithms with in the program. The main reason for
 * 	this is to compare the four's performance in comparison to one another.
 *
 * USAGE: java vmsim <numframes> -a <opt|clock|lru|nfu> <tracefile> 
 * 	(this is done after compiliation)
 *
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.lang.Math;

public class vmsim {

	private static ArrayList<String> arr;
	private static int[][] pte;
	private static int writes;
	
	/**
	 * This is one of the four paging algorithms. This one is OPT. With each page fault, the 
	 * 	the algorithm will pick the page in the frame that is referenced the furthest out
	 *	that is the page that will be replaced.
	 * It takes in one parameter, which is the number of frames
	 * It returns an int, which represents the number of page faults that occured.
	 */
	private static int opt(int buf) {
		int ret = 0;
		int[] frame = new int[buf];
		int in = 0;
		int max;
		long cur;
		int pageNum;
		boolean full = false;
		String curString;

		int pointer = 0;
		
		LinkedList<Integer>[] nextAccess = new LinkedList[arr.size()];

		for (int i = 0; i < pte.length; i++) {
			nextAccess[i] = new LinkedList<Integer>();
		}

		for (int i = 0; i < arr.size(); i++) {
			curString = arr.get(i);
			cur = Long.decode(curString);
			pageNum = (int) (cur/8192);
			
			nextAccess[pageNum].add(i);
		}

		while (in < arr.size()) {
			curString = arr.get(in);
			cur = Long.decode(curString);
			pageNum = (int) (cur/8192);
			
			nextAccess[pageNum].remove();
			if (pte[pageNum][0] == 0) {
				if (!full) {
					pte[pageNum][0] = 1;
					pte[pageNum][1] = pointer;
					pointer++;
					if (pointer == buf) {
						pointer = 0;
						full = true;
					}
				} else {
					 max = -1;
					 int temp;
					 for (int i = 0; i < buf; i++) {
						if (nextAccess[frame[i]].peek() != null) {
							temp = nextAccess[frame[i]].peek();
						} else {
							temp = Integer.MAX_VALUE;
						}
						 
						if (temp > max) {
							max = temp;
							pointer = i;
						}
				 }
					 pte[pageNum][0] = 1;
					 pte[pageNum][1] = pointer;
					 pte[frame[pointer]][0] = 0;
					 pte[frame[pointer]][1] = 0;
					 if (pte[frame[pointer]][2] == 1 ) {
						writes++;	
					 }
					 frame[pointer] = pageNum;
				}
				ret++;
			}
			in++;
		}
		
		return ret;
	}

	/**
	 * This is one of the four paging algorithms. This one is clock/second chance. Anytime a page
	 * 	which is in the frames is referenced again. That page will gain a second chance. The
	 *	actual page replacement occurs when we need to insert as usual. A pointer points to the
	 *	index that will be replaced. If the page has been given a second chance, we continue
	 *	until we reach a page that does not.
	 * It takes in one parameter, which is the number of frames
	 * It returns an int, which represents the number of page faults that occured.
	 */
	private static int clock(int buf) {
		int ret = 0;
		int[] frame = new int[buf];
		int[] sec = new int[buf];
		int in = 0;
		long cur;
		int pageNum;
		String curString;

		int pointer = 0;

		while (in < arr.size()) {
			if (pointer == buf) {
				pointer = 0;
			}
			
			curString = arr.get(in);
			cur = Long.decode(curString);
			pageNum = (int) (cur/8192);
			
			if (pte[pageNum][0] == 0) {
				while (sec[pointer] == 1) {
					sec[pointer] = 0;
					pointer++;
					if (pointer == buf) {
						pointer = 0;
					}
				}
				pte[pageNum][0] = 1;	
				pte[pageNum][1] = pointer;
				pte[frame[pointer]][0] = 0;
				pte[frame[pointer]][1] = 0;
				if (pte[frame[pointer]][2] == 1 ) {
					writes++;
				}
				frame[pointer] = pageNum;
				pointer++;
				ret++;
			} else {
				sec[pte[pageNum][1]] = 1;
			}

			in++;
		}

		return ret;
	}

	/**
	 * This is one of the four paging algorithms. This one is lru. With every page
	 * 	reference, this method increments numbers within an array. Whenever
	 * 	we need to replace, it looks for the index with the largest int. That
	 * 	page is replaced and the counter for that index is reset.
	 * It takes in one parameter, which is the number of frames
	 * It returns an int, which represents the number of page faults that occured.
	 */
	private static int lru(int buf) {
		int ret = 0;
		int[] frame = new int[buf];
		int[] lu = new int[buf];
		int in = 0;
		long cur;
		int pageNum;
		String curString;

		while (in < arr.size()) {
			curString = arr.get(in);
			cur = Long.decode(curString);
			pageNum = (int) (cur/8192);

			for (int i = 0; i < buf; i++) {
				lu[i]++;
			}

			int max = -1;
			int pointer = 0;

			if(pte[pageNum][0] == 0) {
				for (int i = 0; i < buf; i++) {
					if (lu[i] > max) {
						max = lu[i];
						pointer = i;
					}
				}
				pte[pageNum][0] = 1;
				pte[pageNum][1] = pointer;
				pte[frame[pointer]][0] = 0;
				pte[frame[pointer]][1] = 0;
				if (pte[frame[pointer]][2] == 1 ) {
					writes++;
				}
				frame[pointer] = pageNum;
				lu[pointer] = 0;
				ret++;
			} else {
				lu[pte[pageNum][1]] = 0;	
			}

			in++;
		}	

		return ret;
	}

	/**
	 * This is one of the four paging algorithms. This one is nfu. Everytime a page
	 * 	is referenced we add to the index that corresponds the page num, which is
	 * 	an array of ints that keeps track of the ammount of times this happens.
	 * 	When a replace needs to happen, it finds the index with the lowest int
	 * 	and replaces the page with that index.
	 * It returns an int, which represents the number of page faults that occured.
	 */
	private static int nfu(int buf) {
		int ret = 0;
		int[] frame = new int[buf];
		int[] us = new int[buf];
		int in = 0;
		long cur;
		int pageNum;
		String curString;

		while (in < arr.size()) {
			curString = arr.get(in);
			cur = Long.decode(curString);
			pageNum = (int) (cur/8192);


			int min = Integer.MAX_VALUE;
			int pointer = 0;

			if (pte[pageNum][0] == 0) {
				for (int i = 0; i < buf; i++) {
					if (us[i] < min) {
						min = us[i];
						pointer = i;
					}
				}
				pte[pageNum][0] = 1;
				pte[pageNum][1] = pointer;
				pte[frame[pointer]][0] = 0;
				pte[frame[pointer]][1] = 0;
				if (pte[frame[pointer]][2] == 1 ) {
					writes++;
				}
				frame[pointer] = pageNum;
				us[pointer] = 1;
				ret++;
			} else {
				us[pte[pageNum][1]]++;
			}

			in++;
		}

		return ret;
	}

	public static void main(String[] args) {
		int access = 0;
		writes = 0;

		int entries = (int) Math.pow(2,19);
		pte = new int[entries][3];
		arr = new ArrayList<>();
		try {
			File obj = new File(args[3]);
			Scanner scan = new Scanner(obj);
			String temp = "0x";
			while (scan.hasNextLine()) {
				String data = scan.nextLine();
				if (!data.startsWith("=") && !data.startsWith("-")) {
					temp = "0x";
					String[] ch = data.split(" ");
					if (ch.length < 3) {
						continue;
					}
					temp += ch[2].split(",")[0];
					if (ch[0].equals("I")) {
						access += 1;
					}
					if (!ch[0].equals("I")) {
						long tempCur = Long.decode(temp);
						int tempPage = (int) (tempCur/8192);

						if (ch[1].equals("M")) {
							access += 2;
							//writes -= 1;
							pte[tempPage][2] = 1;
							arr.add(temp);
						} else {
							if (ch[1].equals("S")) {
								pte[tempPage][2] = 1;
							}
							access += 1;
						}
					}
					arr.add(temp);
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error");
			e.printStackTrace();
		}

		String alg = args[2];
		int frames = Integer.parseInt(args[0]);
		int faults = 0;

		if (alg.equals("opt")) {
			faults = opt(frames);
		} else if (alg.equals("clock")) {
			faults = clock(frames);
		} else if (alg.equals("lru")) { 
			faults = lru(frames);
		} else if (alg.equals("nfu")) {
			faults = nfu(frames);
		} else {
			
		}

		System.out.println("Algorithm: " + alg);
		System.out.println("Number of frames: " + frames);
		System.out.println("Total memory accesses: " + access);
		System.out.println("Total page faults: " + faults);
		System.out.println("Total writes to disk: " + writes);
		System.out.println("Total size of page table: " + ((int)Math.pow(2,19)));
	}	
}
