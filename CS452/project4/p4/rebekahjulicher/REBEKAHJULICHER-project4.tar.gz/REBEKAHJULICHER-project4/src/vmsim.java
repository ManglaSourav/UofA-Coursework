import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class vmsim {
	// Stat counters
	private static int numFaults = 0;
	private static int numAccesses = 0;
	private static int numFrames = 0;
	private static int numWrites = 0;
	private static int tableSize = 0;
	
	// Page tracking collections
	private static PageEntry tableHead = null;
	private static PageEntry tableTail = null;
	// I know, this is a heck of a memory investment, but O(1) page retrieval go nyoom
	private static PageEntry[] pageArr = new PageEntry[524288];
	
	// Algorithm-specific variable
	private static PageEntry clockHand = null;
	
	// Prints the final summary, given the current algorithm mode
	private static void printSummary(String mode) {
		System.out.println("Algorithm: " + mode);
		System.out.println("Number of frames:       " + numFrames);
		System.out.println("Total memory accesses:  " + numAccesses);
		System.out.println("Total page faults:      " + numFaults);
		System.out.println("Total writes to disk:   " + numWrites);
		System.out.println("Total size of page table: 2097152");
	}
	
	// readFileToList(String, ArrayList<String>) Puts the entire file into an ArrayList for opt
	public static void readFileToList(String filename, ArrayList<String> traceFile){
		int currNum = 0;
		
		try{
			BufferedReader stream = new BufferedReader(new FileReader(filename));
			
			String currLine = stream.readLine();
			while (currLine != null) {
				
				String[] lineArr = currLine.trim().split("\\s+");
				//System.out.println(lineArr[0]);
				
				// This might need to be adjusted if string split starts at the 0 index
				if ((lineArr[0].equals("I") || lineArr[0].equals("S") || lineArr[0].equals("L") || lineArr[0].equals("M")) &&
						lineArr[1].length() > 3) {
					String address = lineArr[1].split(",")[0];
					traceFile.add(lineArr[0] + " 0x0" + address);
					
					int page = (int) (Long.decode("0x0" + address) >>> 13);
					
					// Makes sure each page knows every instruction number at which they occur
					if (pageArr[page] == null) pageArr[page] = new PageEntry(page, currNum);
					else pageArr[page].instructionNums.add(currNum);
					
					currNum++;    // Tracks instruction number
				}
				currLine = stream.readLine();
			}
			
			stream.close();
		}
		catch (IOException e){
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	// optEvict(PageEntry, String[]) - Load a page in and possibly evict something using OPT
	private static void optEvict(PageEntry currPage, String[] lineArr) {
		if (tableSize < numFrames) {  // page not yet located in RAM, there is space in RAM
			currPage.next = tableHead;
			if (tableHead != null) tableHead.last = currPage;
			tableHead = currPage;
			currPage.inRam = true;
			tableSize++;
			System.out.println("page: " + currPage.page + " address: " + lineArr[1] + " page fault - no eviction");
		}
		else {    // page not yet located in RAM, no space in RAM
			PageEntry furthest = tableHead;
			int furthestInstr = 0;
			PageEntry currCheck = tableHead;
			
			// Decide which page in RAM reoccurs furthest in the future
			while (currCheck != null) {
				if (currCheck.lastInstruction > currCheck.instructionNums.size() - 1) {    // replaced item is never used again
					furthest = currCheck;
					furthestInstr = Integer.MAX_VALUE;
				}
				else if (currCheck.instructionNums.get(currCheck.lastInstruction) > furthestInstr) {    // replaced item may be used again
					furthest = currCheck;
					furthestInstr = currCheck.instructionNums.get(currCheck.lastInstruction);
				}
				currCheck = currCheck.next;
			}
			
			// Do the eviction
			currPage.inRam = true;
			furthest.inRam = false;
			
			currPage.last = furthest.last;
			currPage.next = furthest.next;
			
			if (currPage.last != null) currPage.last.next = currPage; // If the currPage is not the new tableHead
			else tableHead = currPage;
			
			if (currPage.next != null) currPage.next.last = currPage;
			furthest.next = null;
			furthest.last = null;
			if (furthest.dirty) {
				System.out.println("page: " + currPage.page + " address: " + lineArr[1] + " page fault - evict dirty");
				furthest.dirty = false;
				numWrites++;
			}
			else System.out.println("page: " + currPage.page + " address: " + lineArr[1] + " page fault - evict clean");
		}
		
		numFaults++;
	}
	
	// opt(ArrayList<String) - runs the OPT algorithm
	public static void opt(ArrayList<String> traceFile) {
		for (String s : traceFile) {
			String[] lineArr = s.split(" ");
			int page = (int) (Long.decode(lineArr[1]) >>> 13);
			
			PageEntry currPage = pageArr[page];
			if (currPage.inRam) {
				System.out.println("page: " + page + " address: " + lineArr[1] + " hit");  // Page already in RAM
			}
			else optEvict(currPage, lineArr);  // Load page in and possibly evict something
			
			// handle loads
			if(lineArr[0].equals("I") || lineArr[0].equals("L") || lineArr[0].equals("M")) {
				numAccesses++;
			}
			
			// handle stores
			if(lineArr[0].equals("S") || lineArr[0].equals("M")) {
				numAccesses++;
				currPage.dirty = true;
			}

			pageArr[page].lastInstruction++;
		}
		
		printSummary("OPT");
	}
	
	// clockEvict(PageEntry, String) - Load a page in and possibly evict something using Clock
	private static void clockEvict(PageEntry currPage, String address) {
		if (tableSize < numFrames) {  
			// page not yet located in RAM, there is space in RAM
			// This linked list inserts at the end because for a little bit, I thought it might matter
			currPage.next = null;
			if (tableHead == null) {
				tableHead = currPage;
				currPage.last = null;
			}
			else {
				tableTail.next = currPage;
				currPage.last = tableTail;
			}
			currPage.inRam = true;
			tableTail = currPage;
			tableSize++;
			if (currPage.next != null) clockHand = currPage.next;
			else clockHand = tableHead;
			System.out.println("page: " + currPage.page + " address: " + address + " page fault - no eviction");
		}
		else {    // page not yet located in RAM, no space in RAM
			boolean found = false;
			PageEntry replaced = clockHand;
			
			// Find the page to evict with clock second-chance
			while (!found) {
				if (!clockHand.referenced) found = true;
				else {
					clockHand.referenced = false;
					if (clockHand.next == null) clockHand = tableHead;
					else clockHand = clockHand.next;
				}
				replaced = clockHand;
			}
			
			// Do the eviction. Yes, all of these algorithms use linked list, but I structure them differently, so I'm not
			// turning this piece of code into a function. It's not quite as redundant as it might seem.
			currPage.inRam = true;
			currPage.last = replaced.last;
			currPage.next = replaced.next;
			if (currPage.last != null) currPage.last.next = currPage; // If the currPage is not the new tableHead
			else tableHead = currPage;
			if (currPage.next != null) currPage.next.last = currPage;
			replaced.next = null;
			replaced.last = null;
			replaced.inRam = false;
			if (currPage.next != null) clockHand = currPage.next;
			else clockHand = tableHead;
			if (replaced.dirty) {
				System.out.println("page: " + currPage.page + " address: " + address + " page fault - evict dirty");
				replaced.dirty = false;
				numWrites++;
			}
			else System.out.println("page: " + currPage.page + " address: " + address + " page fault - evict clean");
		}
		
		numFaults++;
	}
	
	// lruEvict(PageEntry, String) - Load a page in and possibly evict something using LRU
	private static void lruEvict(PageEntry currPage, String address) {
		if (tableSize < numFrames) {  // page not yet located in RAM, there is space in RAM
			currPage.last = null;
			currPage.next = tableHead;
			if (tableHead != null) tableHead.last = currPage;
			else tableTail = currPage; // Makes sure the tableTail is set
			tableHead = currPage;
			currPage.inRam = true;
			tableSize++;
			
			System.out.println("page: " + currPage.page + " address: " + address + " page fault - no eviction");
		}
		else {    // page not yet located in RAM, no space in RAM
			PageEntry replaced = tableTail;
			
			// Do the eviction - place currPage at the head of the list, remove the tail of the list, and set the tail
			// to whatever was right behind it.
			currPage.inRam = true;
			currPage.last = null;
			currPage.next = tableHead;
			tableHead.last = currPage;
			tableHead = currPage;

			tableTail = replaced.last;
			tableTail.next = null;
			replaced.last = null;
			replaced.inRam = false;
			
			if (replaced.dirty) {
				System.out.println("page: " + currPage.page + " address: " + address + " page fault - evict dirty");
				replaced.dirty = false;
				numWrites++;
			}
			else System.out.println("page: " + currPage.page + " address: " + address + " page fault - evict clean");
		}
		
		numFaults++;
	}
	
	// nfuEvict(PageEntry, String) - Load a page in and possibly evict something using NFU
	private static void nfuEvict(PageEntry currPage, String address) {
		if (tableSize < numFrames) {  // page not yet located in RAM, there is space in RAM
			currPage.next = tableHead;
			if (tableHead != null) tableHead.last = currPage;
			tableHead = currPage;
			currPage.inRam = true;
			currPage.timesUsed = 1;
			tableSize++;
			System.out.println("page: " + currPage.page + " address: " + address + " page fault - no eviction");
		}
		else {    // page not yet located in RAM, no space in RAM
			PageEntry lowest = tableHead;
			boolean lowestIsDirty = false;
			int lowestCount = tableHead.timesUsed;
			PageEntry currCheck = tableHead;
			
			// Decide which page in RAM reoccurs furthest in the future
			while (currCheck != null) {
				if (currCheck.timesUsed < lowestCount) {    // replaced item is never used again
					lowest = currCheck;
					lowestIsDirty = currCheck.dirty;
					lowestCount = currCheck.timesUsed;
				}
				if (currCheck.timesUsed == lowestCount && ((lowestIsDirty && currCheck.dirty) || (!currCheck.dirty))) {    // replaced item is never used again
					lowest = currCheck;
					lowestIsDirty = currCheck.dirty;
					lowestCount = currCheck.timesUsed;
				}
				currCheck = currCheck.next;
			}
			
			// Do the eviction
			currPage.inRam = true;
			currPage.timesUsed = 1;
			currPage.last = lowest.last;
			currPage.next = lowest.next;
			if (currPage.last != null) currPage.last.next = currPage; // If the currPage is not the new tableHead
			else tableHead = currPage;
			if (currPage.next != null) currPage.next.last = currPage;
			lowest.next = null;
			lowest.last = null;
			lowest.inRam = false;
			lowest.timesUsed = 0;
			if (lowest.dirty) {
				System.out.println("page: " + currPage.page + " address: " + address + " page fault - evict dirty");
				lowest.dirty = false;
				numWrites++;
			}
			else System.out.println("page: " + currPage.page + " address: " + address + " page fault - evict clean");
		}
		
		numFaults++;
	}
	
	// Moves current page to the top of the list, sets the tail to the next in line if needed
	private static void lruPing(PageEntry currPage) {
		if (currPage.next == null) tableTail = currPage.last;
		else currPage.next.last = currPage.last;
		currPage.last.next = currPage.next;
		
		currPage.next = tableHead;
		currPage.last = null;
		if (tableHead != null) tableHead.last = currPage;
		tableHead = currPage;
	}
	
	
	// threeAlgorithms(String, String) - runs any given OPT-alternative algorithm
	public static void threeAlgorithms(String filename, String mode) {
		try{
			BufferedReader stream = new BufferedReader(new FileReader(filename));
			
			String currLine = stream.readLine();
			while (currLine != null) {
				String[] lineArr = currLine.trim().split("\\s+");
				
				// If the line is a valid trace, handle it
				if ((lineArr[0].equals("I") || lineArr[0].equals("S") || lineArr[0].equals("L") || lineArr[0].equals("M")) &&
						lineArr[1].length() > 3) {
					String address = lineArr[1].split(",")[0];
					int page = (int) (Long.decode("0x0" + address) >>> 13);
					
					// Create PageEntries as needed
					if (pageArr[page] == null) pageArr[page] = new PageEntry(page, 0);
					PageEntry currPage = pageArr[page];
					
					if (currPage.inRam) {
						if (mode.equals("lru") && currPage.last != null) lruPing(currPage);
						else if (mode.equals("nfu")) currPage.timesUsed++;
						
						System.out.println("page: " + page + " address: " + address + " hit");  // Page already in RAM
					}
					else {
						if (mode.equals("clock")) clockEvict(currPage, address);
						else if (mode.equals("lru")) lruEvict(currPage, address);
						else nfuEvict(currPage, address);
					}
					
					// handle loads
					if(lineArr[0].equals("I") || lineArr[0].equals("L") || lineArr[0].equals("M")) numAccesses++;
					
					// handle stores
					if(lineArr[0].equals("S") || lineArr[0].equals("M")) {
						numAccesses++;
						currPage.dirty = true;
					}
					
					if (mode.equals("clock")) currPage.referenced = true;
				}
				currLine = stream.readLine();
			}
			stream.close();
			
			printSummary(mode);
		}
		catch (IOException e){
			e.printStackTrace();
			System.exit(1);
		}
	}
	

	public static void main(String[] args) {
		boolean nextIsFrames = false;
		boolean nextIsAlg = false;
		String algorithm = "";
		String traceFile = "";
		
		for (String s : args) {
			if (nextIsFrames) {
				numFrames = Integer.parseInt(s);
				nextIsFrames = false;
			}
			else if (nextIsAlg) {
				algorithm = s;
				nextIsAlg = false;
			}
			else if (s.equals("-n")) nextIsFrames = true;
			else if (s.equals("-a")) nextIsAlg = true;
			else traceFile = s;
		}
		
		if (numFrames == 0 || !(algorithm.equals("opt") || algorithm.equals("clock") ||
				algorithm.equals("lru") || algorithm.equals("nfu")) || traceFile.equals("")) System.exit(1);
		
		if (algorithm.equals("opt")) {
			ArrayList<String> traces = new ArrayList<String>();
			readFileToList(traceFile, traces);
			opt(traces);
		}
		else threeAlgorithms(traceFile, algorithm);
	}
	
	// My Linked List nodes that double as page info table entries
	private static class PageEntry {
		public int page;
		public boolean dirty;
		public boolean inRam;

		// Algorithm-specific variables
		public boolean referenced;
		public int timesUsed;
		public int lastInstruction;
		public ArrayList<Integer> instructionNums;
		
		public PageEntry next;
		public PageEntry last;
		
		public PageEntry(int pageNum, int instruction) {
			this.dirty = false;
			this.inRam = false;
			this.referenced = false;
			
			this.timesUsed = 0;
			this.lastInstruction = 0;
			this.instructionNums = new ArrayList<Integer>();
			this.instructionNums.add(instruction);
			this.next = null;
			this.last = null;
			this.page = pageNum;
		}
		
	}

}
