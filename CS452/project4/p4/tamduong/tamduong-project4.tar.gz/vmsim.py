"""
Author: Tam Dinh Duong
Programming Assignment 4
This programming assignment simulate the pagefault handler
using algorithms like opt, clock, lru, nfu
"""

import sys
from heapq import *

# page size is 8kb
PAGE_SIZE = 8192
#table size is 2^32/8192
TABLE_SIZE = 1<<19
# 4 byte per page entry
PAGE_ENTRY_SIZE = 4

# class to represent page entry
class Entry:
    def __init__(self):
        self.dirty = False
        self.valid = False
        self.ref   = True
        self.frame = -1

    def evict(self):
        self.dirty = False
        self.valid = False
        self.ref   = True
        self.frame = -1

def main():
    # check and locate arguments
    if len(sys.argv) != 6 or sys.argv[1] != "-n" or sys.argv[3] != "-a":
        raise Exception("FORM: vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>")
        exit(1)
    numFrame = int(sys.argv[2])
    algo = sys.argv[4]
    fileName = sys.argv[5]
    pages = []
    for i in range(TABLE_SIZE):
        pages.append(Entry())
    memory = [0] * numFrame
    file = open(fileName, 'r')
    lines = file.readlines()
    file.close()

    # call algorithm, a lot of them have a lot in common, but keep separated for clearer code
    if algo == "opt":
        memAccess, pageFault, diskWrite = opt(lines, pages, memory, numFrame)
    elif algo == "clock":
        memAccess, pageFault, diskWrite = clock(lines, pages, memory, numFrame)
    elif algo == "lru":
        memAccess, pageFault, diskWrite = lru(lines, pages, memory, numFrame)
    elif algo == "nfu":
        memAccess, pageFault, diskWrite = nfu(lines, pages, memory, numFrame)
    else:
        raise Exception("you only have options <opt|clock|lru|nfu>")
    # print out the result
    print(f"Algorithm: {algo}")
    print(f"Number of frames:       {numFrame}")
    print(f"Total memory accesses:  {memAccess}")
    print(f"Total page faults:      {pageFault}")
    print(f"Total writes to disk:   {diskWrite}")
    print(f"Total size of page table:   {TABLE_SIZE*PAGE_ENTRY_SIZE}")

def optReadFile(file):
    """
        optReadFile(file) will read all the file and generate data
        for opt algorithm, which include a map and a list that
        contain all the entry
    """
    pageMap     = {}
    pageList    = []
    cmdNum      = 1
    for line in file:
        splited = line.split()
        if len(splited) == 0 or splited[0] not in "ISML":
            continue
        op = splited[0]
        addrStr, size = splited[1].split(",")
        address = int(addrStr, 16)
        tableIndex = address//PAGE_SIZE
        if tableIndex not in pageMap:
            pageMap[tableIndex] = []
        heappush(pageMap[tableIndex], cmdNum)
        pageList.append((tableIndex, op, line.strip()))
        cmdNum += 1
    return pageMap, pageList
        

def opt(file, pages, memory, numFrame):
    """
        opt(file, pages, memory, numFrame) will read through
        the instruction in the file will evict the entry
        in the memory based on the entry of the furthest time
        of use in the future
    """
    memAccess = pageFault = diskWrite = count = 0
    pageMap, pageList = optReadFile(file)
    cmdNum = 1

    for tableIndex, op, line in pageList:
        entry = pages[tableIndex]
        if entry.valid:
            #if entry is valid, which means already in memory
            print(f"{line} - hit.")
            entry.ref = True
        else:
            if count >= numFrame:
                # if run out of memory
                entryEvict = optEvict(pages, memory, pageMap, cmdNum)
                entry.frame = entryEvict.frame
                entry.valid = True
                if entryEvict.dirty:
                    diskWrite += 1
                    print(f"{line} - page fault - evict dirty")
                else:
                    print(f"{line} - page fault - evict clean")
                entryEvict.evict()
                memory[entry.frame] = tableIndex
            else:
                # if pagefault but still have memory
                print(f"{line} - page fault - no eviction")
                entry.valid = True
                entry.frame = count
                memory[count] = tableIndex
                count = count + 1
            pageFault += 1
        if op == "M":
            memAccess += 2
            entry.dirty = True
        else:
            if op == "S":
                entry.dirty = True
            memAccess += 1
        cmdNum += 1
    return memAccess, pageFault, diskWrite

def optEvict(pages, memory, pageMap, cmdNum):
    """
        optEvict(pages, memory, pageMap, cmdNum) will find the
        entry in the memory to evict based on the opt algorithm,
        which means the entry that will not be used until furthest
        in the future will be chosen
    """
    furthest = -1
    maxi = -1
    for page in memory:
        if len(pageMap[page]) == 0:
            nextOccur = -1
            break
        else:
            nextOccur = pageMap[page][0]
            while nextOccur <= cmdNum:
                heappop(pageMap[page])
                if len(pageMap[page]) == 0:
                    nextOccur = -1
                    break
                else:
                    nextOccur = pageMap[page][0]
        if nextOccur == -1:
            furthest = page
            break
        if nextOccur > maxi:
            furthest = page
            maxi = nextOccur
    return pages[furthest] if furthest != -1 else pages[memory[0]]

def clock(file, pages, memory, numFrame):
    """
        clock(file, pages, memory, numFrame) will read through
        the instruction in the file will evict the entry
        in the memory based on the clock algorithm, which is based
        on a second chance
    """
    memAccess = pageFault = diskWrite = count = oldInd = 0
    for line in file:
        # read in the file
        line = line.strip()
        splited = line.split()
        if len(splited) == 0 or splited[0] not in "ISML":
            continue
        op = splited[0]
        addrStr, size = splited[1].split(",")
        address = int(addrStr, 16)
        tableIndex = address//PAGE_SIZE
        entry = pages[tableIndex]
        if entry.valid:
            # if entry is in memory
            print(f"{line} - hit.")
            entry.ref = True
        else:
            if count >= numFrame:
                # if run out of memory, has to evict
                entryEvict = pages[memory[oldInd]]
                while entryEvict.ref:
                    entryEvict.ref = False
                    oldInd = (oldInd + 1) % len(memory)
                    entryEvict = pages[memory[oldInd]]
                entry.frame = entryEvict.frame
                entry.valid = True
                if entryEvict.dirty:
                    diskWrite += 1
                    print(f"{line} - page fault - evict dirty")
                else:
                    print(f"{line} - page fault - evict clean")
                entryEvict.evict()
                memory[oldInd] = tableIndex
                oldInd = (oldInd + 1) % len(memory)
            else :
                # pagefault but there is enough memory
                print(f"{line} - page fault - no eviction")
                entry.valid = True
                entry.frame = count
                memory[count] = tableIndex
                count += 1
            pageFault += 1
        if op == "M":
            memAccess += 2
            entry.dirty = True
        else:
            if op == "S":
                entry.dirty = True
            memAccess += 1
    return memAccess, pageFault, diskWrite

def lru(file, pages, memory, numFrame):
    """
        lru(file, pages, memory, numFrame) will read through
        the instruction in the file will evict the entry
        in the memory based on the lru algorithm, which
        choose evict based on timestamp
    """
    memAccess = pageFault = diskWrite = count = curTime = 0
    timeTable = [0]*len(memory)
    indMap = {}
    # read in the file
    for line in file:
        line = line.strip()
        splited = line.split()
        if len(splited) == 0 or splited[0] not in "ISML":
            continue
        op = splited[0]
        addrStr, size = splited[1].split(",")
        address = int(addrStr, 16)
        tableIndex = address//PAGE_SIZE
        entry = pages[tableIndex]
        if entry.valid:
            # if entry is in memory
            print(f"{line} - hit.")
            timeTable[indMap[entry]] = curTime
        else:
            if count >= numFrame:
                # entry not in memory, out or memory, evict
                toEvict = 0
                for i in range(len(timeTable)):
                    if timeTable[i] < timeTable[toEvict]:
                        toEvict = i
                entryEvict = pages[memory[toEvict]]
                entry.frame = entryEvict.frame
                entry.valid = True
                if entryEvict.dirty:
                    diskWrite += 1
                    print(f"{line} - page fault - evict dirty")
                else:
                    print(f"{line} - page fault - evict clean")
                entryEvict.evict()
                indMap[pages[tableIndex]] = toEvict
                memory[toEvict] = tableIndex
                timeTable[toEvict] = curTime
            else:
                # entry not in memory, still memory, no evict
                print(f"{line} - page fault - no eviction")
                entry.valid = True
                entry.frame = count
                memory[count] = tableIndex
                indMap[pages[tableIndex]] = count
                timeTable[count] = curTime
                count += 1
            pageFault += 1
        curTime += 1
        if op == "M":
            memAccess += 2
            entry.dirty = True
        else:
            if op == "S":
                entry.dirty = True
            memAccess += 1
    return memAccess, pageFault, diskWrite

def nfu(file, pages, memory, numFrame):
    """
        nfu(file, pages, memory, numFrame) will read through
        the instruction in the file will evict the memory based
        on the frequency of use
    """
    memAccess = pageFault = diskWrite = count = 0
    freq = [0]*len(memory)
    indMap = {}
    # read file
    for line in file:
        line = line.strip()
        splited = line.split()
        if len(splited) == 0 or splited[0] not in "ISML":
            continue
        op = splited[0]
        addrStr, size = splited[1].split(",")
        address = int(addrStr, 16)
        tableIndex = address//PAGE_SIZE
        entry = pages[tableIndex]
        if entry.valid:
            # entry in memory
            print(f"{line} - hit.")
            freq[indMap[entry]] += 1
        else:
            if count >= numFrame:
                # entry not in memory, out of memory, evict
                toEvict = 0
                for i in range(len(freq)):
                    if freq[i] < freq[toEvict]:
                        toEvict = i
                entryEvict = pages[memory[toEvict]]
                entry.frame = entryEvict.frame
                entry.valid = True
                if entryEvict.dirty:
                    diskWrite += 1
                    print(f"{line} - page fault - evict dirty")
                else:
                    print(f"{line} - page fault - evict clean")
                entryEvict.evict()
                indMap[pages[tableIndex]] = toEvict
                memory[toEvict] = tableIndex
                freq[toEvict] = 0
            else:
                # entry not in memory, memory left, evict
                print(f"{line} - page fault - no eviction")
                entry.valid = True
                entry.frame = count
                memory[count] = tableIndex
                indMap[pages[tableIndex]] = count
                freq[count]+=1
                count += 1
            pageFault += 1
        if op == "M":
            memAccess += 2
            entry.dirty = True
        else:
            if op == "S":
                entry.dirty = True
            memAccess += 1
    return memAccess, pageFault, diskWrite

main()