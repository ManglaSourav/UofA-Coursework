/**
 * @file vmsim.cpp
 * @author Luke Broadfoot (lucasxavier@email.arizona.edu)
 * @brief
 *
 * @compile g++ -std=c++17 -O2 -o vmsim vmsim.cpp
 *
 * @execute vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>
 *  -where numframes is the number of frames <8|16|32|64>
 *  -where <opt|clock|lru|nfu> refers to the algorithm to run
 *  -where <tracefile> is the file path to a lackey trace file
 *
 */

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <queue>
#include <map>

using namespace std;

// Constants
// the spec says an 8k page size, so 8k is 13 bits
int PAGE_SIZE_BITS = 13;
// whatever is leftover from the pagesize is the page#
int PAGE_NUM_BITS = 32 - PAGE_SIZE_BITS;

// a struct containing the parsed cli arguments
struct Args {
	int numFrame;
	string alg, file;
};

// a struct the represents a page table entry
struct Page {
	bool dirty{false}, ref{true}, valid{false};
	int refCount{0};
};

// a struct that holds the results of each algorithm
struct Results {
	string alg;
	int frames, accesses{0}, faults{0}, writes{0};
    // a struct constructor that takes alg and frames,
    // since alg and frames don't change
    Results(string a, int f) : alg{a}, frames{f} {}
};

// a struct containing if a given line of a trace file is actual code
struct Valid {
    bool isCmd, modify;
    int accesses;
};

/**
 * @brief takes in the cli arguments and determines if they are valid
 * if they are returns a struct containing the values parsed from it
 * 
 * @param argc how many arguments the cli received
 * @param argv a list of string containing the cli arguments
 * @return Args the cli arguments in a struct 
 */
Args getArgs(int argc, char* argv[]) {
	Args res;
	try {
        // makes sure we received the expected amount of arguments
		if (argc != 6) { throw 1; }

        // makes sure that the first flag is '-n'
		if (string{argv[1]}.compare("-n")) { throw 2; }
        // attempts to convert the <numframes> to int
		try {
			res.numFrame = stoi(argv[2]);
		} catch (...) { throw 3; }

        // makes sure that the second flag is '-a'
		if (string{argv[3]}.compare("-a")) { throw 4; }

        // determines if the algorithm is supported
		bool validAlg = false;
		for (string alg : {"opt", "clock", "lru", "nfu"}) {
			if (argv[4] == alg) {
				validAlg = true;
				res.alg = alg;
			}
		}
		if (!validAlg) { throw 5; }
        
        // checks that the <tracefile> exits
		try {
			ifstream f{argv[5]};
		} catch (...) { throw 6; }
		res.file = argv[5];
    // prints out only if any argument check fails
	} catch (int flag) {
		switch (flag) {
			case 1:
				fprintf(stderr, "invalid number of arguments, expect 6 got %d\n", argc);
			case 2:
				fprintf(stderr, "expected a '-n' got %s\n", argv[1]);
			case 3:
				fprintf(stderr, "unable to cast '%s' to int\n", argv[2]);
			case 4:
				fprintf(stderr, "expected a '-a' got %s\n", argv[3]);
			case 5:
				fprintf(stderr, "invalid algorithm type '%s'\n", argv[4]);
			case 6:
				fprintf(stderr, "unable to open file '%s'\n", argv[5]);
		}
		exit(1);
	}
	return res;
}

/**
 * @brief very basic factory for making a page table
 * 
 * @return vector<Page> a page table
 */
vector<Page> pageTableFactory() {
    vector<Page> res(2 << PAGE_NUM_BITS);
    return res;
}

/**
 * @brief checks that a line of the tracefile valid and what type of event
 * 
 * @param cmd a 2 character string
 * @return Valid {bool, bool, int}
 */
Valid checkCmd(string cmd) {
    if (cmd == " M") { return {true, true, 2}; }
    if (cmd == " S") { return {true, true, 1}; }
    if (cmd == " L") { return {true, false, 1}; }
    if (cmd == "I ") { return {true, false, 1}; }
    return {false, false, 0};
}

/**
 * @brief Implements the optimal algorithm that knows the future and evicts the page that
 * is need furthest in the future
 * 
 * @param args the parsed cli arguments
 * @return Results a struct contianing results of running of algorithm
 */
Results optimalAlg(Args args) {
    // constructs the response struct
	Results res{args.alg, args.numFrame};
    // optimal doesn't care about treating ram like a circular queue.
    vector<int> ram;
    // creates the pageTable to hold all the entries
    auto pageTable = pageTableFactory();
    // maps page# -> queue of when they appear
    map<int, queue<int>> futureTable;
    // allows me to not have to reopen and iterate over the file
    vector<string> program;
    // a program counter which is the values in the queues in futureTable
    int pc{0};
    string line;
    ifstream file{args.file};
    // iterates over the tracefile
    while (getline(file, line)) {
        // grabs the first 2 characters to determine if it is an event or not
        string cmd = line.substr(0, 2);
        auto [isCmd, isDirty, count] = checkCmd(cmd);
        if (!isCmd) { continue; }
        // converts the hex into an integer where we only care about the page number upper 19 bits
        int pageNum = stoul(line.substr(3,8), nullptr, 16) >> PAGE_SIZE_BITS;
        program.push_back(line);
        // if the page# is already in the map, add the current program counter, else add the page#
        if (futureTable.count(pageNum)) {
            futureTable.at(pageNum).push(pc++);
        } else {
            queue<int> q;
            q.push(pc++);
            futureTable.insert({pageNum, q});
        }
    }
    // goes over the program again
    for (string line : program) {
        string cmd = line.substr(0, 2);
        auto [isCmd, isDirty, count] = checkCmd(cmd);
        res.accesses += count;
        // converts the hex into an integer where we only care about the page number upper 19 bits
        int pageNum = stoul(line.substr(3,8), nullptr, 16) >> PAGE_SIZE_BITS;
        // futreTable.at(pageNum).front() == $pc
        futureTable.at(pageNum).pop();
        // if it's in ram, thats a hit we can go to the next instruction
        if (pageTable[pageNum].valid) {
            cout << line << " (hit)\n";
            if (isDirty) { pageTable[pageNum].dirty = true; }
            continue;
        }
        // if it is not in ram, we get a page fault
        res.faults++;
        // if ram is full
        if (ram.size() == args.numFrame) {
            int furthest{0};
            // finds which ever page currently in ram is referenced furthest from now
            for (int i = 0; i < ram.size(); i++) {
                if (futureTable.at(ram[i]).empty()) {
                    furthest = i;
                    break;
                }
                if (futureTable.at(ram[i]).front() > futureTable.at(ram[furthest]).front()) {
                    furthest = i;
                }
            }
            // evicts the page that is furthest from now
            int evicted = ram[furthest];
            vector<int> newRam;
            for (int inRam : ram) {
                if (inRam != evicted) { newRam.push_back(inRam); }
            }
            ram = newRam;
            pageTable[evicted].valid = false;
            // prints out the type of eviction
            if (pageTable[evicted].dirty) {
                cout << line << " (page fault - evict dirty)\n";
                res.writes++;
            } else {
                cout << line << " (page fault - evict clean)\n";
            }
            pageTable[evicted].dirty = false;
            // adds the new page to ram
            pageTable[pageNum].valid = true;
            ram.push_back(pageNum);
        } else {
            // if ram is open and we faulted, then just add the page to ram
            pageTable[pageNum].valid = true;
            if (isDirty) { pageTable[pageNum].dirty = true; }
            ram.push_back(pageNum);
            cout << line << " (page fault - no eviction)\n";
        }
    }
	return res;
}

/**
 * @brief Implements the clock algorithm that gives pages a second chance
 * 
 * @param args the parsed cli arguments
 * @return Results a struct contianing results of running of algorithm
 */
Results clockAlg(Args args) {
    // constructs the reponse struct
	Results res{args.alg, args.numFrame};
    // the clock algorithm treats ram as a queue
    queue<int> ram;
    // creates the pageTable to hold all the entries
    auto pageTable = pageTableFactory();
    string line;
    ifstream file{args.file};
    // iterates over the tracefile
    while (getline(file, line)) {
        // grabs the first 2 characters to determine if it is an event or not
        string cmd = line.substr(0, 2);
        auto [isCmd, isDirty, count] = checkCmd(cmd);
        if (!isCmd) { continue; }
        // count is either 1 or 2, if the event type is "M" then it is 2 else 1
        res.accesses += count;
        // converts the hex into an integer where we only care about the page number upper 19 bits
        int pageNum = stoul(line.substr(3,8), nullptr, 16) >> PAGE_SIZE_BITS;
        // if it's in ram, thats a hit and we can go to the next instruction
        if (pageTable[pageNum].valid) {
            cout << line << " (hit)\n";
            if (isDirty) { pageTable[pageNum].dirty = true; }
            pageTable[pageNum].ref = true;
            continue;
        }
        // if it is not in ram, we get a page fault
        res.faults++;
        // if ram is full
        if (ram.size() == args.numFrame) {
            // loops until we evict some page
            while (true) {
                int curPageNum = ram.front();
                ram.pop();
                // second chance
                if (pageTable[curPageNum].ref) {
                    pageTable[curPageNum].ref = false;
                    ram.push(curPageNum);
                // if the page already got a second change, evict it
                } else {
                    pageTable[curPageNum].valid = false;
                    if (pageTable[curPageNum].dirty) {
                        cout << line << " (page fault - evict dirty)\n";
                        res.writes++;
                    } else {
                        cout << line << " (page fault - evict clean)\n";
                    }
                    pageTable[curPageNum].dirty = false;
                    // add new page to ram
                    ram.push(pageNum);
                    pageTable[pageNum].valid = true;
                    pageTable[pageNum].ref = true;
                    break;
                }
            }
        // ram is not full, just put page into ram
        } else {
            pageTable[pageNum].valid = true;
            pageTable[pageNum].ref = true;
            if (isDirty) { pageTable[pageNum].dirty = true; }
            ram.push(pageNum);
            cout << line << " (page fault - no eviction)\n";
        }
    }
	return res;
}

/**
 * @brief Implements the least recently used algorithm that evicts the least recently used page
 * 
 * @param args the parsed cli arguments
 * @return Results a struct contianing results of running of algorithm
 */
Results lruAlg(Args args) {
	Results res{args.alg, args.numFrame};
    queue<int> ram;
    auto pageTable = pageTableFactory();
    string line;
    ifstream file{args.file};
    // iterates over the tracefile
    while (getline(file, line)) {
        // grabs the first 2 characters to determine if it is a event or not
        string cmd = line.substr(0, 2);
        auto [isCmd, isDirty, count] = checkCmd(cmd);
        if (!isCmd) { continue; }
        res.accesses += count;
        // converts the hex into an integer where we only care about the page number upper 19 bits
        int pageNum = stoul(line.substr(3,8), nullptr, 16) >> PAGE_SIZE_BITS;
        // if its in ram, we update the recency
        if (pageTable[pageNum].valid) {
            cout << line << " (hit)\n";
            if (isDirty) { pageTable[pageNum].dirty = true; }
            // takes the page out of the ram queue, and puts it at the tail.
            queue<int> tempRam;
            while (!ram.empty()) {
                int inRam = ram.front();
                ram.pop();
                if (inRam != pageNum) { tempRam.push(inRam); }
            }
            tempRam.push(pageNum);
            ram = tempRam;
            continue;
        }
        // if it is not in ram, thats a page fault
        res.faults++;
        if (ram.size() == args.numFrame) {
            // the page at the head of the queue is the least recently used, so evict it
            int evicted = ram.front();
            ram.pop();
            pageTable[evicted].valid = false;
            if (pageTable[evicted].dirty) {
                cout << line << " (page fault - evict dirty)\n";
                res.writes++;
            } else {
                cout << line << " (page fault - evict clean)\n";
            }
            pageTable[evicted].dirty = false;
            // add the new page to ram
            ram.push(pageNum);
            pageTable[pageNum].valid = true;
        // if ram is not full, add the new page
        } else {
            pageTable[pageNum].valid = true;
            if (isDirty) { pageTable[pageNum].dirty = true; }
            ram.push(pageNum);
            cout << line << " (page fault - no eviction)\n";
        }
    }
	return res;
}

/**
 * @brief Implements the not frequently used algorithm that evicts a page who has the least
 * references since being loaded
 * 
 * @param args the parsed cli arguments
 * @return Results a struct contianing results of running of algorithm
 */
Results nfuAlg(Args args) {
	Results res{args.alg, args.numFrame};
    vector<int> ram;
    auto pageTable = pageTableFactory();
    string line;
    ifstream file{args.file};
    // iterates over the tracefile
    while (getline(file, line)) {
        // grabs the first 2 characters to determine if it is a event or not
        string cmd = line.substr(0, 2);
        auto [isCmd, isDirty, count] = checkCmd(cmd);
        if (!isCmd) { continue; }
        res.accesses += count;
        // converts the hex into an integer where we only care about the page number upper 19 bits
        int pageNum = stoul(line.substr(3,8), nullptr, 16) >> PAGE_SIZE_BITS;
        // if the page is ram, we increments it's refCount
        if (pageTable[pageNum].valid) {
            cout << line << " (hit)\n";
            if (isDirty) { pageTable[pageNum].dirty = true; }
            pageTable[pageNum].refCount++;
            continue;
        }
        // if it is not in ram, thats a page fault
        res.faults++;
        if (ram.size() == args.numFrame) {
            int leastIndex{0};
            // finds the page with the least reference counter
            for (int i = 0; i < ram.size(); i++) {
                if (pageTable[ram[i]].refCount < pageTable[ram[leastIndex]].refCount) {
                    leastIndex = i;
                }
            }
            // evicts the page which has the least amount of recent references
            int evicted = ram[leastIndex];
            vector<int> newRam;
            // removes it from the ram list
            for (int inRam : ram) {
                if (inRam != evicted) { newRam.push_back(inRam); }
            }
            ram = newRam;
            pageTable[evicted].refCount = 0;
            pageTable[evicted].valid = false;
            if (pageTable[evicted].dirty) {
                cout << line << " (page fault - evict dirty)\n";
                res.writes++;
            } else {
                cout << line << " (page fault - evict clean)\n";
            }
            pageTable[evicted].dirty = false;
            // adds the new page
            pageTable[pageNum].valid = true;
            pageTable[pageNum].refCount = 1;
            ram.push_back(pageNum);
        // if ram is not full, adds the page to ram
        } else {
            pageTable[pageNum].valid = true;
            pageTable[pageNum].refCount = 1;
            if (isDirty) { pageTable[pageNum].dirty = true; }
            ram.push_back(pageNum);
            cout << line << " (page fault - no eviction)\n";
        }
    }
	return res;
}

int main(int argc, char* argv[]) {
    auto args = getArgs(argc, argv);
    Results r{args.alg, args.numFrame};
    
    if (args.alg == "opt") { r = optimalAlg(args); }
    if (args.alg == "clock") { r = clockAlg(args); }
    if (args.alg == "lru") { r = lruAlg(args); }
    if (args.alg == "nfu") { r = nfuAlg(args); }

    printf("Algorithm: %s\n", r.alg.c_str());
    printf("Number of frames: %d\n", r.frames);
    printf("Total memory accesses: %d\n", r.accesses);
    printf("Total page faults: %d\n", r.faults);
    printf("Total writes to disk: %d\n", r.writes);
    printf("Total size of page table: %d bytes\n", (2 << PAGE_NUM_BITS));
	return 0;
}