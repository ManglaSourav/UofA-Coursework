import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/*
 * Author: Christian Trejo
 * Course: CSC452
 * Assignment: Project 4 - Virtual Memory Simulator 
 * Due: Tuesday, April 22, 2022, by 11:59pm 
 * Purpose: Implement four different page replacement algorithms on traces of 
 * 			memory references, gather statistics on each and compare the performance
 * 			of each algorithm.
 */
public class vmsim {

	public static void main(String[] args) throws FileNotFoundException {

		//Setup variables using arguments 
		Integer numFrames = Integer.valueOf(args[1]);
		String algorithm  = args[3];
		String filename   = args[4];
		
		//Initialize page table and RAM 
		int numPages = (int)Math.pow(2, 19);
		PageTableEntry[] pageTable = new PageTableEntry[numPages];
		PageTableEntry[] ram = new PageTableEntry[numFrames];
		for(int i = 0; i < numPages; i++) {			//Initialize PageTable
			pageTable[i] = new PageTableEntry();
			pageTable[i].setPageNumber(i);  			//Save page number in each page table entry 
		}
		for(int i = 0; i < numFrames; i++) {		//Initialize RAM entries to null initially
			ram[i] = null;
		}
		
		//Initialize return values array 
		int[] retvals = new int[3];
		
		//Call requested algorithm
		if(algorithm.equals("opt")) {
			retvals = optAlgorithm(filename, pageTable, ram, numFrames);
		} else if(algorithm.equals("clock")) {
			retvals = clockAlgorithm(filename, pageTable, ram, numFrames);
		} else if(algorithm.equals("lru")) {
			retvals = lruAlgorithm(filename, pageTable, ram, numFrames);
		} else if(algorithm.equals("nfu")) {
			retvals = nfuAlgorithm(filename, pageTable, ram, numFrames);
		} else {
			System.out.println("Invalid algorithm. Valid algorithms are: opt, clock, lru, nfu.");
			return;
		}
		
		//Get return values and pageTableSize for print statements 
		int numMemAccesses = retvals[0];
		int numPageFaults  = retvals[1];
		int numWriteDisk   = retvals[2];
		int pageTableSize = numPages * 4;		//TableSize = numPages * 4 byte (entry size)
		
		//Print out summary statistics
		System.out.println("Algorithm: " + algorithm);
		System.out.println("Number of frames:       " + numFrames);
		System.out.println("Total memory accesses:  " + numMemAccesses);
		System.out.println("Total page faults:      " + numPageFaults);
		System.out.println("Total writes to disk:   " + numWriteDisk);
		System.out.println("Total size of page table: " + pageTableSize + " bytes");
		
	}
	
	
	/**********************************************************************/
	/*
	 * Purpose: Returns the statistics of the OPT Page Replacement Algorithm which 
	 *          simulates what the optimal page replacement algorithm would choose if 
	 *          it had perfect knowledge of the future - evict the page that is used
	 *          farthest (or never again) in the future.
	 * Parameters:
	 * 	        filename: the file to read instructions from; string type
	 * 			pageTable: Page table with initialized page table entries; PageTableEntry array type
	 * 			ram: ram with null entries; PageTableEntry array type
	 * 			numFrames: the number of frames in ram; int type 
	 * Returns: 
	 * 			retval: array holding number of memory accesses, number of page faults, and number of 
	 * 				    writes to disk; int array type
	 */
	public static int[] optAlgorithm(String filename, PageTableEntry[] pageTable, PageTableEntry[] ram, int numFrames) throws FileNotFoundException {
		
		//Get HashMap mapping a page number to all line numbers with addresses corresponding to this page
		HashMap<Integer, ArrayList<Integer>> futurePages = optAlgHelper(filename);
		
		//Initialize counts
		int numMemAccesses = 0;
		int numPageFaults  = 0;
		int numWriteDisk   = 0;
				
		//Initialize scanner used to read the file
		Scanner scanner = new Scanner(new File(filename));
		
		//Read file and do calculations
		String[] splitStr = null;
		String line;
		int currentInstr = 0;			//Represents position of current instruction within file
		while(scanner.hasNext()) {
			line = scanner.nextLine();
			splitStr = line.trim().split("\\s+");
			if(splitStr[0].equals("I") || splitStr[0].equals("L") |
			   splitStr[0].equals("S") || splitStr[0].equals("M")) {
				
				//Find page and access page table to get entry
				String[] addressPart = splitStr[1].split(",");
				long l = Long.parseLong(addressPart[0], 16);
				int pageNum = (int) (l >>> 13);			  //Page# = VA/2^13 == VA >>> 13
				PageTableEntry pte = pageTable[pageNum];  //PageTableEntry = PT[Page#]
				
				if(pte.getValidBit() == 1) {
					System.out.println("hit");			  //Hit page message 
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.setDirtyBit(1);
					} else { 							  //if instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.setDirtyBit(1);
					}
					
					//Update HashMap to remove the current instruction from pageNum's ArrayList
					if(!futurePages.get(pageNum).contains(currentInstr)) {
						System.out.println("Error. Cannot find instruction: " + currentInstr);
					} else {
						futurePages.get(pageNum).remove(0);
					}

				} else {
					numPageFaults++;			//Increase Page Fault count
					
					//Iterate through RAM and find the page that is used farthest in the future
					int farthestPageFrame = 0;			  //Page frame number of farthest page
					int distanceOfFarthestPage = -1;      //Distance of farthest page from current instruction
					for(int i = 0; i < numFrames; i++) {
						//If frame is empty, use this frame
						if(ram[i] == null) {
							farthestPageFrame = i;
							break;
						} 
						
						int pn = ram[i].getPageNumber();		//Page number of page at frame i (at ram[i])
						
						//If page is never used again, immediately evict this page 
						if(futurePages.get(pn).isEmpty()) {
							farthestPageFrame = i;
							break;
						}
						
						//Find distance between next occurrence of page use and current instruction and compare.
						int ramiDistance = futurePages.get(pn).get(0) - currentInstr;	//# of instr.s in the future until page's next use
						if(ramiDistance > distanceOfFarthestPage) {
							farthestPageFrame = i;
							distanceOfFarthestPage = ramiDistance;
						}
					}

					//Update page table entry that is being evicted
					if(ram[farthestPageFrame] != null) {
						ram[farthestPageFrame].setValidBit(0);
						ram[farthestPageFrame].setPageFrameNum(-1);
						if(ram[farthestPageFrame].getDirtyBit() == 1) {
							numWriteDisk++;
							System.out.println("page fault - evict dirty");
						} else {
							System.out.println("page fault - evict clean");
						}
						ram[farthestPageFrame].setDirtyBit(0);
					} else {
						System.out.println("page fault - no eviction");
					}
					
					//Update page table entry that is being added
					ram[farthestPageFrame] = pte;
					pte.setDirtyBit(0);
					pte.setValidBit(1);
					pte.setPageFrameNum(farthestPageFrame);
					
					//Update HashMap to remove the current instruction from PageNum's ArrayList
					if(!futurePages.get(pageNum).contains(currentInstr)) {
						System.out.println("Error. Cannot find instruction: " + currentInstr);
					} else {
						futurePages.get(pageNum).remove(0);
					}
					
					//After updating RAM and PageTableEntries, update count(s)
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.setDirtyBit(1);
					} else { 							  //If instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.setDirtyBit(1);
					}
				}
			}
			currentInstr++;
		}
		
		scanner.close();     			//Close scanner 
		int[] retval = new int[3];
		retval[0] = numMemAccesses;
		retval[1] = numPageFaults;
		retval[2] = numWriteDisk;
		return retval;
	}
	
	
	/**********************************************************************/
	/*
	 * Purpose: Build and return a HashMap mapping all page numbers to a list of line numbers whose 
	 * 			address will fall into that given page. 
	 * Parameter: 
	 * 			filename: the name of the file to read; String type  
	 * Return: 
	 * 			futurePages: HashMap mapping page numbers to line numbers whose address maps
	 * 						 to the given page in the given file; HashMap<Integer, ArrayList<Integer>> type
	 */
	public static HashMap<Integer, ArrayList<Integer>> optAlgHelper(String filename) throws FileNotFoundException{
		
		//Initialize scanner, HashMap, and line number
		Scanner scanner = new Scanner(new File(filename));
		HashMap<Integer, ArrayList<Integer>> futurePages = new HashMap<Integer, ArrayList<Integer>>();
		int lineNum = 0;
		
		//Read file and save position of instruction corresponding to a page
		while(scanner.hasNext()) {
			String line = scanner.nextLine();
			String[] splitStr = line.trim().split("\\s+");
			if(splitStr[0].equals("I") || splitStr[0].equals("L") |
			   splitStr[0].equals("S") || splitStr[0].equals("M")) {
				
				//Find page number
				String[] addressPart = splitStr[1].split(",");
				long l = Long.parseLong(addressPart[0], 16);
				int pageNum = (int) (l >>> 13);			    //Page# = VA/2^13 == VA >>> 13
	
				if(futurePages.containsKey(pageNum)) {		//If page number is already seen, add line number
					futurePages.get(pageNum).add(lineNum);
				} else {									//Else, add page number and line number
					futurePages.put(pageNum, new ArrayList<Integer>());
					futurePages.get(pageNum).add(lineNum);
				}
			}
			lineNum++;
		}
		scanner.close();
		return futurePages;
	}
	
	
	/**********************************************************************/
	/*
	 * Purpose: Returns the statistics of the Clock Page Replacement Algorithm 
	 *          which uses the better implementation of the second-chance algorithm.
	 * Parameters:
	 * 	        filename: the file to read instructions from; string type
	 * 			pageTable: Page table with initialized page table entries; PageTableEntry array type
	 * 			ram: ram with null entries; PageTableEntry array type
	 * 			numFrames: the number of frames in ram; int type 
	 * Returns: 
	 * 			retval: array holding number of memory accesses, number of page faults, and number of 
	 * 				    writes to disk; int array type
	 */
	public static int[] clockAlgorithm(String filename, PageTableEntry[] pageTable, PageTableEntry[] ram, int numFrames) throws FileNotFoundException {
		
		int numMemAccesses = 0;
		int numPageFaults  = 0;
		int numWriteDisk   = 0;
		
		//Initialize scanner used to read the file
		Scanner scanner = new Scanner(new File(filename));
		
		//Read file and do calculations
		String[] splitStr = null;
		String line;
		int ramHead = 0;			//Head of clock set to 0 initially
		while(scanner.hasNext()) {
			line = scanner.nextLine();
			splitStr = line.trim().split("\\s+");
			if(splitStr[0].equals("I") || splitStr[0].equals("L") |
			   splitStr[0].equals("S") || splitStr[0].equals("M")) {
				
				//Find page and access page table to get entry
				String[] addressPart = splitStr[1].split(",");
				long l = Long.parseLong(addressPart[0], 16);
				int pageNum = (int) (l >>> 13);			  //Page# = VA/2^13 == VA >>> 13
				PageTableEntry pte = pageTable[pageNum];  //PageTableEntry = PT[Page#]
				
				//Page hit: valid bit of table entry is 1; there exists a valid mapping to RAM
				if(pte.getValidBit() == 1) {
					System.out.println("hit");			  //Hit page message 
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.setDirtyBit(1);
					} else { 							  //If instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.setDirtyBit(1);
					}
					
					pte.setReferencedBit(1); 			  //Update reference bit
				
				//Page Fault: no mapping exists so we need to find a frame to use
				} else {
					numPageFaults++;					  //Increase page fault count
					
					//Find page to evict taking into account the head pointer in ram
					int pageToEvict = 0;
					int curr = -1;
					for(int i = 0; i < 2*numFrames; i++) {
						curr = (i + ramHead)%numFrames;			//index of current ram entry
						if(ram[curr] == null) {					//If frame is empty, use frame.
							pageToEvict = curr;
							break;
						}
						if(ram[curr].getReferencedBit() == 0) {	//If reference bit is 0, use this frame
							pageToEvict = curr;
							break;
						} else {								//Else, set reference bit to 0
							ram[curr].setReferencedBit(0);
						}
					}
					ramHead = (curr + 1)%numFrames;			//Set head to the frame after the evicted frame
					
					//If old entry is not null, reset its values.
					if(ram[pageToEvict] != null) {
						ram[pageToEvict].setValidBit(0);
						ram[pageToEvict].setPageFrameNum(-1);
						if(ram[pageToEvict].getDirtyBit() == 1) {
							numWriteDisk++;
							System.out.println("page fault - evict dirty");
						} else {
							System.out.println("page fault - evict clean");
						}
						ram[pageToEvict].setDirtyBit(0);
						ram[pageToEvict].setReferencedBit(0);
					} else {
						System.out.println("page fault - no eviction");
					}
					
					//Set values for new entry and save entry in RAM 
					ram[pageToEvict] = pte;
					pte.setDirtyBit(0);
					pte.setValidBit(1);
					pte.setPageFrameNum(pageToEvict);
					pte.setReferencedBit(1);
					
					//After updating RAM and PageTableEntries, update correct count(s)
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.setDirtyBit(1);
					} else { 							  //If instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.setDirtyBit(1);
					}
				}
			}
		}
		
		scanner.close();     			//Close scanner 
		int[] retval = new int[3];
		retval[0] = numMemAccesses;
		retval[1] = numPageFaults;
		retval[2] = numWriteDisk;
		return retval;
	}

	
	/**********************************************************************/
	/*
	 * Purpose: Returns the statistics of the LRU Page Replacement Algorithm 
	 *          which evicts the least recently used page. Note: I will use line numbers
	 *          as the way to differentiate the time of usage for a page. 
	 * Parameters:
	 * 	        filename: the file to read instructions from; string type
	 * 			pageTable: Page table with initialized page table entries; PageTableEntry array type
	 * 			ram: ram with null entries; PageTableEntry array type
	 * 			numFrames: the number of frames in ram; int type 
	 * Returns: 
	 * 			retval: array holding number of memory accesses, number of page faults, and number of 
	 * 				    writes to disk; int array type
	 */
	public static int[] lruAlgorithm(String filename, PageTableEntry[] pageTable, PageTableEntry[] ram, int numFrames) throws FileNotFoundException {
		
		int numMemAccesses = 0;
		int numPageFaults  = 0;
		int numWriteDisk   = 0;
		int lineNum = 0;		  //Line number in the file
		
		//Initialize scanner used to read the file
		Scanner scanner = new Scanner(new File(filename));
		
		//Read file and do calculations
		while(scanner.hasNext()) {
			String line = scanner.nextLine();
			String[] splitStr = line.trim().split("\\s+");
			
			if(splitStr[0].equals("I") || splitStr[0].equals("L") |
			   splitStr[0].equals("S") || splitStr[0].equals("M")) {
				
				//Find page and access page table to get entry
				String[] addressPart = splitStr[1].split(",");
				long l = Long.parseLong(addressPart[0], 16);
				int pageNum = (int) (l >>> 13);			  //Page# = VA/2^13 == VA >>> 13
				PageTableEntry pte = pageTable[pageNum];  //PageTableEntry = PT[Page#]

				//If valid bit of table entry is 1, there exists a valid mapping to RAM 
				if(pte.getValidBit() == 1) {		
					System.out.println("hit");			  //Hit page message 
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.setDirtyBit(1);
					} else { 							  //If instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.setDirtyBit(1);
					}
					
					pte.setLineNumber(lineNum);

				//Else, no mapping exists so we need to find a frame to use
				} else {
					numPageFaults++;					  //Increase page fault count
					
					//Need to find page that was least recently used by comparing line numbers
					int least = 0; 
					for(int i = 0; i < numFrames; i++) {
						if(ram[i] == null) {
							least = i;
							break;
						}
						if(ram[i].getLineNumber() < ram[least].getLineNumber()) {
							least = i;
						}
					}

					//If old entry is not null, reset its values. Check if it's dirty or not too.
					if(ram[least] != null) {
						ram[least].setValidBit(0);				//Set valid bit to 0 for old entry
						ram[least].setPageFrameNum(-1);         //Set page frame for old entry
						if(ram[least].getDirtyBit() == 1) {	    //If dirty, increase write to disk count
							numWriteDisk++;
							System.out.println("page fault - evict dirty");
						} else {
							System.out.println("page fault - evict clean");
						}
						ram[least].setDirtyBit(0); 				//Reset dirty bit
					} else {
						System.out.println("page fault - no eviction");
					}

					//Set values for new entry and save entry in RAM
					ram[least] = pte;
					pte.setDirtyBit(0);							//Reset dirty bit
					pte.setValidBit(1);							//Set valid bit 
					pte.setPageFrameNum(least);				    //Update page frame number for new entry
					pte.setLineNumber(lineNum); 				//Update line number for new entry 

					//After updating RAM and PageTableEntries, update correct count(s)
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.setDirtyBit(1);
					} else { 							  //If instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.setDirtyBit(1);
					}
				}
			}
			lineNum++;
		}
		
		scanner.close();     			//Close scanner 
		int[] retval = new int[3];
		retval[0] = numMemAccesses;
		retval[1] = numPageFaults;
		retval[2] = numWriteDisk;
		return retval;
	}
	
	
	/**********************************************************************/
	/*
	 * Purpose: Returns the statistics of the NFU Page Replacement Algorithm 
	 *          which evicts the page whose referenced count (frequency of use) 
	 *          since loaded is the lowest. 
	 * Parameters:
	 * 	        filename: the file to read instructions from; string type
	 * 			pageTable: Page table with initialized page table entries; PageTableEntry array type
	 * 			ram: ram with null entries; PageTableEntry array type
	 * 			numFrames: the number of frames in ram; int type 
	 * Returns: 
	 * 			retval: array holding number of memory accesses, number of page faults, and number of 
	 * 				    writes to disk; int array type
	 */
	public static int[] nfuAlgorithm(String filename, PageTableEntry[] pageTable, PageTableEntry[] ram, int numFrames) throws FileNotFoundException {
		
		int numMemAccesses = 0;
		int numPageFaults  = 0;
		int numWriteDisk   = 0;
	
		//Initialize scanner used to read the file
		Scanner scanner = new Scanner(new File(filename));
		
		//Read file and collect statistics on nfu algorithm
		while(scanner.hasNext()) { 
			String line = scanner.nextLine();
			String[] splitStr = line.trim().split("\\s+");
			
			if(splitStr[0].equals("I") || splitStr[0].equals("L") |
			   splitStr[0].equals("S") || splitStr[0].equals("M")) {

				//Find page and access page table to get entry
				String[] addressPart = splitStr[1].split(",");
				long l = Long.parseLong(addressPart[0], 16);
				int pageNum = (int) (l >>> 13);			  //Page# = VA/2^13 == VA >>> 13
				PageTableEntry pte = pageTable[pageNum];  //PageTableEntry = PT[Page#]
		
				//If valid bit of table entry is 1, there exists a valid mapping to RAM 
				if(pte.getValidBit() == 1) {		
					System.out.println("hit");			  //Hit page message 
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
						pte.increaseReferenceCount();
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
						pte.increaseReferenceCount();
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.increaseReferenceCount();
						pte.setDirtyBit(1);
					} else { 							  //If instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.increaseReferenceCount();
						pte.setDirtyBit(1);
					}
					
				//Else, no mapping exists so we need to find a frame to use
				} else {
					numPageFaults++;					  //Increase page fault count
	
					//Iterate through RAM and find the lowest reference count 
					int lowest = 0;
					for(int i = 0; i < numFrames; i++) { 
						if(ram[i] == null) {		      //If frame is empty, use this frame
							lowest = i;
							break; 
						}						          //Otherwise, compare reference counts 
						if(ram[i].getReferenceCount() < ram[lowest].getReferenceCount()) {
							lowest = i;
						}
					}

					//If old entry is not null, reset values. Check if dirty or not too.
					if(ram[lowest] != null) {
						ram[lowest].setReferenceCount(0); 		//Reset reference court for old entry
						ram[lowest].setValidBit(0);				//Set valid bit to 0 for old entry
						ram[lowest].setPageFrameNum(-1);        //Set page frame for old entry
						if(ram[lowest].getDirtyBit() == 1) {	//If dirty, increase write to disk count
							numWriteDisk++;
							System.out.println("page fault - evict dirty");
						} else {
							System.out.println("page fault - evict clean");
						}
						ram[lowest].setDirtyBit(0); 			//Reset dirty bit
					} else {
						System.out.println("page fault - no eviction");
					}
					
					//Set values for new entry and save entry in RAM
					pte.setValidBit(1);						//Set valid bit to 1 for new entry
					pte.setPageFrameNum(lowest);			//Set page frame number to frame number 
					pte.setReferenceCount(0);				//Set reference count
					ram[lowest] = pte;						//Store page table entry in RAM
					
					//After updating RAM and PageTableEntries, update count(s) 
					if(splitStr[0].equals("I")){          //If instruction is a memory access
						numMemAccesses++;
					} else if(splitStr[0].equals("L")) {  //If instruction is a load 
						numMemAccesses++;
					} else if(splitStr[0].equals("S")) {  //If instruction is a store 
						numMemAccesses++;
						pte.setDirtyBit(1);
					} else { 							  //If instruction is a modify (load and store)
						numMemAccesses++;
						numMemAccesses++;
						pte.setDirtyBit(1);
					}
				}
			}
		}
		
		scanner.close();     			//Close scanner 
		int[] retval = new int[3];
		retval[0] = numMemAccesses;
		retval[1] = numPageFaults;
		retval[2] = numWriteDisk;
		return retval;
	}
}
