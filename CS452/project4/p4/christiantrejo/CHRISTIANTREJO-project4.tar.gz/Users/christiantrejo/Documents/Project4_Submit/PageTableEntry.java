/*
 * Author: Christian Trejo
 * Course: CSC452
 * Assignment: Project 4 - Virtual Memory Simulator 
 * Due: Tuesday, April 22, 2022, by 11:59pm 
 * Purpose: This class will hold all fields found in a page table entry, along with some 
 * 			other information, and will be used in the page replacement algorithms found
 * 			vmsim.java. 
 */
public class PageTableEntry {
	
	private int dirtyBit;			//Dirty bit
	private int referencedBit;		//Reference bit
	private int validBit;			//Valid bit
	private int pageFrameNum;		//Current Page Frame Number 
	private int referenceCount;		//Number of times page has been referenced (used in NFU)
	private int lineNumber;			//Last time page was used (used in LRU)
	private int pageNumber;			//Page number in page table
	
	
	/*
	 * Purpose: Constructor for page table entry object
	 * Parameters: None
	 */
	public PageTableEntry() {
		dirtyBit       = 0;
		referencedBit  = 1;
		validBit       = 0;
		pageFrameNum   = -1;
		referenceCount = 0;
		lineNumber     = -1;
		pageNumber     = -1;
	}
	

	/*********************Getters*********************/
	/*
	 * Purpose: Returns the dirty bit associated with page table entry.
	 * Parameter: None 
	 * Returns: dirty bit; int type
	 */
	public int getDirtyBit() {
		return dirtyBit;
	}
	
	/*
	 * Purpose: Returns the reference bit associated with page table entry. 
	 * Parameter: None 
	 * Returns: reference bit; int type
	 */
	public int getReferencedBit() {
		return referencedBit;
	}
	
	/*
	 * Purpose: Returns the valid bit associated with page table entry.
	 * Parameter: None 
	 * Returns: valid bit; int type
	 */
	public int getValidBit() {
		return validBit;
	}
	
	/*
	 * Purpose: Returns the page frame number associated with page table entry.
	 * Parameter: None 
	 * Returns: page frame number; int type
	 */
	public int getPageFrameNum() {
		return pageFrameNum;
	}
	
	/*
	 * Purpose: Returns the number of times the page table entry has been referenced. 
	 * Parameter: None 
	 * Returns: reference count; int type
	 */
	public int getReferenceCount() {
		return referenceCount;
	}
	
	/*
	 * Purpose: Returns the line number of the file that last used the page.
	 * Parameter: None 
	 * Returns: line number; int type
	 */
	public int getLineNumber() {
		return lineNumber;
	}
	
	/*
	 * Purpose: Returns the page number associated with page table entry. 
	 * 			In other words, it returns where the page is located in the page table. 
	 * Parameter: None 
	 * Returns: page number; int type
	 */
	public int getPageNumber() {
		return pageNumber;
	}
	
	
	/*********************Setters*********************/
	/*
	 * Purpose: Set the dirty bit associated with page table entry.
	 * Parameter: val - value is either 0 or 1; int type; 
	 * Returns: None
	 */
	public void setDirtyBit(int val) {
		dirtyBit = val;
	}
	
	/*
	 * Purpose: Set the referenced bit associated with page table entry.
	 * Parameter: val - value is either 0 or 1; int type; 
	 * Returns: None
	 */
	public void setReferencedBit(int val) {
		referencedBit = val;
	}
	
	/*
	 * Purpose: Set the valid bit associated with page table entry.
	 * Parameter: val - value is either 0 or 1; int type; 
	 * Returns: None
	 */
	public void setValidBit(int val) {
		validBit = val;
	}

	/*
	 * Purpose: Set the page frame number associated with page table entry.
	 * Parameter: val - value of page frame number; int type; 
	 * Returns: None
	 */
	public void setPageFrameNum(int val) {
		pageFrameNum = val;
	}
	
	/*
	 * Purpose: Set the reference count associated with page table entry.
	 * Parameter: val - new reference count; int type; 
	 * Returns: None
	 */
	public void setReferenceCount(int val) {
		referenceCount = val;
	}
	
	/*
	 * Purpose: Increase the reference count by 1.
	 * Parameter: None 
	 * Returns: None
	 */
	public void increaseReferenceCount() {
		referenceCount++;
	}
	
	/*
	 * Purpose: Set the line number field to the line number of the file where the page 
	 * 			was last used. 
	 * Parameter: val - new line number; int type; 
	 * Returns: None
	 */
	public void setLineNumber(int line) {
		lineNumber = line;
	}
	
	/*
	 * Purpose: Set the page number, which is the location of the page in the page table.
	 * Parameter: pn - value of page number; int type; 
	 * Returns: None
	 */
	public void setPageNumber(int pn) {
		pageNumber = pn;
	}
}
