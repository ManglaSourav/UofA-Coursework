
/*
Jiwon Seo
CSC 452 Project 4
04/12/2022
Vmsim.java
run: java vmsim -n <numframe> -a <opt|clock|lru | nfu> <tracefile>
simultate virtual memory algorithm 
*/
import java.io.*;
import java.util.*;

public class vmsim {

    public static int memAccess = 0;
    public static int pageFaults = 0;
    public static int writes = 0;
    public static String traceFile = "";
    public static ArrayList<String> hex;
    public static ArrayList<String> accessOpt;
    public static ArrayList<Page> pageTable;
    public static int[] frameArray;

    public static void main(String[] args) throws IOException {
        int numFrames = 0;
        String algChoice = "Initializing algChoice";
        // Looks at arguments at sets values appropriately.
        for (int i = 0; i < args.length; ++i) {
            if (args[i].equals("-n")) {
                numFrames = Integer.parseInt(args[i + 1]);
            } else if (args[i].equals("-a")) {
                algChoice = args[i + 1];
            } else if (i == args.length - 1) {
                traceFile = args[i];
            }
        }

        // Creates Page Table
        pageTable = new ArrayList<>();
        int maxPages = 1024 * 512 * 2;

        for (int i = 0; i < maxPages; i++) {
            Page entry = new Page();
            pageTable.add(i, entry);
        }
        hex = new ArrayList<>();
        accessOpt = new ArrayList<>();
        frameArray = new int[numFrames];

        for (int i = 0; i < numFrames; i++) {
            frameArray[i] = -1;
        }

        // depending on the choice, move to the method.
        if (algChoice.equals("opt")) {
            opt(numFrames, traceFile);
        }
        if (algChoice.equals("clock")) {
            clock(numFrames, traceFile);
        }
        if (algChoice.equals("nfu")) {
            nfu(numFrames, traceFile);
        }
        if (algChoice.equals("lru")) {
            lru(numFrames, traceFile);
        }
    }

    /*
     * Optimal Page Replacement algorithm. : OPT
     */

    public static void opt(int numframes, String trace) throws FileNotFoundException {
        int pageFaults = 0;
        int memoryAccesses = 0;
        int diskWrites = 0;
        int[] frames = new int[numframes];

        // create our page table
        Hashtable<Integer, Page> pt = new Hashtable<Integer, Page>();
        for (int i = 0; i < 1024 * 512; i++)
            pt.put(i, new Page());

        // we are using linkedlist within the hashtable.
        Hashtable<Integer, LinkedList<Integer>> opt = new Hashtable<Integer, LinkedList<Integer>>();
        int count = 0;
        BufferedReader br = null;
        try {// organize the trace file, give up trash lines.
            for (int i = 0; i < numframes; i++) {
                frames[i] = -1;
            }
            br = new BufferedReader(new FileReader(trace));
            for (int k = 0; k < 37; k++) {
                br.readLine();
            }
            while (br.ready()) {
                String lines = br.readLine();
                String[] line = null;
                // System.out.println(lines);
                if (lines.startsWith("I")) {
                    line = lines.split("  ");
                } else if (lines.startsWith(" ")) {
                    lines = lines.substring(1);
                    line = lines.split(" ");
                } else if (lines.startsWith("==")) {
                    break;
                } else {
                    continue;
                }
                int pagenum = Integer.decode("0X" + line[1].split(",")[0].substring(0, 5));
                if (opt.get(pagenum) == null) {
                    opt.put(pagenum, new LinkedList<Integer>());
                    opt.get(pagenum).add(count);
                } else
                    opt.get(pagenum).add(count);
                count++;
            }

            for (int i = 0; i < 37; i++) {
                br.readLine();
            }
            br = new BufferedReader(new FileReader(trace));
            int fr = 0;
            while (br.ready()) {
                memoryAccesses++;
                String lines = br.readLine();
                String[] line = null;
                if (lines.startsWith("I")) {
                    line = lines.split("  ");
                } else if (lines.startsWith(" ")) {
                    lines = lines.substring(1);
                    line = lines.split(" ");
                } else if (lines.startsWith("==")) {
                    break;
                } else {
                    continue;
                }
                int pagenum = Integer.decode("0x" + line[1].split(",")[0].substring(0, 5));
                opt.get(pagenum).removeFirst();
                Page cur = pt.get(pagenum);
                cur.ref = true;
                cur.index = pagenum;
                if (line[1].equals("S") || line[1].equals("M"))
                    cur.dirty = true;
                if (cur.valid == true)
                    continue;
                else {
                    pageFaults++;
                    if (fr < numframes) {
                        frames[fr] = pagenum;
                        cur.valid = true;
                        cur.frame = fr;
                        fr++;
                    } else {
                        // if we make it here we need to find the page w/ the longest distance until
                        // use and evict it
                        int longest = 0;
                        int page = 0;
                        for (int i = 0; i < frames.length; i++) {
                            if (opt.get(frames[i]).isEmpty()) {
                                page = frames[i];
                                break;
                            } else {
                                if (opt.get(frames[i]).get(0) > longest) {
                                    longest = opt.get(frames[i]).get(0);
                                    page = frames[i];
                                }
                            }
                        }
                        Page evictPage = pt.get(page);
                        if (evictPage.dirty == true)
                            diskWrites++;
                        // update values for pte in the ram
                        cur.frame = evictPage.frame;
                        frames[evictPage.frame] = pagenum;
                        cur.valid = true;
                        // update values for pte being evicted & reset the value as original.
                        evictPage.frame = -1;
                        evictPage.valid = false;
                        evictPage.ref = false;
                        evictPage.dirty = false;
                        pt.put(evictPage.index, evictPage);
                    }

                }
                // put pte going into ram back into page table w/ updated values
                pt.put(pagenum, cur);
            }
            System.out.println("Algorithm: Opt");
            System.out.println("Number of Frames: " + numframes);
            System.out.println("Total memory accesses: " + memoryAccesses);
            System.out.println("Total Page faults: " + pageFaults);
            System.out.println("Total writes to disk: " + diskWrites + " bytes");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /*
     * Clock algorithm
     */

    public static void clock(int numframes, String trace) throws FileNotFoundException {
        int pageFaults = 0;
        int memoryAccesses = 0;
        int diskWrites = 0;
        // to keep track of clock pointer
        int clock = 0;
        // to represent physical memory
        int[] frames = new int[numframes];
        // page table with Page obj.
        Hashtable<Integer, Page> pt = new Hashtable<Integer, Page>();

        // initialize our page table
        for (int i = 0; i < 1024 * 512; i++){
            Page p = new Page();
            pt.put(i, p);
        }
        for (int j = 0; j < frames.length; j++) {
            frames[j] = -1; // initialize the freame value.
        }
        int fr = 0;

       
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(trace));
            for(int k=0; k<37; k++){
                br.readLine();
            }
            while (br.ready()) {
                String lines = br.readLine();
                String[] line = null;
                System.out.println(lines);
                // trash the unnecessary lines.
                if (lines.startsWith("I")) {
                    line = lines.split("  ");
                } else if (lines.startsWith(" ")) {
                    lines = lines.substring(1);
                    line = lines.split(" ");

                } else if (lines.startsWith("==")) {
                    break;
                } else {
                    continue;
                }
                System.out.println(Integer.decode("0x"+line[1].split(",")[0].substring(0,5)));
                // get the page number for this address
                int pagenum = Integer.decode("0x" + line[1].split(",")[0].substring(0, 5));
               
                Page cur = pt.get(pagenum);
                // update the pte with information we have/ read
                cur.index = pagenum;
                if (line[1].equals("S")|| line[1].equals("M")){
                    cur.dirty = true;
                }
               
                cur.ref = true;

                if (!cur.valid) {
                    pageFaults++;
                    if (fr < numframes) {
                        frames[fr] = cur.index;
                        // update the page table entry
                        cur.valid = true;
                        cur.frame = fr;
                        fr++;
                    } else { // actual clock part
                        boolean done = false;
                        int evict = 0;
                        while (!done) {
                            if (clock == frames.length || clock < 0)
                                clock = 0;
                            if (!pt.get(frames[clock]).ref) {
                                // we want to evict the uncessary entry from the clock.
                                evict = frames[clock];
                                done = true;
                            } else {
                                // switch it to unreferenced.
                                pt.get(frames[clock]).ref = false;
                            }
                            clock++;
                        }
                        // evict and sqap to new page.
                        Page evictPage = pt.get(evict);
                        if (evictPage.dirty)
                            diskWrites++;
                        // update values for pte going into ram
                        frames[evictPage.frame] = cur.index;
                        cur.frame = evictPage.frame;
                        cur.valid = true;
                        cur.valid = true;
                        // update values for pte being evicted & reset the value as initial
                        evictPage.dirty = false;
                        evictPage.ref = false;
                        evictPage.valid = false;
                        evictPage.frame = -1;
                        pt.put(evict, evictPage);
                    }
                    // put pte going into ram back into page table w/ updated values
                }
                pt.put(pagenum, cur);
                memoryAccesses++;

            }
            System.out.println("Algorithm: Clock");
            System.out.println("Number of Frames: " + numframes);
            System.out.println("Total memory accesses: " + memoryAccesses);
            System.out.println("Total Page faults: " + pageFaults);
            System.out.println("Total writes to disk: " + diskWrites + " bytes");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void lru(int numframes, String trace) throws FileNotFoundException {
        int pageFaults = 0;
        int memoryAccesses = 0;
        int diskWrites = 0;
        int[] frames = new int[numframes];

        // create our page table & initialize it
        Hashtable<Integer, Page> pt = new Hashtable<Integer, Page>();
        for (int i = 0; i < 1042 * 512; i++)
            pt.put(i, new Page());

        File f = new File(trace);
        Scanner scan = new Scanner(f);
        int fr = 0;
        int count = 0;

        String[] readLine = null;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            if (line.startsWith("I")) {
                readLine = line.split("  ");
            } else if (line.startsWith(" ")) {
                line = line.substring(1);
                readLine = line.split(" ");
            } else if (line.startsWith("==")) {
                break;
            } else {
                continue;
            }
            memoryAccesses++;
            int pagenum = (int) (Long.decode("0X" + readLine[1].split(",")[0]) / 32000);
            Page cur = pt.get(pagenum);
            // update the pte w/ information we have
            cur.index = pagenum;
            cur.address = readLine[1].split(",")[0];
            cur.ref = true;
            cur.timestamp = count;
            if (readLine[0].equalsIgnoreCase("S"))
                cur.dirty = true;
            if (readLine[0].equalsIgnoreCase("M"))
                cur.dirty = true;

            if (cur.valid == false) {
                pageFaults++;
                if (fr < numframes) {
                    // put the page in the next memory
                    frames[fr] = pagenum;
                    // update the page table entry
                    cur.valid = true;
                    cur.frame = fr;
                    fr++;
                } else { // lru main part.
                    int least = -1;
                    int evict = -1;
                    for (int i = 0; i < frames.length; i++) {
                        if (evict == -1) {
                            evict = pt.get(frames[i]).index;
                            least = pt.get(frames[i]).timestamp;
                        } else if (pt.get(frames[i]).timestamp < least) {
                            evict = pt.get(frames[i]).index;
                            least = pt.get(frames[i]).timestamp;
                        }
                    }
                    // evict and swap in the new page
                    Page evictPage = pt.get(evict);
                    if (evictPage.dirty)
                        diskWrites++;
                    // update values for pte going into ram
                    cur.frame = evictPage.frame;
                    frames[evictPage.frame] = pagenum;
                    cur.valid = true;
                    // update values for pte being evicted and reset the page with original value.
                    evictPage.frame = -1;
                    evictPage.valid = false;
                    evictPage.ref = false;
                    evictPage.dirty = false;
                    pt.put(evict, evictPage);
                }

            }
            // put pte going into ram back into page table w/ updated values
            pt.put(pagenum, cur);
        }
        System.out.println("Algorithm: LRU");
        System.out.println("Number of Frames: " + numframes);
        System.out.println("Total memory accesses: " + memoryAccesses);
        System.out.println("Total Page faults: " + pageFaults);
        System.out.println("Total writes to disk: " + diskWrites + " bytes");
        scan.close();
    }

    public static void nfu(int numframes, String trace) throws FileNotFoundException {
        int pageFaults = 0;
        int memoryAccesses = 0;
        int diskWrites = 0;
        int[] frames = new int[numframes];

        // create our page table
        Hashtable<Integer, Page> pt = new Hashtable<Integer, Page>();
        for (int i = 0; i < 1042 * 512; i++)
            pt.put(i, new Page());

        File f = new File(trace);
        Scanner scan = new Scanner(f);
        int fr = 0;
        int count = 0;

        String[] readLine = null;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            if (line.startsWith("I")) {
                readLine = line.split("  ");
            } else if (line.startsWith(" ")) {
                line = line.substring(1);
                readLine = line.split(" ");
            } else if (line.startsWith("==")) {
                break;
            } else {
                continue;
            }
            memoryAccesses++;
            // get the page number for this address
            int pagenum = Integer.decode("0X" + readLine[1].split(",")[0].substring(0, 5));
            Page cur = pt.get(pagenum);
            // update the pte with info we have
            cur.index = pagenum;
            cur.address = readLine[1].split(",")[0];
            cur.ref = true;
            cur.timestamp = count;
            if (readLine[0].equals("S"))
                cur.dirty = true;
            if (readLine[0].equals("M"))
                cur.dirty = true;

            if (cur.valid == false) {
                pageFaults++;
                if (fr < numframes) {
                    frames[fr] = pagenum;
                    // update the page table entry
                    cur.valid = true;
                    cur.frame = fr;
                    fr++;
                } else { // main lru part
                    int least = -1;
                    int evict = -1;
                    for (int i = 0; i < frames.length; i++) {
                        if (evict == -1) {
                            evict = pt.get(frames[i]).index;
                            least = pt.get(frames[i]).timestamp;
                        } else if (pt.get(frames[i]).timestamp < least) {
                            evict = pt.get(frames[i]).index;
                            least = pt.get(frames[i]).timestamp;
                        }
                    }
                    // evict and swap in the new page
                    Page evictPage = pt.get(evict);
                    if (evictPage.dirty)
                        diskWrites++;
                    // update values for pte going into ram
                    cur.frame = evictPage.frame;
                    frames[evictPage.frame] = pagenum;
                    cur.valid = true;
                    // update values for pte being evicted & put it back into the page table
                    evictPage.frame = -1;
                    evictPage.valid = false;
                    evictPage.ref = false;
                    evictPage.dirty = false;
                    pt.put(evict, evictPage);
                }

            }
            // put pte going into ram back into page table w/ updated values
            pt.put(pagenum, cur);
        }
        System.out.println("Algorithm: NFU");
        System.out.println("Number of Frames: " + numframes);
        System.out.println("Total memory accesses: " + memoryAccesses);
        System.out.println("Total Page faults: " + pageFaults);
        System.out.println("Total writes to disk: " + diskWrites + " bytes");
        scan.close();
    }
}