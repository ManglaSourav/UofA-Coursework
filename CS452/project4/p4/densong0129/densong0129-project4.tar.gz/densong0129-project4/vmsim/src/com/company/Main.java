package com.company;

import java.io.File;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Scanner;

public class Main {

    public static class Page {
        public long vAddress;
        public int frameNumber;
        public boolean valid;
        public boolean referenced;
        public boolean dirty;

        public Page(long vAddress) {
            this.vAddress = vAddress;
            this.valid = false;
            this.referenced = false;
            this.dirty = false;
        }
    }

    public static class Frame {
        public Page page;

        public Frame() {
            page = null;
        }
    }

    static final int PAGESIZE = 8192;
    static String[] ALGORITHMS = {"opt", "clock", "lru", "nfu"};
    static int pageFaults = 0;
    static int memAccess = 0;
    static int writes = 0;
    static int numFrames;
    static int pageTableSize;

    public static void errorHandling() {
        System.err.println("Arguments should look like 'vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>'");
        System.exit(1);
    }

    public static boolean isInteger(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void clock(ArrayList<String> traces) {
        int pointer = 0;

        Frame[] ram = new Frame[numFrames];
        for (int i = 0; i < numFrames; i++) {
            ram[i] = new Frame();
        }

        Page[] pageTable = new Page[(int) Math.pow(2, 19)];
        pageTableSize = (int) Math.pow(2, 19);
        int frameNumber = 0;
        for (int i = 0; i < Math.pow(2, 19); i++) {
            Page page = new Page(i);
            page.frameNumber = frameNumber;
            pageTable[i] = page;
        }

        for (int i = 0; i < traces.size(); i++) {
            String trace = traces.get(i);
            String[] splitTrace = trace.split(" ");

            String va, type;
            if (splitTrace.length == 3) {
                memAccess++;
                type = splitTrace[1];
                va = splitTrace[2].split(",")[0];
            } else {
                type = splitTrace[0];
                va = splitTrace[1].split(",")[0];
            }

            long vAdr = Long.parseLong(va);
            long pageNum = vAdr/PAGESIZE;

            if (!pageTable[(int) pageNum].valid) {
                pageFaults++;

                Page curr = ram[pageTable[(int) pageNum].frameNumber].page;
                if (curr != null) curr.valid = false;
                ram[pageTable[(int) pageNum].frameNumber].page = pageTable[(int) pageNum];
                pageTable[(int) pageNum].valid = true;
            }

        }
    }

    public static void main(String[] args) {
        // PARSING THE ARGUMENTS WHICH WERE PASSED VIA INVOCATION
        if (args.length != 5) {
	        System.err.println("Invalid number of arguments used when invoking vmsim");
	        errorHandling();
        } else {

            // if the -n or -a flag cannot be found within the first 4 indices
            // then the program wasn't invoked correctly.
            int nFlag = -1;
            int aFlag = -1;
	        for (int i = 0; i < 4; i++) {
	            if (args[i].equals("-n"))
	                nFlag = i;
	            else if (args[i].equals("-a"))
	                aFlag = i;
            }
	        if (nFlag == -1 || aFlag == -1)
	            errorHandling();

	        numFrames = 0;
	        if (!isInteger(args[nFlag + 1]))
	            errorHandling();
	        else numFrames = Integer.parseInt(args[nFlag + 1]);

	        // Compare the inputted -a argument to the possible arguments allowed
	        String alg = null;
	        for (int i = 0; i < 4; i++) {
                if (args[aFlag + 1].equals(ALGORITHMS[i])) {
                    alg = ALGORITHMS[i];
                    break;
                }
            }
	        if (alg == null) errorHandling();

	        // Search for the argument <tracefile> (it shouldn't have an argument before it)
	        String traceFile = null;
            for (int i = 0; i < 5; i++) {
	            if (i == nFlag || i == aFlag) continue;
	            if (i == nFlag + 1 || i == aFlag + 1) continue;
	            traceFile = args[i];
            }
            if (traceFile == null) errorHandling();
            File file = new File(traceFile);
            ArrayList<String> traces = new ArrayList<String>();;
            try {
                Scanner trace = new Scanner(file);
                while (trace.hasNext()){
                    String line = trace.next();
                    if (line.substring(0, 1).equals("I") || line.substring(0, 1).equals(" "))
                        traces.add(line);
                }
            } catch (Exception e){
                System.err.println("Tracefile not found");
                errorHandling();
            }

            if (alg.equals("OPT")) {
                System.out.println("not implemented yet");
            } else if (alg.equals("clock")){
                clock(traces);
            }

            System.out.println("Algorithm: " + alg);
            System.out.println("Number of frames: " + numFrames);
            System.out.println("Total memory accesses: " + pageFaults);
            System.out.println("Total writes to disk: " + writes);
            System.out.println("Total size of pageTable:        " + pageTableSize + " bytes");
            System.exit(0);
        }

    }
}
