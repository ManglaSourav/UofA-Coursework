package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class represents a reader for instructions specified in a file
 */
public class InstructionReader implements Iterable<Instruction> {

    /** BufferedReader to read each instruction line from */
    private BufferedReader br;
    /** Regex for reading in a line with an instruction */
    private static final Pattern LINE_REGEX = Pattern.compile("^\\s*([ILSM])\\s+([0-9a-fA-F]*),\\d+$");

    /**
     * Creates an instruction reader
     * @param br is the BufferedReader to read lines from
     */
    public InstructionReader(BufferedReader br) {
        this.br = br;
    }

    @Override
    public Iterator<Instruction> iterator() {
        return new InstructionIterator();
    }

    private class InstructionIterator implements Iterator<Instruction> {

        /** Current instruction (will be returned next) */
        private Instruction cur = null;

        public InstructionIterator() {
            this.loadNextInstruction();
        }

        /**
         * Loads the next instruction to return
         */
        private void loadNextInstruction() {
            // Read in first line from file reader
            String curLine = null;
            try {
                curLine = br.readLine();
            } catch (IOException e) {
                return;
            }

            while (curLine != null) {
                Matcher m = LINE_REGEX.matcher(curLine);
                if (m.find()) {
                    // Found an instruction
                    this.cur = new Instruction(Long.parseLong(m.group(2), 16), m.group(1));
                    return;
                }

                // Read the next line
                try {
                    curLine = br.readLine();
                } catch (IOException e) {
                    return;
                }
            }
        }

        @Override
        public boolean hasNext() {
            return (cur != null);
        }

        @Override
        public Instruction next() {
            Instruction instruction = this.cur;
            this.cur = null;
            this.loadNextInstruction();
            return instruction;
        }

    }

}