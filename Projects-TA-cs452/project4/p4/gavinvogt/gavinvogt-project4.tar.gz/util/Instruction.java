package util;

/**
 * This class represents an instruction
 */
public class Instruction {

    /** Address the instruction accesses */
    public final long address;
    /** Type (I, L, S, or M) */
    private final String type;
    /** Number of bytes in a page (8 KB) */
    private static double PAGE_SIZE = Math.pow(2, 13); // 8 KB

    /**
     * Creates an instruction to process
     * 
     * @param address is the address the instruction accesses
     * @param type    is the type of access
     */
    public Instruction(long address, String type) {
        this.address = address;
        this.type = type;
    }

    /**
     * Gets the page number the instruction accesses
     * 
     * @return page number accessed
     */
    public int pageNumber() {
        return (int) (address / PAGE_SIZE);
    }

    /**
     * Checks if this instruction is a read
     * 
     * @return whether the instruction involves a read from memory
     */
    public boolean isRead() {
        // Instruction, Load, and Modify
        return (this.type.equals("I") || this.type.equals("L") || this.type.equals("M"));
    }

    /**
     * Checks if this instruction is a write
     * 
     * @return whether the instruction involves a write to memory
     */
    public boolean isWrite() {
        // Store and Modify
        return (this.type.equals("S") || this.type.equals("M"));
    }

}