/*
 * File: vmsim.java
 * Author: Gavin Vogt
 * This program runs the virtual memory simulation using the given algorithm
 * and number of frames on the provided instruction file.
 * 
 * Usage: vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import algorithms.Algorithm;
import algorithms.AlgorithmResult;
import algorithms.ClockAlgorithm;
import algorithms.LruAlgorithm;
import algorithms.NfuAlgorithm;
import algorithms.OptimalAlgorithm;
import util.InstructionReader;

public class vmsim {

    public static void main(String[] args) {
        // Verify correct usage of command
        if (args.length != 5 || !args[0].equals(("-n")) || !args[2].equals("-a")) {
            System.out.println("Usage: vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            return;
        }

        // Get the number of frames
        int numFrames = getNumFrames(args[1]);
        if (numFrames <= 0) {
            System.out.println("Number of frames must be a positive integer");
            return;
        }

        // Try to read in the file
        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader(args[4]));
        } catch (FileNotFoundException e) {
            System.out.println("Unable to open tracefile '" + args[4] + "'");
            return;
        }

        // Run the specified algorithm
        runAlgorithm(numFrames, args[3], br);
        try {
            br.close();
        } catch (IOException e) {
        }
    }

    /**
     * Gets the number of frames the user wants to run the algorithm with
     * 
     * @param numFrames is the String holding the number of frames
     * @return integer number of frames, or -1 if invalid
     */
    private static int getNumFrames(String numFrames) {
        try {
            return Integer.parseInt(numFrames);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Runs the specified algorithm
     * 
     * @param numFrames is the number of frames to use
     * @param alg       is the name of the algorithm to run
     * @param br        is the BufferedReader for the file to read instructions from
     */
    private static void runAlgorithm(int numFrames, String alg, BufferedReader br) {
        Algorithm algorithm = null;
        if (alg.equals("opt")) {
            // Simulate what the optimal page replacement algorithm
            // would choose if it had perfect knowledge of the future
            algorithm = new OptimalAlgorithm(numFrames);
        } else if (alg.equals("clock")) {
            // Better implementation of second-chance algorithm
            algorithm = new ClockAlgorithm(numFrames);
        } else if (alg.equals("lru")) {
            // Least recently used
            algorithm = new LruAlgorithm(numFrames);
        } else if (alg.equals("nfu")) {
            // Not frequently used
            algorithm = new NfuAlgorithm(numFrames);
        } else {
            System.out.println("Algorithm must be one of <opt|clock|lru|nfu>");
            return;
        }

        // Run the algorithm and display result
        AlgorithmResult result = algorithm.run(new InstructionReader(br));
        System.out.println("\nAlgorithm: " + alg);
        System.out.println("Number of frames:\t" + numFrames);
        System.out.println("Total memory accesses:\t" + result.getMemoryAccesses());
        System.out.println("Total page faults:\t" + result.getPageFaults());
        System.out.println("Total writes to disk:\t" + result.getDiskWrites());
        System.out.println("Total size of page table:\t" + result.tableSize() + " bytes");
    }

}
