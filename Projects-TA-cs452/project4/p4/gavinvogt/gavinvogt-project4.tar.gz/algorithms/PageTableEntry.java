package algorithms;

/**
 * This class represents an entry in the page table
 */
public class PageTableEntry {
    /** Page number in physical memory */
    int pageNumber;
    /** Whether the page is dirty */
    boolean dirty = false;
    /** Whether the page is valid */
    boolean valid = false;
    
    /**
     * Number of bytes used to represent this entry
     * @return number of bytes for this entry
     */
    static int entrySize() {
        // page number: 32 bits
        // dirty: 1 bit
        // valid: 1 bit
        return 4 + 1;
    }
    
}