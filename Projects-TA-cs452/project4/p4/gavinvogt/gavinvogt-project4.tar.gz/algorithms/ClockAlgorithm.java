package algorithms;

import util.Instruction;
import util.InstructionReader;

/**
 * This class represents the clock algorithm for page replacement.
 */
public class ClockAlgorithm implements Algorithm {

    /** Number of frames in the table */
    private final int numFrames;
    /** Table of page table entries */
    private final ClockPageTableEntry table[];
    /** Current pointer for hand on clock */
    private int cur = 0;
    /** Result of running the algorithm */
    private final AlgorithmResult result = new AlgorithmResult();
    
    /**
     * Creates a clock algorithm
     * @param numFrames is the number of frames in the table
     */
    public ClockAlgorithm(int numFrames) {
        // Create the page table
        this.numFrames = numFrames;
        table = new ClockPageTableEntry[numFrames];
        for (int i = 0; i < numFrames; ++i) {
            table[i] = new ClockPageTableEntry();
        }
        
        // Set the page table size (extra word for cur hand)
        result.setSize(4 + ClockPageTableEntry.entrySize() * numFrames);
    }
    
    @Override
    public AlgorithmResult run(InstructionReader reader) {
        for (Instruction instruction : reader) {
            result.increaseCounts(instruction);
            
            // Find the frame holding the desired page
            int pageNum = instruction.pageNumber();
            ClockPageTableEntry entry = this.findPage(pageNum);
            
            if (entry == null) {
                // Failed to find page
                this.handlePageFault(pageNum);
            } else {
                System.out.println("hit");
            }
            
            // Set dirty if written to
            if (instruction.isWrite()) {
                entry = this.findPage(pageNum);
                entry.dirty = true;
            }
        }
        
        return result;
    }
    
    /**
     * Advances the cur pointer of the clock
     */
    private void advanceCur() {
        this.cur = (this.cur + 1) % this.numFrames;
    }
    
    /**
     * Handles a page fault
     * @param pageNum is the page number being accessed
     */
    private void handlePageFault(int pageNum) {
        result.pageFault();
        String actionMessage = null;
        if (table[cur].valid) {
            // Rotate cur until non-referenced page
            while (table[cur].referenced) {
                table[cur].referenced = false;
                this.advanceCur();
            }
        } else {
            // Make page valid
            table[cur].valid = true;
            actionMessage = "page fault - no eviction";
        }
        
        if (actionMessage == null) {
            // Know it was not a no-eviction
            if (table[cur].dirty) {
                result.diskWrite();
                actionMessage = "page fault - evict dirty";
            } else {
                actionMessage = "page fault - evict clean";
            }
        }
        
        table[cur].pageNumber = pageNum;
        table[cur].dirty = false;
        this.advanceCur();
        System.out.println(actionMessage);
    }
    
    /**
     * Finds the page in the page table
     * @param pageNum is the page number to find
     * @return entry for the page if found, or null
     */
    private ClockPageTableEntry findPage(int pageNum) {
        for (ClockPageTableEntry entry : this.table) {
            if (entry.valid && entry.pageNumber == pageNum) {
                return entry;
            }
        }
        
        // No page found
        return null;
    }
    
    private static class ClockPageTableEntry extends PageTableEntry {
        /** Whether the page has been referenced */
        private boolean referenced = false;
        
        static int entrySize() {
            // Same number because referenced only adds one bit
            return PageTableEntry.entrySize();
        }
    }

}
