package algorithms;

import util.Instruction;
import util.InstructionReader;

/**
 * This class represents the LRU algorithm by evicting the page that was least
 * recently used
 */
public class LruAlgorithm implements Algorithm {

    /** Table of page table entries */
    private final LruPageTableEntry table[];
    /** Current instruction number */
    private long instructionCounter = 0;
    /** Result of running the algorithm */
    private final AlgorithmResult result = new AlgorithmResult();

    /**
     * Creates an LRU algorithm
     * @param numFrames is the number of frames in the table
     */
    public LruAlgorithm(int numFrames) {
        // Create the page table
        table = new LruPageTableEntry[numFrames];
        for (int i = 0; i < numFrames; ++i) {
            table[i] = new LruPageTableEntry();
        }

        // Set the page table size (extra long for instruction counter)
        result.setSize(8 + LruPageTableEntry.entrySize() * numFrames);
    }

    @Override
    public AlgorithmResult run(InstructionReader reader) {
        for (Instruction instruction : reader) {
            result.increaseCounts(instruction);

            // Find the frame holding the desired page
            int pageNum = instruction.pageNumber();
            LruPageTableEntry entry = this.findPage(pageNum);

            if (entry == null) {
                // Failed to find page
                this.handlePageFault(pageNum);
            } else {
                System.out.println("hit");
            }

            // Get the page that was used
            entry = this.findPage(pageNum);
            entry.lastUsed = instructionCounter++;

            // Set dirty if written to
            if (instruction.isWrite()) {
                entry.dirty = true;
            }
        }

        return this.result;
    }
    
    /**
     * Handles a page fault
     * @param pageNum is the page number being accessed
     */
    private void handlePageFault(int pageNum) {
        result.pageFault();
        String actionMessage = null;

        // Find the least recently used frame
        LruPageTableEntry oldest = this.table[0];
        for (LruPageTableEntry entry : this.table) {
            if (!entry.valid) {
                // Invalid page, just use this one
                entry.valid = true;
                oldest = entry;
                actionMessage = "page fault - no eviction";
                break;
            } else if (entry.lastUsed < oldest.lastUsed) {
                // Found older entry
                oldest = entry;
            }
        }

        if (actionMessage == null) {
            // Know it was not a no-eviction
            if (oldest.dirty) {
                result.diskWrite();
                actionMessage = "page fault - evict dirty";
            } else {
                actionMessage = "page fault - evict clean";
            }
        }

        oldest.dirty = false;
        oldest.pageNumber = pageNum;
        System.out.println(actionMessage);
    }

    /**
     * Finds the page in the page table
     * 
     * @param pageNum is the page number to find
     * @return entry for the page if found, or null
     */
    private LruPageTableEntry findPage(int pageNum) {
        for (LruPageTableEntry entry : this.table) {
            if (entry.valid && entry.pageNumber == pageNum) {
                return entry;
            }
        }

        // No page found
        return null;
    }

    private static class LruPageTableEntry extends PageTableEntry {
        /** Instruction number last time this page was used */
        private long lastUsed;

        static int entrySize() {
            // Last used: 64 bits
            return PageTableEntry.entrySize() + 8;
        }
    }

}
