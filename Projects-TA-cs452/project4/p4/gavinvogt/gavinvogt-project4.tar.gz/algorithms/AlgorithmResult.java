package algorithms;

import util.Instruction;

/**
 * This class represents the result of the algorithm run
 */
public class AlgorithmResult {

    /** Total count of memory accesses */
    private long memoryAccesses = 0;
    /** Total count of page faults */
    private long pageFaults = 0;
    /** Total count of disk writes */
    private long diskWrites = 0;
    /** Size of the page table */
    private int size;

    /**
     * Gets the number of memory accesses that occurred
     * 
     * @return number of memory accesses
     */
    public long getMemoryAccesses() {
        return this.memoryAccesses;
    }

    /**
     * Gets the number of page faults that occurred
     * 
     * @return number of page faults
     */
    public long getPageFaults() {
        return this.pageFaults;
    }

    /**
     * Gets the number of disk writes that occurred
     * 
     * @return number of disk writes
     */
    public long getDiskWrites() {
        return this.diskWrites;
    }

    /**
     * Gets the number of bytes in the page table
     * @return page table size in bytes
     */
    public int tableSize() {
        return this.size;
    }
    
    /**
     * Adds a page fault to the count
     */
    void pageFault() {
        ++this.pageFaults;
    }

    /**
     * Increases the memory access and disk write counts based on the instruction
     * 
     * @param instruction is the Instruction
     */
    void increaseCounts(Instruction instruction) {
        // Access for read
        if (instruction.isRead()) {
            ++this.memoryAccesses;
        }

        // Access for write
        if (instruction.isWrite()) {
            ++this.memoryAccesses;
        }
    }

    /**
     * Increases the number of disk writes that have occurred
     */
    void diskWrite() {
        ++this.diskWrites;
    }

    /**
     * Sets the page table size
     * @param size is the page table size in bytes
     */
    void setSize(int size) {
        this.size = size;
    }

}