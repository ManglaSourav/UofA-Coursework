package algorithms;

import util.Instruction;
import util.InstructionReader;

/**
 * This class represents the NFU algorithm by evicting the page
 * that is not frequently used
 */
public class NfuAlgorithm implements Algorithm {
    
    /** Table of page table entries */
    private final NfuPageTableEntry table[];
    /** Result of running the algorithm */
    private final AlgorithmResult result = new AlgorithmResult();

    /**
     * Creates an NFU algorithm
     * @param numFrames is the number of frames in the table
     */
    public NfuAlgorithm(int numFrames) {
        // Create the page table
        table = new NfuPageTableEntry[numFrames];
        for (int i = 0; i < numFrames; ++i) {
            table[i] = new NfuPageTableEntry();
        }
        
        // Set the page table size
        result.setSize(NfuPageTableEntry.entrySize() * numFrames);
    }

    @Override
    public AlgorithmResult run(InstructionReader reader) {
        for (Instruction instruction : reader) {
            result.increaseCounts(instruction);
            
            // Find the frame holding the desired page
            int pageNum = instruction.pageNumber();
            NfuPageTableEntry entry = this.findPage(pageNum);
            
            if (entry == null) {
                // Failed to find page
                this.handlePageFault(pageNum);
            } else {
                System.out.println("hit");
            }
            
            // Get the page that was used
            entry = this.findPage(pageNum);
            ++entry.refCount;
            
            // Set dirty if written to
            if (instruction.isWrite()) {
                entry.dirty = true;
            }
        }
        
        return this.result;
    }
    
    
    /**
     * Handles a page fault
     * @param pageNum is the page number being accessed
     */
    private void handlePageFault(int pageNum) {
        result.pageFault();
        String actionMessage = null;
        
        // Find the least recently used frame
        NfuPageTableEntry lowest = this.table[0];
        for (NfuPageTableEntry entry : this.table) {
            if (!entry.valid) {
                // Invalid page, just use this one
                entry.valid = true;
                lowest = entry;
                actionMessage = "page fault - no eviction";
                break;
            } else if (entry.refCount < lowest.refCount) {
                // Found entry with lower reference count
                lowest = entry;
            }
        }
        
        if (actionMessage == null) {
            // Know it was not a no-eviction
            if (lowest.dirty) {
                result.diskWrite();
                actionMessage = "page fault - evict dirty";
            } else {
                actionMessage = "page fault - evict clean";
            }
        }
        
        lowest.pageNumber = pageNum;
        lowest.dirty = false;
        lowest.refCount = 0;            // reset reference count
        System.out.println(actionMessage);
    }
    
    /**
     * Finds the page in the page table
     * @param pageNum is the page number to find
     * @return entry for the page if found, or null
     */
    private NfuPageTableEntry findPage(int pageNum) {
        for (NfuPageTableEntry entry : this.table) {
            if (entry.valid && entry.pageNumber == pageNum) {
                return entry;
            }
        }
        
        // No page found
        return null;
    }
    
    private static class NfuPageTableEntry extends PageTableEntry {
        /** Number of times this page has been referenced */
        private long refCount;
        
        static int entrySize() {
            // Reference count: 64 bits
            return PageTableEntry.entrySize() + 8;
        }
    }
}
