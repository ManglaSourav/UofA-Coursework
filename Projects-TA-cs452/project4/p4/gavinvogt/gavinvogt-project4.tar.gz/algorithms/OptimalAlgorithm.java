package algorithms;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import util.Instruction;
import util.InstructionReader;

/**
 * This class represents the optimal algorithm for page replacement.
 * It looks ahead in the future to make the best possible choice.
 */
public class OptimalAlgorithm implements Algorithm {

    /** Table of page table entries */
    private final PageTableEntry table[];
    /** Maps page number -> queue of instruction numbers that reference that page */
    private final Map<Integer, Queue<Long>> future = new HashMap<>();
    /** Queue of instructions to run */
    private final Queue<Instruction> instructions = new LinkedList<Instruction>();
    /** Result of running the algorithm */
    private final AlgorithmResult result = new AlgorithmResult();

    /**
     * Creates the optimal algorithm
     * @param numFrames is the number of frames in the table
     */
    public OptimalAlgorithm(int numFrames) {
        // Create the page table
        table = new PageTableEntry[numFrames];
        for (int i = 0; i < numFrames; ++i) {
            table[i] = new PageTableEntry();
        }
        
        // Set the page table size
        result.setSize(PageTableEntry.entrySize() * numFrames);
    }

    @Override
    public AlgorithmResult run(InstructionReader reader) {
        // Load all the instructions
        long i = 0;
        for (Instruction instruction : reader) {
            instructions.add(instruction);
            int pageNum = instruction.pageNumber();
            if (!future.containsKey(pageNum)) {
                future.put(pageNum, new LinkedList<Long>());
            }
            future.get(pageNum).add(i++);
        }

        for (Instruction instruction : instructions) {
            result.increaseCounts(instruction);

            // Find the frame holding the desired page
            int pageNum = instruction.pageNumber();
            PageTableEntry entry = this.findPage(pageNum);

            if (entry == null) {
                // Failed to find page
                this.handlePageFault(pageNum);
            } else {
                System.out.println("hit");
            }

            // Remove this instruction number from the correct queue
            future.get(pageNum).remove();

            // Set dirty if written to
            if (instruction.isWrite()) {
                entry = this.findPage(pageNum);
                entry.dirty = true;
            }

        }

        return this.result;
    }

    /**
     * Handles a page fault
     * @param pageNum is the page number being accessed
     */
    private void handlePageFault(int pageNum) {
        result.pageFault();
        String actionMessage = null;

        PageTableEntry furthest = table[0];
        long furthestUse = 0;
        for (PageTableEntry entry : table) {
            if (!entry.valid) {
                // No eviction needed
                entry.valid = true;
                furthest = entry;
                actionMessage = "page fault - no eviction";
                break;
            } else {
                Queue<Long> q = future.get(entry.pageNumber);
                if (q.isEmpty()) {
                    // Frame never used again, so use this one
                    furthest = entry;
                    break;
                } else {
                    long nextUse = q.peek();
                    if (nextUse > furthestUse) {
                        // Found the furthest use
                        furthestUse = nextUse;
                        furthest = entry;
                    }
                }
            }
        }

        if (actionMessage == null) {
            // Know it was not a no-eviction
            if (furthest.dirty) {
                result.diskWrite();
                actionMessage = "page fault - evict dirty";
            } else {
                actionMessage = "page fault - evict clean";
            }
        }
        furthest.dirty = false;
        furthest.pageNumber = pageNum;
        System.out.println(actionMessage);
    }

    /**
     * Finds the page in the page table
     * @param pageNum is the page number to find
     * @return entry for the page if found, or null
     */
    private PageTableEntry findPage(int pageNum) {
        for (PageTableEntry entry : this.table) {
            if (entry.valid && entry.pageNumber == pageNum) {
                return entry;
            }
        }

        // No page found
        return null;
    }

}
