package algorithms;

import util.InstructionReader;

/**
 * This class represents an algorithm to run
 */
public interface Algorithm {

    /**
     * Runs the algorithm
     * 
     * @param reader InstructionReader to read instructions from
     * @return AlgorithmResult representing the result of the algorithm
     */
    public AlgorithmResult run(InstructionReader reader);

}
