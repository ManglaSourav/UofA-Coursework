/*
 *  Author:     Minghui Ke
 *  Assignment: CSC452 project 4
 *
 *  Purpose:    Get the user input to run <opt|clock|lru|nfu> page algorithms with given
 *              number of frame and the trace file.
 */
public class vmsim {

    /*
     * Use the arguments to run the page algorithms.
     */
    public static void main(String[] args) {

        if (args.length<5 || args.length>7) {
            System.out.println("Incorrect number of arguments, need 6.");
            System.exit(0);
        }

        if (!args[0].equals("-n")) {
            System.out.println("Incorrect first argument, need -<n>.");
            System.exit(0);
        }

        int frame = 0;
        try {
            frame = Integer.parseInt(args[1]);
        } catch(Exception e) {
            System.out.println("Incorrect second argument, need an integer.");
            System.exit(0);
        }

        if (!args[2].equals("-a")) {
            System.out.println("Incorrect third argument, need -<a>.");
            System.exit(0);
        }

        String alg = args[3];
        if(!alg.equals("opt") && !alg.equals("clock") && !alg.equals("lru") && !alg.equals("nfu"))
        {
            System.out.println("Incorrect fourth argument, need -<opt|clock|lru|nfu>.");
            System.exit(0);
        }

        String filename = args[4];
        Algorithms algo = new Algorithms(frame, filename);

        if (alg.equals("opt")) algo.opt();
        else if (alg.equals("clock")) algo.clock();
        else if (alg.equals("lru")) algo.lru();
        else if (alg.equals("nfu")) algo.nfu();

    }
}
