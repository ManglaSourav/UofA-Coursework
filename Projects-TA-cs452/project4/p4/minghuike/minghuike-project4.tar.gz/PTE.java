/*
 *  Author:     Minghui Ke
 *  Assignment: CSC452 project 4
 *
 *  Purpose:    Stand for Page Table Entry.
 */
public class PTE {

    private boolean dirty;
    private boolean referenced;
    private boolean valid;
    private int frame;
    private int page;
    private int count;

    public PTE() {
        this.dirty = false;
        this.referenced = false;
        this.valid = false;
        this.frame = -1;
        this.page = -1;
        this.count = -1;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public boolean isReferenced() {
        return referenced;
    }

    public void setReferenced(boolean referenced) {
        this.referenced = referenced;
    }

    public int getFrame() {
        return frame;
    }

    public void setFrame(int frame) {
        this.frame = frame;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public boolean isDirty() {
        return dirty;
    }

    public void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }
}
