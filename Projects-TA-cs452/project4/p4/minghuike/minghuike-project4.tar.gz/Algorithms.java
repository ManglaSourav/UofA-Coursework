/*
 *  Author:     Minghui Ke
 *  Assignment: CSC452 project 4
 *
 *  Purpose:    run the algorithm with initial frame and file name, output the statistic
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Algorithms {

    private int frame;
    private String filename;

    private int access = 0;
    private int fault = 0;
    private int write = 0;
    private PTE[] pageTable;
    private PTE[] memory;
    private int size = 0;
    private int toatlPage = 0;

    // 8K page size
    private static final int PAGESIZE = (int) Math.pow(2, 13);

    public Algorithms(int frame, String filename) {
        this.frame = frame;
        this.filename = filename;
        pageTable = new PTE[(int) Math.pow(2, 19)];
        memory = new PTE[frame];
    }

    /*
     * Optimal algorithm
     */
    public void opt() {
        Scanner sc = null;
        // get the optimal
        try {
            sc = new Scanner(new File(filename));
        } catch (FileNotFoundException e) {
            System.out.println("File Error!");
        }

        int time = 0;
        HashMap<Integer, Queue<Integer>> opt = new HashMap<>();

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] ins = line.trim().split(("\\s+"));
            if (!ins[0].equals("I") && !ins[0].equals("L") && !ins[0].equals("S") && !ins[0].equals("M")) continue;

            long address = Long.decode("0x"+ins[1].substring(0, 8));
            int page = (int) (address/PAGESIZE);

            if (!opt.containsKey(page)) opt.put(page, new LinkedList<>());
            opt.get(page).offer(time++);
        }

        // begin the algorithm
        try {
            sc = new Scanner(new File(filename));
        } catch (FileNotFoundException e) {
            System.out.println("File Error!");
        }

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] ins = line.trim().split(("\\s+"));
            if (!ins[0].equals("I") && !ins[0].equals("L") && !ins[0].equals("S") && !ins[0].equals("M")) continue;

            char type = ins[0].charAt(0);
            long address = Long.decode("0x"+ins[1].substring(0, 8));
            int page = (int) (address/PAGESIZE);
            access++;

            if (pageTable[page] == null) {
                PTE temp = new PTE();
                temp.setPage(page);
                pageTable[page] = temp;
                toatlPage++;
            }
            PTE entry = pageTable[page];
            if (type == 'S' || type == 'M') entry.setDirty(true);

            if(entry.isValid()) {
                System.out.println("hit");

            } else {
                fault++;
                entry.setValid(true);
                if (size < frame) { // memory is not full
                    entry.setFrame(size);
                    memory[size++] = entry;
                    System.out.println("page fault - no eviction");

                } else { // need to swap
                    int remove = 0;
                    for (int i = 0; i < frame; i++) {
                        if (opt.get(memory[i].getPage()).peek() == null) { // not use anymore
                            remove = i;
                            break;
                        }
                        // check the next time use
                        if (opt.get(memory[remove].getPage()).peek() < opt.get(memory[i].getPage()).peek()) {
                            remove = i;
                        }
                    }
                    if (memory[remove].isDirty()) {
                        write++;
                        System.out.println("page fault - evict dirty");
                    } else System.out.println("page fault - evict clean");

                    PTE toRemove = memory[remove];
                    toRemove.setDirty(false);
                    toRemove.setReferenced(false);
                    toRemove.setValid(false);
                    toRemove.setFrame(-1);
                    entry.setFrame(remove);
                    memory[remove] = entry;
                }
            }
            opt.get(page).poll();
        }
        output("opt");
    }

    /*
     * Clock algorithm
     */
    public void clock() {
        int clock = 0;
        Scanner sc = null;
        try {
            sc = new Scanner(new File(filename));
        } catch (FileNotFoundException e) {
            System.out.println("File Error!");
        }

        // begin the algorithm
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] ins = line.trim().split(("\\s+"));
            if (!ins[0].equals("I") && !ins[0].equals("L") && !ins[0].equals("S") && !ins[0].equals("M")) continue;

            char type = ins[0].charAt(0);
            long address = Long.decode("0x"+ins[1].substring(0, 8));
            int page = (int) (address/PAGESIZE);
            access++;

            if (pageTable[page] == null) {
                PTE temp = new PTE();
                temp.setPage(page);
                pageTable[page] = temp;
                toatlPage++;
            }
            PTE entry = pageTable[page];
            if (type == 'S' || type == 'M') entry.setDirty(true);
            entry.setReferenced(true); // set R bit to 1
            if(entry.isValid()) {
                System.out.println("hit");

            } else {
                fault++;
                entry.setValid(true);
                if (size < frame) { // memory is not full
                    entry.setFrame(size);
                    memory[size++] = entry;
                    System.out.println("page fault - no eviction");

                } else { // need to swap
                    int remove = 0;
                    while (true) {
                        if (!memory[clock].isReferenced()) { // if R bit is 0
                            remove = clock;
                            break;
                        } else memory[clock].setReferenced(false); // else set R bit to 0
                        clock = (clock+1) % frame;
                    }

                    if (memory[remove].isDirty()) {
                        write++;
                        System.out.println("page fault - evict dirty");
                    } else System.out.println("page fault - evict clean");

                    PTE toRemove = memory[remove];
                    toRemove.setDirty(false);
                    toRemove.setValid(false);
                    toRemove.setFrame(-1);
                    entry.setFrame(remove);
                    memory[remove] = entry;
                    clock = (clock+1) % frame;
                }
            }
        }
        output("clock");
    }

    /*
     * Least recently used algorithm
     */
    public void lru() {
        LinkedList<PTE> pageList = new LinkedList<>();
        Scanner sc = null;
        try {
            sc = new Scanner(new File(filename));
        } catch (FileNotFoundException e) {
            System.out.println("File Error!");
        }

        // begin the algorithm
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] ins = line.trim().split(("\\s+"));
            if (!ins[0].equals("I") && !ins[0].equals("L") && !ins[0].equals("S") && !ins[0].equals("M")) continue;

            char type = ins[0].charAt(0);
            long address = Long.decode("0x"+ins[1].substring(0, 8));
            int page = (int) (address/PAGESIZE);
            access++;

            if (pageTable[page] == null) {
                PTE temp = new PTE();
                temp.setPage(page);
                pageTable[page] = temp;
                toatlPage++;
            }
            PTE entry = pageTable[page];
            if (type == 'S' || type == 'M') entry.setDirty(true);

            if(entry.isValid()) {
                pageList.remove(entry); // remove the entry
                pageList.offerFirst(entry); // add to the front of linked list
                System.out.println("hit");

            } else {
                fault++;
                entry.setValid(true);
                pageList.offerFirst(entry);  // add to the front of linked list
                if (size < frame) { // memory is not full
                    entry.setFrame(size);
                    memory[size++] = entry;
                    System.out.println("page fault - no eviction");

                } else { // need to swap
                    int remove = pageList.pollLast().getFrame(); // remove the least recently used

                    if (memory[remove].isDirty()) {
                        write++;
                        System.out.println("page fault - evict dirty");
                    } else System.out.println("page fault - evict clean");

                    PTE toRemove = memory[remove];
                    toRemove.setDirty(false);
                    toRemove.setValid(false);
                    toRemove.setFrame(-1);
                    entry.setFrame(remove);
                    memory[remove] = entry;
                }
            }
        }
        output("lru");
    }

    /*
     * Not frequency used algorithm, the time clock is each memory access.
     */
    public void nfu() {

        Scanner sc = null;
        try {
            sc = new Scanner(new File(filename));
        } catch (FileNotFoundException e) {
            System.out.println("File Error!");
        }

        // begin the algorithm
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] ins = line.trim().split(("\\s+"));
            if (!ins[0].equals("I") && !ins[0].equals("L") && !ins[0].equals("S") && !ins[0].equals("M")) continue;

            char type = ins[0].charAt(0);
            long address = Long.decode("0x"+ins[1].substring(0, 8));
            int page = (int) (address/PAGESIZE);
            access++;

            if (pageTable[page] == null) {
                PTE temp = new PTE();
                temp.setPage(page);
                pageTable[page] = temp;
                toatlPage++;
            }
            PTE entry = pageTable[page];
            if (type == 'S' || type == 'M') entry.setDirty(true);

            if(entry.isValid()) {
                System.out.println("hit");
                entry.setCount(entry.getCount()+1); // update count

            } else {
                fault++;
                entry.setValid(true);
                entry.setCount(1); // initial count
                if (size < frame) { // memory is not full
                    entry.setFrame(size);
                    memory[size++] = entry;
                    System.out.println("page fault - no eviction");

                } else { // need to swap
                    int remove = 0;
                    int min = Integer.MAX_VALUE;
                    for (PTE temp : memory) { // find the least count
                        if (temp.getCount() < min) {
                            min = temp.getCount();
                            remove = temp.getFrame();
                        }
                    }

                    if (memory[remove].isDirty()) {
                        write++;
                        System.out.println("page fault - evict dirty");
                    } else System.out.println("page fault - evict clean");

                    PTE toRemove = memory[remove];
                    toRemove.setDirty(false);
                    toRemove.setValid(false);
                    toRemove.setFrame(-1);
                    toRemove.setCount(-1);
                    entry.setFrame(remove);
                    memory[remove] = entry;
                }
            }
        }
        output("lru");
    }

    // print out the statistic of the algorithm
    private void output(String algorithm) {
        System.out.println("============================================");
        System.out.println("Algorithm: "+ algorithm);
        System.out.println("Number of frames:\t\t" + frame);
        System.out.println("Total memory accesses:\t\t" + access);
        System.out.println("Total page faults:\t\t" + fault);
        System.out.println("Total writes to disk:\t\t" + write);
        System.out.println("Total size of page table:\t" + toatlPage * PAGESIZE  + " bytes");
    }

}
