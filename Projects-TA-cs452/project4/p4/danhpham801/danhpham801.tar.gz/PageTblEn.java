public class PageTblEn implements Comparable {

    protected int baseAddr;
    protected Long lastA;
    private boolean n;
    protected Integer refNum;
    protected boolean ref;
    protected boolean valid;
    protected boolean dirty;


    public PageTblEn(int baseAddr){
        this.baseAddr = baseAddr;
        this.ref = this.valid = this.dirty = false;
        this.lastA = 0L;
        this.refNum = 0;
    }

    public void setA(){
        this.n = true;
    }

    @Override
    public int compareTo(Object o) {
        PageTblEn o1 = (PageTblEn) o;
        if(n){
            return this.refNum.compareTo(o1.refNum);
        }
        return this.lastA.compareTo(o1.lastA);
    }
}
