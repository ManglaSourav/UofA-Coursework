import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.PriorityQueue;

public class NFU extends Algo {
    PriorityQueue<PageTblEn> pq;
    public NFU(){
        super();
        this.name = "NFU";
        pq = new PriorityQueue<>(framSize);
    }

    @Override
    public void sim(String file) {
        PageTblEn temp;
        PageTblEn save;
        long hex;
        String line;
        char m;
        int i;

        try{
            BufferedReader lines = new BufferedReader(new FileReader(file));
            while (lines.ready()) {
                line = lines.readLine();
                if(line.charAt(0)!='=' && line.charAt(0)!='-' && line.charAt(0)!='t') {
                    if (line.charAt(0) != ' ') {
                        m = line.charAt(0);
                    } else {
                        m = line.charAt(1);
                    }
                    String[] tstr = line.substring(3).split(",");
                    String addr = "0x" + tstr[0];
                    hex = Long.decode(addr);
                    i = (int) (hex >> 13);

                    if(!pageTable.containsKey(i)){
                        temp = new PageTblEn(i);
                        temp.setA();
                        pageTable.put(i, temp);
                    }
                    else{
                        temp = pageTable.get(i);
                    }

                    if (m =='S' || m == 'M'){
                        temp.dirty = true;
                    }

                    if(RAM.containsKey(i)){
                        Update(temp);
                    }

                    else{
                        pgFault++;
                        if(RAMisFull()){
                            Update(temp);
                            RAM.put(i, temp);
                        }
                        else {
                            save = pq.poll();

                            if(save.dirty){
                                dWrite ++;
                                save.dirty = false;
                            }

                            save.valid = false;
                            RAM.remove(save.baseAddr, save);

                            Update(temp);
                            temp.valid = true;
                            RAM.put(temp.baseAddr, temp);
                        }
                    }
                    memAccess++;
                }

            }
            lines.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void Update(PageTblEn temp) {
        if(pq.contains(temp)){
            pq.remove(temp);
        }
        temp.refNum++;
        pq.add(temp);
    }

}
