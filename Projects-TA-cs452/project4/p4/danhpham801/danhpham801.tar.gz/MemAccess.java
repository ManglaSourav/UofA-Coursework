public class MemAccess {

    private int addr;
    private char mode;
    private int size;

    public MemAccess(int addr, char mode, int size){
        this.addr = addr;
        this.mode = mode;
        this.size = size;
    }

    public int getAddr(){
        return addr;
    }

    public char getMode(){
        return mode;
    }

    public int getSize(){return size;}
}
