import java.util.Locale;

public class vmsim {

    private static final int y = 32 - 13;
    private static int numFrames;
    private static Algo alg;
    private static String file;
    private static String name;
    private static final int numPgs = (int) Math.pow(2,y);

    private static void parseArgs(String[] args){
        try{
            for(int i = 0; i<= args.length -1; i++){
                switch (args[i]){
                    case "-n":
                        numFrames = Integer.parseInt(args[++i]);
                        break;
                    case "-a":
                        name = args[i+1].toUpperCase();
                    i++;
                    break;
                    default:
                        file = args[i];
                        break;
                }
            }
        }catch (NumberFormatException e){
            System.out.println("Error");
        }
    }

    private static void print(){
        System.out.printf("Algorithm: %s\nNumber of frames: %d\nTotal memory accesses: %d\n" +
                        "Total page fault: %d\nTotal write to disk: %d\nTotal size of page table: %d bytes\n"
                            , name, numFrames, alg.getMemAccess(), alg.pgFault, alg.dWrite,numPgs*4);
    }

    public static void main(String[] args){
        file = null;
        numFrames = 0;

        parseArgs(args);

        Algo.setFramSize(numFrames);
        Algo.setPageTblSize(numPgs);

        switch (name){
            case "OPT":
                alg = new OPT();
                break;
            case "LRU":
                alg = new LRU();
                break;
            case "NFU":
                alg = new NFU();
                break;
            case "CLOCK":
                alg = new Clock();
        }


        alg.sim(file);

        print();

    }
}
