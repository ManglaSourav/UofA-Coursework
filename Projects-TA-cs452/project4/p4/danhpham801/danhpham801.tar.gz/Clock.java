import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class Clock extends Algo{

    public Clock(){
        super();
        name = "CLOCK";
    }

    @Override
    public void sim(String file) {
        PageTblEn temp;
        PageTblEn save = null;
        long hex;
        String line;
        char m;
        int i;
        int head = 0;
        LinkedList<PageTblEn> clock = new LinkedList<>();

        try{
            BufferedReader lines = new BufferedReader(new FileReader(file));
            while (lines.ready()){
                line = lines.readLine();
                if(line.charAt(0)!='=' && line.charAt(0)!='-' && line.charAt(0)!='t') {
                    if (line.charAt(0) != ' ') {
                        m = line.charAt(0);
                    } else {
                        m = line.charAt(1);
                    }

                    String[] tstr = line.substring(3).split(",");
                    String addr = "0x" + tstr[0];
                    hex = Long.decode(addr);
                    i = (int) (hex >> 13);
                    if(!pageTable.containsKey(i)){
                        temp = new PageTblEn(i);
                        pageTable.put(i, temp);
                    }
                    else{
                        temp = pageTable.get(i);
                    }

                    if (m =='S' || m == 'M'){
                        temp.dirty = true;
                    }
                    if(clock.contains(temp)){
                        temp.ref = true;
                    }
                    else{
                        pgFault++;
                        if(clock.size()< framSize){
                            clock.add(temp);
                            temp.valid = true;
                        }
                        else {
                            int i1, j;
                            for(i1 = head, j = 0; j< clock.size()+1; j++, i1=(i1+1)%framSize){
                                PageTblEn pg = clock.get(i1);
                                if(pg.ref){
                                    pg.ref = false;
                                }
                                else{
                                    save = pg;
                                    break;
                                }
                            }
                            head = (i1+1)%framSize;

                            if (save.dirty){
                                save.dirty = false;
                                dWrite++;
                            }
                            save.valid = false;
                            clock.set(i1, temp);
                            temp.valid = true;
                        }
                    }
                    memAccess ++;
                }

            }
            lines.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
