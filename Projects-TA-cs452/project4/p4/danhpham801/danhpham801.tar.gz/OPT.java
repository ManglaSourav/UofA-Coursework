import java.io.BufferedReader;
import java.util.Iterator;
import java.util.Map.Entry;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class OPT extends Algo{

    private HashMap<Integer, LinkedList<Integer>> future;
    private PriorityQueue<PageTblEn> pq;

    public OPT(){
        super();
        this.name = "OPT";
        future = new HashMap<>();
        pq = new PriorityQueue<>(framSize);
    }

    @Override
    public void sim(String file) {
        PageTblEn temp;
        PageTblEn save;
        MemAccess instr;
        ArrayList<MemAccess> ref = new ArrayList<MemAccess>();
        try {
            BufferedReader buff = new BufferedReader(new FileReader(file));
            parse(buff, ref);
            buff.close();
            int i;
            char m;

            while(memAccess< ref.size()) {

                instr = ref.get(memAccess);
                i = instr.getAddr();
                m = instr.getMode();

                temp = pageTable.get(i);

                if (m == 'S' || m == 'M') {
                    temp.dirty = true;
                }
                future.get(i).getFirst();

                if (RAM.containsKey(i)) {
                    Update(temp);
                } else {
                    pgFault++;

                    if (RAMisFull()) {
                        Update(temp);
                        RAM.put(i, temp);
                    } else {
                        int addr = locateAddr();

                        save = RAM.get(addr);

                        if (save.dirty) {
                            dWrite++;
                            save.dirty = false;
                        }

                        save.valid = false;
                        RAM.remove(save.baseAddr, save);

                        Update(temp);
                        temp.valid = true;
                        RAM.put(temp.baseAddr, temp);
                    }
                }
                memAccess ++;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void Update(PageTblEn temp) {
        temp.lastA = System.nanoTime();
    }

    private int locateAddr() {
        Iterator<Entry<Integer, PageTblEn>> iterator;
        Map.Entry<Integer, PageTblEn> en;
        PageTblEn temp;

        iterator = RAM.entrySet().iterator();
        en = iterator.next();
        temp = en.getValue();

        int max = 0, mAddr = 0, emptFuture = 0;

        while (iterator.hasNext()){

            if(future.get(temp.baseAddr).isEmpty()){
                pq.add(temp);
                emptFuture++;
            }
            else{
                if (future.get(temp.baseAddr).getFirst() > max){
                    max = future.get(temp.baseAddr).getFirst();
                    mAddr = temp.baseAddr;
                }
            }
            en = iterator.next();
            temp = en.getValue();
        }
        if(!iterator.hasNext()){
            temp = en.getValue();

            if(future.get(temp.baseAddr).isEmpty()){
                pq.add(temp);
                emptFuture++;
            }
            else if(future.get(temp.baseAddr).getFirst() > max){
                max = future.get(temp.baseAddr).getFirst();
                mAddr = temp.baseAddr;
            }
        }
        if(emptFuture > 0){
            temp = pq.poll();
            mAddr = temp.baseAddr;
        }

        while(!pq.isEmpty()) {
            pq.poll();
        }
        return mAddr;
    }


    private void parse(BufferedReader buf, ArrayList<MemAccess> ref){
        String line;
        long hex;
        int i;
        int lineN;
        char mode;
        PageTblEn temp;

        try {
            lineN = 0;
            while (buf.ready()){
                line = buf.readLine();
                if(line.charAt(0)!='=' && line.charAt(0)!='-' && line.charAt(0)!='t'){

                    if(line.charAt(0) !=' '){
                        mode = line.charAt(0);
                    }
                    else{
                        mode = line.charAt(1);
                    }

                    String [] tstr = line.substring(3).split(",");
                    String size = tstr[1];
                    String addr = "0x"+tstr[0];
                    hex = Long.decode(addr);

                    i = (int) (hex >> 13);

                    ref.add(new MemAccess(i, mode, Integer.parseInt(size)));

                    if(!pageTable.containsKey(i)){
                        temp = new PageTblEn(i);
                        pageTable.put(i,temp);
                    }

                    if(!future.containsKey(i)){
                        future.put(i, new LinkedList<>());
                    }
                    future.get(i).add(lineN);

                    lineN++;
                }

            }
            buf.close();
        }catch (IOException e){

        }
    }
}
