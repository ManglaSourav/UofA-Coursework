import java.util.HashMap;
import java.util.LinkedList;

public abstract class Algo {

    protected String name;
    protected static int framSize;
    protected static int pageTblSize;
    protected int memAccess, pgFault, dWrite;
    protected HashMap<Integer, PageTblEn> pageTable;
    protected HashMap<Integer, PageTblEn> RAM;


    protected Algo(){
        memAccess = 0;
        pageTable = new HashMap<>(pageTblSize);
        RAM = new HashMap<>(framSize);
    }

    public abstract void sim(String file);

    public static void setFramSize(int size){
        framSize = size;
    }

    public static void setPageTblSize(int size){
        pageTblSize = size;
    }

    protected boolean RAMisFull(){
        return RAM.size() < framSize;
    }

    public int getMemAccess(){
        return memAccess;
    }
}
