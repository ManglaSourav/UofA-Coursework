import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.SortedMap;
import java.util.TreeMap;

public class VirtualMemSim {
	
	public static class PTE {
		public int frame = 0;
		public boolean dirty = false;
		public int referenced = 0;
		public boolean referred = false;
		public boolean valid = false;
		public long timeOfAccess = 0;
	}

	public static void main(String[] args) {
		
		// usage: vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>
		
		if (args.length != 5) {
			System.err.println("Wrong usage: expected 5 command line arguments.");
			return;	
		}
		
		int nIndex, aIndex;
		
		if (args[0].equals("-n") && args[2].equals("-a")) {
			
			nIndex = 1;
			aIndex = 3;
			
		} else if (args[0].equals("-a") && args[2].equals("-n")) {
			
			nIndex = 3;
			aIndex = 1;
			
		} else {
			
			System.err.println("Wrong usage: argument #s 1 and/or 3 are faulty.");
			return;
		}
		
		int numFrames;
		
		try {
			
			numFrames = Integer.parseInt(args[nIndex]);
		
		} catch (NumberFormatException e) {
			
			System.err.println("Wrong usage: argument #" + (nIndex + 1) + " is not an integer.");
			return;
		}
		
		Scanner traceFile;
		
		try {
			
			traceFile = new Scanner(new File(args[4]));
			
		} catch (FileNotFoundException e) {
			
			System.err.println("Error: file specified by argument #5 was not found.");
			return;
		}
		
		int[] stats = new int[4];		// [numAccesses, numFaults, numWrites]
		
		switch (args[aIndex]) {
		
			case "opt":
				opt(numFrames, stats, traceFile, args[4]);
				break;
				
			case "clock":
				clock(numFrames, stats, traceFile);
				break;
				
			case "lru":
				lru(numFrames, stats, traceFile);
				break;
				
			case "nfu":
				nfu(numFrames, stats, traceFile);
				break;
				
			default:
				System.err.println("Wrong usage: argument #" + (aIndex + 1) + " is not a valid algorithm.");
				return;
		}
		
		traceFile.close();
		
		printStats(args[aIndex], numFrames, stats[0], stats[1], stats[2], stats[3]);
	}
	
	public static void opt(int numFrames, int[] stats, Scanner traceFile, String fileName) {

		SortedMap<Long, Integer> map = new TreeMap<>();
		
		long revTime = Long.MAX_VALUE;		// smaller value => further into the future
		
		while (traceFile.hasNext()) {
			
			revTime--;
			
			String[] line = traceFile.nextLine().trim().split("\\s+");
			
			if (line.length != 2) {	
				continue;
			}
			
			String event = line[0];
			
			String[] second = line[1].split(",");
			
			if (second.length != 2) {
				continue;
			}
			
			long address;
			
			try {
				
				address = Long.parseLong(second[0], 16);
			
			} catch (NumberFormatException e) {
				continue;
			}
			
			switch (event) {
			
				case "I":
				case "L":
				case "S":
				case "M":
					break;
					
				default:
					continue;
			}
			
			int pageNum = (int) (address / Math.pow(2, 13));												// pageSize = 8KB (2^13)

			if (!map.containsValue(pageNum)) {
				map.put(revTime, pageNum);
			}
		}
		
		traceFile.close();
		
		try {
			
			traceFile = new Scanner(new File(fileName));
			
		} catch (FileNotFoundException e) {
			
			System.err.println("Error: file could not be reopened.");
			return;
		}
		
		// pageSize = 8KB (2^13) => numPages = 2^19
		// bits for frames = log_2(frameNum)
		// 1 bit each for dirty and valid
		stats[3] = (int) ((2 + Math.ceil(Math.log(numFrames) / Math.log(2))) * Math.pow(2, 19 - 3));		// -3: bits -> bytes
		
		int frameIndex = 0;
		
		PTE[] pageTable = new PTE[(int) Math.pow(2, 19)];
		
		while (traceFile.hasNext()) {
			
			String[] line = traceFile.nextLine().trim().split("\\s+");
			
			if (line.length != 2) {
				continue;
			}
			
			String event = line[0];
			
			String[] second = line[1].split(",");
			
			if (second.length != 2) {
				continue;
			}
			
			long address;
			
			try {
				
				address = Long.parseLong(second[0], 16);
			
			} catch (NumberFormatException e) {
				continue;
			}
			
			switch (event) {
			
				case "I":
					stats[0]++;
					break;
			
				case "L":
					stats[0]++;
					break;
			
				case "S":
					stats[0]++;
					break;
			
				case "M":
					stats[0] += 2;
					break;
					
				default:
					continue;
			}
			
			int pageNum = (int) (address / Math.pow(2, 13));												// pageSize = 8KB (2^13)
			
			PTE entry = pageTable[pageNum];
			
			if ((entry != null) && entry.valid) {															// valid
				
				System.out.println("Hit @ " + second[0]);
				
				if (event.equals("S") || event.equals("M")) {
					entry.dirty = true;
				}
				
			} else {
				
				// invalid => pageFault
				stats[1]++;
				
				entry = pageTable[pageNum] = new PTE();
				
				if (frameIndex < numFrames) {																// empty frames exist

					System.out.println("Page fault - no eviction @ " + second[0]);
					
					entry.frame = frameIndex++;
					
					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}
					
					entry.valid = true;
					
				} else {																					// all frames are full, must evict
				
					// find the furthest valid page
					PTE entryToEvict = null;
					
					for (long rt : map.keySet()) {
						
						PTE e = pageTable[map.get(rt)];
						
						if ((e != null) && e.valid) {
							
							entryToEvict = e;
							break;
						}
					}
					
					// evict the furthest page
					if (entryToEvict.dirty) {																// write to disk if dirty
						
						System.out.println("Page fault - evict dirty @ " + second[0]);
						stats[2]++;
						
					} else {

						System.out.println("Page fault - evict clean @ " + second[0]);
					}
					
					entryToEvict.valid = false;
					
					// load the new page into frame
					entry.frame = entryToEvict.frame;

					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}
					
					entry.valid = true;
				}
			}
		}
	}
	
	public static void clock(int numFrames, int[] stats, Scanner traceFile) {
		
		// pageSize = 8KB (2^13) => numPages = 2^19
		// bits for frames = log_2(frameNum)
		// 1 bit each for dirty and valid
		// 1 bit to keep track of second-chance
		stats[3] = (int) ((3 + Math.ceil(Math.log(numFrames) / Math.log(2))) * Math.pow(2, 19 - 3));		// -3: bits -> bytes
		
		int frameIndex = 0;
		
		PTE[] pageTable = new PTE[(int) Math.pow(2, 19)];
		
		Queue<PTE> queue = new LinkedList<>();
		
		while (traceFile.hasNext()) {
			
			String[] line = traceFile.nextLine().trim().split("\\s+");
			
			if (line.length != 2) {	
				continue;
			}
			
			String event = line[0];
			
			String[] second = line[1].split(",");
			
			if (second.length != 2) {
				continue;
			}
			
			long address;
			
			try {
				
				address = Long.parseLong(second[0], 16);
			
			} catch (NumberFormatException e) {
				continue;
			}
			
			switch (event) {
			
				case "I":
					stats[0]++;
					break;
			
				case "L":
					stats[0]++;
					break;
			
				case "S":
					stats[0]++;
					break;
			
				case "M":
					stats[0] += 2;
					break;
					
				default:
					continue;
			}
			
			int pageNum = (int) (address / Math.pow(2, 13));							// pageSize = 8KB (2^13)
			
			PTE entry = pageTable[pageNum];
			
			if ((entry != null) && entry.valid) {										// valid
				
				System.out.println("Hit @ " + second[0]);
				
				if (event.equals("S") || event.equals("M")) {
					entry.dirty = true;
				}
				
				entry.referred = true;
				
			} else {
				
				// invalid => pageFault
				stats[1]++;
				
				entry = pageTable[pageNum] = new PTE();
				
				if (frameIndex < numFrames) {											// empty frames exist

					System.out.println("Page fault - no eviction @ " + second[0]);
					
					entry.frame = frameIndex++;
					
					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}

					entry.referred = true;
					entry.valid = true;
					
					queue.add(entry);
					
				} else {																// all frames are full, must evict
				
					// find a page to evict
					PTE entryToEvict = null;
					
					while (true) {
						
						PTE e = queue.remove();
						
						if (e.referred) {
							
							e.referred = false;
							queue.add(e);
							
						} else {
							
							entryToEvict = e;
							break;
						}
					}
					
					// evict the least recently used page
					if (entryToEvict.dirty) {											// write to disk if dirty
						
						System.out.println("Page fault - evict dirty @ " + second[0]);
						stats[2]++;
						
					} else {

						System.out.println("Page fault - evict clean @ " + second[0]);
					}
					
					entryToEvict.valid = false;
					
					// load the new page into frame
					entry.frame = entryToEvict.frame;

					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}

					entry.referred = true;
					entry.valid = true;
					
					queue.add(entry);
				}
			}
		}
	}
	
	public static void lru(int numFrames, int[] stats, Scanner traceFile) {
		
		// pageSize = 8KB (2^13) => numPages = 2^19
		// bits for frames = log_2(frameNum)
		// 1 bit each for dirty and valid
		// 64 bits to store time of last access
		stats[3] = (int) ((66 + Math.ceil(Math.log(numFrames) / Math.log(2))) * Math.pow(2, 19 - 3));		// -3: bits -> bytes
		
		int frameIndex = 0;
		
		PTE[] pageTable = new PTE[(int) Math.pow(2, 19)];
		
		long time = -1;
		
		while (traceFile.hasNext()) {
			
			time++;
			
			String[] line = traceFile.nextLine().trim().split("\\s+");
			
			if (line.length != 2) {	
				continue;
			}
			
			String event = line[0];
			
			String[] second = line[1].split(",");
			
			if (second.length != 2) {
				continue;
			}
			
			long address;
			
			try {
				
				address = Long.parseLong(second[0], 16);
			
			} catch (NumberFormatException e) {
				continue;
			}
			
			switch (event) {
			
				case "I":
					stats[0]++;
					break;
			
				case "L":
					stats[0]++;
					break;
			
				case "S":
					stats[0]++;
					break;
			
				case "M":
					stats[0] += 2;
					break;
					
				default:
					continue;
			}
			
			int pageNum = (int) (address / Math.pow(2, 13));							// pageSize = 8KB (2^13)
			
			PTE entry = pageTable[pageNum];
			
			if ((entry != null) && entry.valid) {										// valid
				
				System.out.println("Hit @ " + second[0]);
				
				if (event.equals("S") || event.equals("M")) {
					entry.dirty = true;
				}
				
				entry.timeOfAccess = time;
				
			} else {
				
				// invalid => pageFault
				stats[1]++;
				
				entry = pageTable[pageNum] = new PTE();
				
				if (frameIndex < numFrames) {											// empty frames exist

					System.out.println("Page fault - no eviction @ " + second[0]);
					
					entry.frame = frameIndex++;
					
					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}
					
					entry.valid = true;
					entry.timeOfAccess = time;
					
				} else {																// all frames are full, must evict
				
					// find the least recently used valid page
					PTE entryToEvict = null;
					
					for (PTE e : pageTable) {
						
						if ((e != null) && e.valid) {
							
							if (entryToEvict == null) {
								entryToEvict = e;
							}
							
							if (e.timeOfAccess < entryToEvict.timeOfAccess) {
								entryToEvict = e;
							}
						}
					}
					
					// evict the least recently used page
					if (entryToEvict.dirty) {											// write to disk if dirty
						
						System.out.println("Page fault - evict dirty @ " + second[0]);
						stats[2]++;
						
					} else {

						System.out.println("Page fault - evict clean @ " + second[0]);
					}
					
					entryToEvict.valid = false;
					
					// load the new page into frame
					entry.frame = entryToEvict.frame;

					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}
					
					entry.valid = true;
					entry.timeOfAccess = time;
				}
			}
		}
	}
	
	public static void nfu(int numFrames, int[] stats, Scanner traceFile) {
		
		// pageSize = 8KB (2^13) => numPages = 2^19
		// bits for frames = log_2(frameNum)
		// 1 bit each for dirty and valid
		// 32 bits to store number of references
		stats[3] = (int) ((34 + Math.ceil(Math.log(numFrames) / Math.log(2))) * Math.pow(2, 19 - 3));		// -3: bits -> bytes
		
		int frameIndex = 0;
		
		PTE[] pageTable = new PTE[(int) Math.pow(2, 19)];
		
		while (traceFile.hasNext()) {
			
			String[] line = traceFile.nextLine().trim().split("\\s+");
			
			if (line.length != 2) {	
				continue;
			}
			
			String event = line[0];
			
			String[] second = line[1].split(",");
			
			if (second.length != 2) {
				continue;
			}
			
			long address;
			
			try {
				
				address = Long.parseLong(second[0], 16);
			
			} catch (NumberFormatException e) {
				continue;
			}
			
			switch (event) {
			
				case "I":
					stats[0]++;
					break;
			
				case "L":
					stats[0]++;
					break;
			
				case "S":
					stats[0]++;
					break;
			
				case "M":
					stats[0] += 2;
					break;
					
				default:
					continue;
			}
			
			int pageNum = (int) (address / Math.pow(2, 13));							// pageSize = 8KB (2^13)
			
			PTE entry = pageTable[pageNum];
			
			if ((entry != null) && entry.valid) {										// valid
				
				System.out.println("Hit @ " + second[0]);
				
				if (event.equals("S") || event.equals("M")) {
					entry.dirty = true;
				}
				
				entry.referenced++;
				
			} else {
				
				// invalid => pageFault
				stats[1]++;
				
				entry = pageTable[pageNum] = new PTE();
				
				if (frameIndex < numFrames) {											// empty frames exist

					System.out.println("Page fault - no eviction @ " + second[0]);
					
					entry.frame = frameIndex++;
					
					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}

					entry.referenced++;
					entry.valid = true;
					
				} else {																// all frames are full, must evict
				
					// find the least used valid page
					PTE entryToEvict = null;
					
					for (PTE e : pageTable) {
						
						if ((e != null) && e.valid) {
							
							if (entryToEvict == null) {
								entryToEvict = e;
							}
							
							if (e.referenced < entryToEvict.referenced) {
								entryToEvict = e;
							}
						}
					}
					
					// evict the least used page
					if (entryToEvict.dirty) {											// write to disk if dirty
						
						System.out.println("Page fault - evict dirty @ " + second[0]);
						stats[2]++;
						
					} else {

						System.out.println("Page fault - evict clean @ " + second[0]);
					}
					
					entryToEvict.valid = false;
					
					// load the new page into frame
					entry.frame = entryToEvict.frame;

					if (event.equals("S") || event.equals("M")) {
						entry.dirty = true;
					}

					entry.referenced++;
					entry.valid = true;
				}
			}
		}
	}
	
	public static void printStats(String algo, int numFrames, int numAccesses, int numFaults, int numWrites, int tableSize) {
		
		System.out.println("\nAlgorithm: " + algo);
		System.out.println("Number of frames:         " + numFrames);
		System.out.println("Total memory accesses:    " + numAccesses);
		System.out.println("Total page faults:        " + numFaults);
		System.out.println("Total writes to disk:     " + numWrites);
		System.out.println("Total size of page table: " + tableSize + " bytes");
	}
}