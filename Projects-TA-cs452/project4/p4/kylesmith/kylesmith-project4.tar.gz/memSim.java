import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * 
 * Author: Kyle Smith
 * File: memSim.java
 * Class: CSC 452
 * Purpose: To simulate page replacement algorithms that an Operating System implementer may choose to 
 * use including Opt, Clock, LRU and NFU. After the algorithm has been run, collected statistics related 
 * to algorithm performance is printed to console. 
 * 
 * Please input command line args as follows:
 * 'vmsim �n <numframes> -a <opt|clock|lru|nfu> <tracefile>'
 *
 * See report for further analysis and commentary on implementation results
 */
public class memSim {
	// Global/static vars for simulation
	static int memAccess = 0;
	static int pageEntrySize = 4;
	static int writeDisk = 0;
	static List<Character> operations = new ArrayList<Character>();
	static int tableSize = 524288;
	static int pageFault = 0;
	
	
	// Page table object
	static class pageTbl {
		int frame;
		boolean dirty;
		boolean ref;
		boolean valid; 
		int lruVal;
		int freqCount;

		public pageTbl() {
			this.frame = -1;
			this.dirty = false;
			this.ref = true;
			this.valid = false;
			this.lruVal = -1;
			this.freqCount = 0;
		}
		
		public void setLRU(int val) {
			this.lruVal = val;
		}
		
		public void evictTbl() {
			this.frame = -1;
			this.dirty = false;
			this.ref = true;
			this.valid = false;
			this.lruVal = Integer.MAX_VALUE;
			this.freqCount = 0;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int totalSize = tableSize * pageEntrySize;
		Scanner scanner = null;
		int numframes = 0;
		numframes = Integer.parseInt(args[1]);
		int[] mem = new int[numframes];
		String algoArg = args[3];
		operations.add('I'); operations.add('L'); operations.add('S'); operations.add('M');
		pageTbl[] pageTable = new pageTbl[tableSize];
		
		// Parse arguments
		if (args.length != 5) { // check arguments
			System.out.println("Invalid argument length (5 total args)");
		}
		else if (!args[0].equals("-n") || !args[2].equals("-a")) { // check arguments
			System.out.println("Invalid argument tags, needs -n");
		}
		else if (!args[2].equals("-a")) { // check arguments
			System.out.println("Invalid argument tags, needs -a");
		}
		
		// Scan Tracefile given
		try {
			scanner = new Scanner(new File(args[4]));
		} catch (FileNotFoundException e) {
			System.out.println("Trace file not found");
		}
		
		// Create page table for simulation
		for (int i = 0; i < tableSize; i++) {
			pageTable[i] = new pageTbl();
		}
		
		if (algoArg.equals("opt")) {
			opt(scanner, numframes, mem, pageTable);
		}
		else if (algoArg.equals("clock")) {
			clock(scanner, numframes, mem, pageTable);
		}
		else if (algoArg.equals("lru")) {
			lru(scanner, numframes, mem, pageTable);
		}
		else if (algoArg.equals("nfu")) {
			nfu(scanner, numframes, mem, pageTable);
		}
		else {
			System.out.println("Invalid algorithm argument, please fix args");
		}
		
		// Print final results after algorithm has successfully ran
		System.out.println();
		System.out.println("Algorithm: " + algoArg);
		System.out.println("Number of frames: " + numframes);
		System.out.println("Total memory accesses: " + memAccess);
		System.out.println("Total page faults: " + pageFault);
		System.out.println("Total writes to disk: " + writeDisk);
		System.out.println("Total size of page table: " + totalSize);
		}
	
	/*
	 *  Optimal algorithm 
	 *  
	 *  This is used as a baseline in our simulation, yet would be impossible to
	 *  fully recreate in a real world system due to the data storage and sorting (via arraylists
	 *  and tree maps in our implementation) done beforehand to pick optimal options that are the
	 *  furthest away from our current selection, or are never used again.
	 */
	public static void opt(Scanner scanner, int numframes, int[] ram, pageTbl[] pageTable) {
		// Need efficiency but also ordering in our mapping, thus we need to use trees
		ArrayList<ArrayList<Object>> pArray = new ArrayList<ArrayList<Object>>();
		TreeMap<Integer, TreeSet<Integer>> pageMapping = new TreeMap<Integer, TreeSet<Integer>>();
		
		int count = 1;
		int curPage = 0;
		int lastPage = 0;
		
		while (scanner.hasNextLine()) {
			String str = scanner.nextLine();
			str = str.trim();
			if (str.length() < 1) { 
				// Probably valgrind output, keep going
				continue;
			}
			else if (!(operations.contains(str.charAt(0)))){
				continue;
			}
			
			// Parse and record each
			String[] line = str.split("\\s+|,");
			char op = line[0].charAt(0);
			long addr = Long.parseLong(line[1], 16);
			long tblLong = (int) (addr / 8192); // page size = 8kb for each page thus 8x1024
			int tblPosition = (int) tblLong;
			
			// Create our mapping to keep track of table position, operations, and line input
			if (pageMapping.get(tblPosition) == null) {
				TreeSet<Integer> newSet = new TreeSet<Integer>();
				pageMapping.put(tblPosition, newSet);
			}
			
			// Update counter in our tree map
			pageMapping.get(tblPosition).add(count);
			ArrayList<Object> val = new ArrayList<Object>();
			
			// Add information then add object to array
			val.add(op); val.add(str); val.add(tblPosition);
			pArray.add(val);
			
			count++;
		}

		// Given the now stored information, we can optimally replace pages
		count = 1;
		
		// Iterate through our page array and decipher entries
		for (int i = 0; i < pArray.size(); i++) {
			ArrayList<Object> buff = pArray.get(i);
			char operation = (char) buff.get(0);
			String str = (String) buff.get(1);
			int tblPosition = (int) buff.get(2);
			pageTbl entry = pageTable[tblPosition];
			
			if (!entry.valid) {
				if (numframes <= curPage) {
					// Ran is full, we must find the optimal page to evict
					int limit = -1;
					int furthest = -1;
					
					// Iterate through our ram
					for (int j = 0; j < ram.length; j++) {
						
						int nextPage;
						int p = ram[j];
						// Find the furthest/optimal page to evict in our created data
						if (!pageMapping.get(p).isEmpty()) {
							nextPage = pageMapping.get(p).first();
							while (nextPage <= count) {

								pageMapping.get(p).remove(nextPage);
								if (pageMapping.get(p).isEmpty()) {
									nextPage = -1;
									break;
								} 
								else {
									
									nextPage = pageMapping.get(p).first();
								}
							}
						}
						else {
							nextPage = -1;
							break;
						}
						if (nextPage == -1) {
							// Page will never be used again
							furthest = p;
							break;
						}
						if (nextPage > limit) {
							// Make sure we don't go over the max allotment
							furthest = p;
							limit = nextPage;
						}
					}
					
					// Pull and evict furthest as our target eviction
					pageTbl target;
					if (furthest != -1) {
						target = pageTable[furthest];
			
					} 
					else {
						target = pageTable[ram[0]];
					}
					
					entry.frame = target.frame;
					entry.valid = true;
					// Evict memory
					if (!target.dirty) {
						System.out.println(str + "/ PAGE FAULT - EVICT CLEAN");
						target.evictTbl();
					} 
					else {
						System.out.println(str + "/ PAGE FAULT - EVICT DIRTY");
						writeDisk++;
						target.evictTbl();
					}
					// Update ram with newly freed memory
					ram[entry.frame] = tblPosition;
					pageFault++;
					} 
					else { 
						// No eviction necessary since entry was not valid
						
						ram[curPage] = tblPosition;
						System.out.println(str + "/ PAGE FAULT - NO EVICTION");
						entry.valid = true;
						entry.frame = curPage;
						curPage++;
						pageFault++;
					}
			} 
			else {
				entry.ref = true;
				
				System.out.println(str + "/ HIT");

			}
			recordMem(entry, operation);
			count++;
		}

	}
	
	/*
	 *  Clock second chance algorithm
	 *  
	 *  We create a target page that we decide to look at first
	 *  and if this page has not been given a second chance, we flip the reference bit. If given
	 *  a second chance in our circular 'clock' array, then we evict this target.
	 */
	public static void clock(Scanner scanner, int numframes, int[] ram, pageTbl[] pageTable) {
		int oldestPosition = 0;
		int curPage = 0;
		int lastPage = 0;
		
		while (scanner.hasNextLine()) {
			int ramSize = ram.length;
			String str = scanner.nextLine();
			str = str.trim();
			
			// Make sure commands present in line
			if (str.length() < 1 ) {
				continue;
			}
			else if (!(operations.contains(str.charAt(0)))){
				continue;
			}
			
			// processing each of the operation
			String[] line = str.split("\\s+|,");
			char op = line[0].charAt(0);
			
			long addr = Long.parseLong(line[1], 16);
			long tblLong = (int) (addr / 8192); // page size = 8kb for each page thus 8x1024
			int tblPosition = (int) tblLong;
			pageTbl entry = pageTable[tblPosition];
			
			if (!entry.valid) { // Need to evict
				if (numframes <= curPage) { 
					// Check our target and verify if we can evict
					int targetindex = ram[oldestPosition];
					pageTbl target = pageTable[targetindex];
					
					while (target.ref != false) {
						// Go until target is found
						oldestPosition++;
						if (ramSize <= oldestPosition) { 
							// Go around the clock
							oldestPosition = 0;
						}
						target.ref = false;
						targetindex = ram[oldestPosition];
						target = pageTable[targetindex];
					}
					
					// now we can evict the given entry
					entry.valid = true;
					entry.frame = target.frame;
					if (!target.dirty) {
						System.out.println(str + "/ PAGE FAULT - EVICT CLEAN");
						target.evictTbl();
					} 
					else {
						System.out.println(str + "/ PAGE FAULT - EVICT DIRTY");
						writeDisk++;
						target.evictTbl();
					}

					// Update table with newly freed space
					ram[oldestPosition] = tblPosition;
					oldestPosition++;
					
					if (ramSize <= oldestPosition) {
						oldestPosition = 0;
					}
					
					pageFault++;
				    } 
				    else {

				    	// No eviction necessary since entry was not valid
				    	ram[curPage] = tblPosition;
				    	System.out.println(str + "/ PAGE FAULT - NO EVICTION");
				    	entry.frame = curPage;
				    	entry.valid = true;
				    	curPage++;
				    	pageFault++;
				    }
			} 
			else {
				System.out.println(str + "/ HIT");
				// Second chance.. don't let it happen again 
				entry.ref = true;
			}

			recordMem(entry, op);
		}
	}

	/*
	 *  Not Frequently Used algorithm
	 *  
	 *  A weak approximation of least frequently used, we keep a count of how often the page has
	 *  been used in our page table and we make the decision of kicking out the page that has the
	 *  lowest amount of uses for our new memory.
	 */
	public static void nfu(Scanner scanner, int numframes, int[] ram, pageTbl[] pageTable) {
		int oldestPosition = 0;
		int curPage = 0;
		int lastPage = 0;
		
		while (scanner.hasNextLine()) {
			int ramSize = ram.length;
			String str = scanner.nextLine();
			str = str.trim();
			
			// Make sure commands present in line
			if (str.length() < 1 ) {
				continue;
			}
			else if (!(operations.contains(str.charAt(0)))){
				continue;
			}
			
			// processing each of the operation
			String[] line = str.split("\\s+|,");
			
			char op = line[0].charAt(0);
			
			long addr = Long.parseLong(line[1], 16);
			long tblLong = (int) (addr / 8192); // page size = 8kb for each page thus 8x1024
			int tblPosition = (int) tblLong;
			pageTbl entry = pageTable[tblPosition];
			
			if (!entry.valid) {
				if (curPage >= numframes) {
					
					int ramIndex = -1;
					pageTbl target = null;
					// Search Ram
					for(int i=0; i < ram.length; i++){
						// Check if initialized
						if(ramIndex==-1){
							ramIndex=i;
						}
						int targetIndex = ram[ramIndex];
						target = pageTable[targetIndex];
						pageTbl check = pageTable[ram[i]];
						
						// Finds the least used to evict
						if(target.freqCount < check.freqCount){ //Finds the least used to evict
							ramIndex=i;
						}
					}
					
					int targetIndex = ram[ramIndex];
					target = pageTable[targetIndex];
					entry.frame = target.frame;
					entry.valid = true;
					
					if (!target.dirty) {
						System.out.println(str + " (page fault - evict clean)");
						target.evictTbl();
						
					} 
					else {
						writeDisk++;
						System.out.println(str + " (page fault - evict dirty)");
						target.evictTbl();
						
					}
					// add to ram the current Page
					// Update table with newly freed space
					ram[ramIndex] = tblPosition;
					pageFault++;
					
			    } 
			    else {
			    	// No eviction necessary since entry was not valid
			    	ram[curPage] = tblPosition;
			    	System.out.println(str + "/ PAGE FAULT - NO EVICTION");
			    	entry.frame = curPage;
			    	entry.valid = true;
			    	curPage++;
			    	pageFault++;
			    }
			} 	
			else {
				// We used it, must be important right?
				// Well that's at least what the algorithm says: update frequency counter
				entry.freqCount++;
				System.out.println(str + " (hit)");
			}
			
			recordMem(entry, op);
		}
		
		
	}
	
	
	/*
	 *  Least Recently used page algorithm
	 *  
	 *  Keeps track of and tallies a 'time stamp' in our page table to
	 *  be compared in our algorithm in which we can choose the least recently used. The time stamp we use \
	 *  is actually the memory access count at time of storage in our simulation.
	 */
	public static void lru(Scanner scanner, int numframes, int[] ram, pageTbl[] pageTable) {
		int oldestPosition = 0;
		int curPage = 0;
		int lastPage = 0;
		
		while (scanner.hasNextLine()) {
			int ramSize = ram.length;
			String str = scanner.nextLine();
			str = str.trim();
			
			// Make sure commands present in line
			if (str.length() < 1 ) {
				continue;
			}
			else if (!(operations.contains(str.charAt(0)))){
				continue;
			}
			
			// processing each of the operation
			String[] line = str.split("\\s+|,");
			
			char op = line[0].charAt(0);
			
			long addr = Long.parseLong(line[1], 16);
			long tblLong = (int) (addr / 8192); // page size = 8kb for each page thus 8x1024
			int tblPosition = (int) tblLong;
			pageTbl entry = pageTable[tblPosition];
			
			if (!entry.valid) {
				if (curPage >= numframes) {
					
					int ramIndex = -1;
					pageTbl target = null;
					// Search Ram
					for(int i=0; i < ram.length; i++){
						// Check if initialized
						if(ramIndex==-1){
							ramIndex=i;
						}
						int targetIndex = ram[ramIndex];
						target = pageTable[targetIndex];
						pageTbl check = pageTable[ram[i]];
						// Finds the least used to evict
						if(target.lruVal > check.lruVal ){ //Finds the least used to evict
							ramIndex=i;
						}
					}
					
					int targetIndex = ram[ramIndex];
					target = pageTable[targetIndex];
					entry.frame = target.frame;
					entry.valid = true;
					
					if (!target.dirty) {
						System.out.println(str + " (page fault - evict clean)");
						target.evictTbl();
						
					} 
					else {
						writeDisk++;
						System.out.println(str + " (page fault - evict dirty)");
						target.evictTbl();
						
					}
					// add to ram the current Page
					ram[ramIndex] = tblPosition;
					pageFault++;
					
			    } 
			    else {
			    	// No eviction necessary since entry was not valid
			    	ram[curPage] = tblPosition;
			    	System.out.println(str + "/ PAGE FAULT - NO EVICTION");
			    	entry.frame = curPage;
			    	entry.valid = true;
			    	curPage++;
			    	pageFault++;
			    }
			} 
			else {
				System.out.println(str + " (hit)");
			}
			recordMem(entry, op);
		}
		
	}
	
	/*
	 * We can easily record the memory access of our operations based on the recorded char in our tracefile
	 */
	public static void recordMem(pageTbl entry, char operation) {
		if (operation == 'S') { // Store
			entry.dirty = true;
		} 
		else {
			if (operation == 'M') { // Modify
				entry.dirty = true;
				memAccess++;
			}
		}
		memAccess++;
		entry.lruVal = memAccess; // For LRU algo
	}

}
