import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class vmsim {

    private static final int NUM_PAGES = 524288; // 2^32/2^13 = 2^19

    public static void main(String[] args) {
        int numFrames = Integer.parseInt(args[1]);
        String alg = args[3];
        String fileName = args[4];
        List<String> text = getText(fileName);
        PageTable pt = new PageTable(NUM_PAGES);
        Frames frames = new Frames(numFrames);
        List<Integer> recentlyUsed = new LinkedList<>();
        int clockHand = 0;
        int totalMemAccess = 0;
        int totalWrites = 0;
        int totalPageFaults = 0;
        int lineIndex = 0;
        for (String line : text) {
            if (!line.startsWith("I") && !line.startsWith("L") && !line.startsWith("S") && !line.startsWith("M")) {
                lineIndex++;
                continue;
            }

            String[] parts = line.split(" ");

            String address = parts[parts.length - 1].split(",")[0];
            String subaddress = address.substring(2, 4);
            int addressValue = Integer.decode("0x" + subaddress);
            if (pt.valid[addressValue]) {
                pt.referenced[addressValue] = true;
                pt.referencedInt[addressValue]++;
                if (recentlyUsed.size() > 0)
                    recentlyUsed.remove((Integer) addressValue);
                recentlyUsed.add(addressValue);
                System.out.println("Hit");
            } else if (frames.numFilled != numFrames) {
                totalPageFaults++;
                pt.valid[addressValue] = true;
                pt.referenced[addressValue] = true;
                pt.referencedInt[addressValue]++;
                pt.physicalPageIndex[addressValue] = frames.numFilled;
                if (recentlyUsed.size() > 0)
                    recentlyUsed.remove((Integer) addressValue);
                recentlyUsed.add(addressValue);
                frames.contentAddress[frames.numFilled] = address;
                frames.numFilled = frames.numFilled + 1;
                System.out.println("Page fault - no eviction");
            } else if (alg.equalsIgnoreCase("opt")) {
                totalPageFaults++;
                int frameToEvict = findFurthestPage(text, lineIndex + 1, frames);
                String pageToEvict = frames.contentAddress[frameToEvict];
                String subaddressToEvict = pageToEvict.substring(2, 4);
                int pageAddressToEvict = Integer.decode("0x" + subaddressToEvict);
                pt.valid[pageAddressToEvict] = false;
                pt.referenced[pageAddressToEvict] = false;
                if (pt.dirty[pageAddressToEvict]) {
                    totalMemAccess++;
                    totalWrites++;
                    System.out.println("Page Fault - evict dirty");
                } else {
                    System.out.println("Page Fault - evict clean");
                }
                pt.dirty[pageAddressToEvict] = false;

                pt.valid[addressValue] = true;
                pt.referenced[addressValue] = true;
                pt.physicalPageIndex[addressValue] = frameToEvict;
                frames.contentAddress[frameToEvict] = address;
            } else if (alg.equalsIgnoreCase("clock")) {
                totalPageFaults++;
                while (pt.referenced[clockHand] || !pt.valid[clockHand]) {
                    pt.referenced[clockHand] = false;
                    clockHand = (clockHand + 1) % NUM_PAGES;
                }
                int frameToOverride = pt.physicalPageIndex[clockHand];
                pt.valid[clockHand] = false;
                pt.referenced[clockHand] = false;
                if (pt.dirty[clockHand]) {
                    totalMemAccess++;
                    totalWrites++;
                    System.out.println("Page Fault - evict dirty");
                } else {
                    System.out.println("Page Fault - evict clean");
                }
                pt.dirty[clockHand] = false;

                pt.valid[addressValue] = true;
                pt.referenced[addressValue] = true;
                frames.contentAddress[frameToOverride] = address;
            } else if (alg.equalsIgnoreCase("lru")) {
                totalPageFaults++;
                int pageToEvict = recentlyUsed.get(0);
                int frameToEvict = pt.physicalPageIndex[pageToEvict];
                pt.valid[pageToEvict] = false;
                pt.referenced[pageToEvict] = false;
                if (pt.dirty[pageToEvict]) {
                    totalMemAccess++;
                    totalWrites++;
                    System.out.println("Page Fault - evict dirty");
                } else {
                    System.out.println("Page Fault - evict clean");
                }
                pt.dirty[pageToEvict] = false;

                pt.valid[addressValue] = true;
                pt.referenced[addressValue] = true;
                frames.contentAddress[frameToEvict] = address;
            } else if (alg.equalsIgnoreCase("nfu")) {
                totalPageFaults++;
                int pageToEvict = 0;
                int minReferenced = Integer.MAX_VALUE;
                for (int i = 0; i < NUM_PAGES; i++) {
                    if (pt.valid[i] && minReferenced > pt.referencedInt[i]) {
                        pageToEvict = i;
                        minReferenced = pt.referencedInt[i];
                    }
                }
                int frameToEvict = pt.physicalPageIndex[pageToEvict];
                pt.valid[pageToEvict] = false;
                pt.referenced[pageToEvict] = false;
                pt.referencedInt[pageToEvict] = 0;
                if (pt.dirty[pageToEvict]) {
                    totalMemAccess++;
                    totalWrites++;
                    System.out.println("Page Fault - evict dirty");
                } else {
                    System.out.println("Page Fault - evict clean");
                }
                pt.dirty[pageToEvict] = false;

                pt.valid[addressValue] = true;
                pt.referenced[addressValue] = true;
                pt.referencedInt[addressValue]++;
                frames.contentAddress[frameToEvict] = address;
            }

            if (line.startsWith("I") || line.startsWith("L")) {
                totalMemAccess++;
            } else if (line.startsWith("S")) {
                totalMemAccess++;
                totalWrites++;
                pt.dirty[addressValue] = true;
            } else if (line.startsWith("M")) {
                totalMemAccess++;
                totalMemAccess++;
                totalWrites++;
                pt.dirty[addressValue] = true;
            }

            lineIndex++;
        }
        System.out.println("Algorithm: " + alg);
        System.out.println("Number of frames: " + numFrames);
        System.out.println("Total memory accesses: " + totalMemAccess);
        System.out.println("Total page faults: " + totalPageFaults);
        System.out.println("Total writes to disk: " + totalWrites);
        System.out.println("Total writes to disk: " + (NUM_PAGES * 11) + " bytes"); // 11 total bytes per entry
    }

    private static int findFurthestPage(List<String> text, int lineStart, Frames frames) {
        int furthest = 0;
        int frameToEvict = 0;
        for (int j = 0; j < frames.contentAddress.length; j++) {
            for (int i = lineStart; i < text.size(); i++) {
                String[] line = text.get(i).split(" ");
                String address = line[line.length - 1].split(",")[0];
                if (address.equals(frames.contentAddress[j])) {
                    if (i > furthest) {
                        furthest = i;
                        frameToEvict = j;
                    }
                }
            }
        }
        return frameToEvict;
    }

    private static List<String> getText(String fn) {
        List<String> text = new ArrayList<>();
        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader(fn));
            String line = br.readLine().strip();
            while (line != null) {
                text.add(line);
                line = br.readLine();
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return text;
    }

}
