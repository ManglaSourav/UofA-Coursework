public class PageTable {

    int[] physicalPageIndex;
    boolean[] dirty;
    boolean[] referenced;
    int[] referencedInt;
    boolean[] valid;

    PageTable(int n) {
        physicalPageIndex = new int[n];
        dirty = new boolean[n];
        referenced = new boolean[n];
        referencedInt = new int[n];
        valid = new boolean[n];
    }

}
