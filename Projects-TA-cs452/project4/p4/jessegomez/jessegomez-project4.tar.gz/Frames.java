public class Frames {

    String[] contentAddress;
    int numFilled;

    Frames(int n) {
        contentAddress = new String[n];
        int numFilled = 0;
    }

}
