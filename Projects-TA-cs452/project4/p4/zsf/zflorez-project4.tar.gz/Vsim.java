
/**
 * Author: Zachary Florez 
 * Course: CSC 452 
 * Class: Vsim.java 
 * 
 * Description: 
 * In this project I compare the results of four different
 * algorithms on traces of memory references. While simulating
 * an algorithm, I then collect stats about its performance 
 * such as the number of page faults that occur and the number 
 * of dirty frames that had to be written back to disk. 
 * After all that I created another file full of my results 
 * with graphs to compare the performace of the four different 
 * algotihms. 
 * 
 */

import java.util.*;
import java.io.*;

public class Vsim {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("Hello! Welcome to Project 4 in CSC 452.\n");

        // First do the command line argument checks
        commandLineChecks(args);

        HashMap<String, Integer> statistics = new HashMap<String, Integer>();
        ArrayList<HashMap<String, Integer>> allStats = new ArrayList<HashMap<String, Integer>>();


        // Add the new algorithms to our List 
        statistics = getNewAlgorithmStats(1);
        allStats.add(statistics);

        statistics = getNewAlgorithmStats(2);
        allStats.add(statistics);

        statistics = getNewAlgorithmStats(3);
        allStats.add(statistics);

        statistics = getNewAlgorithmStats(4);
        allStats.add(statistics);

        try {

            File tracefile = new File(args[4]);
            Scanner fileReader = new Scanner(tracefile);

            // Now we want to skip all the heading lines for the tracefiles.
            String firstLine = readFirstLines(fileReader, tracefile);

            // When we get here we start off with the first instruction line of the file
            // and the scanner starts at the second line.
            String[] currInstruction = getCurrInstruction(firstLine);

            while (fileReader.hasNextLine()) {

                // Stop when you get to the bottom of the file where there 
                // is no more instructions
                String next = fileReader.nextLine(); 
                if (next.startsWith("=") || next.startsWith("-")) {
                    break; 
                }
                
                currInstruction = getCurrInstruction(next); 

            }

        } catch (FileNotFoundException e) {
            System.out.println(e);
        }

        // Comment out printing for complicitig and calling the exact evictor 
        //printOutSummary(allStats);
    }



    /**
     * Splits the current line down into a String[] that we return 
     * back to main to do our testing. 
     * 
     * @param instruction, String current line. 
     * @return String[]
     */
    public static String[] getCurrInstruction(String instruction) {

        // First split by white spaces, then the comma, then combine 
        // the two splits. 
        String[] instructionList = instruction.split("\\s+");

        // Check if this is an instruction line or a Store/Load/Modify 
        if (instructionList.length == 2) {

            String[] second = instructionList[1].split(",");
            String[] last = { instructionList[0], second[0], second[1] };
            return last; 

        } else {
            String[] second = instructionList[2].split(","); 
            String[] last   = {instructionList[1], second[0], second[1]}; 
            return last; 
        }

    }


    /**
     * Helper function called from main to read the first lines 
     * and move the pointer for the Scanner. Since once we realize when we 
     * get to the actual first line, and we already read the string from the 
     * Scanner, we just return that first line back to main since the Scanner will 
     * ttechnically be at the second valid line. 
     * 
     * @param fileReader, Scanner
     * @param tracefile, File being read 
     * @return String, first first valid instruction. 
     */
    public static String readFirstLines(Scanner fileReader, File tracefile) {

        String line = "";

        // Iterate until we find the first valid line. 
        while (fileReader.hasNextLine()) {

            line = fileReader.nextLine();
            if (line.startsWith("=")) {
                continue;
            } else if (line.startsWith("-")) {
                continue;
            } else {
                return line;
            }
        }

        // Need this for error but if all command line checks are valid 
        // then this will never happen. 
        return "";
    }



    /**
     * Inital setup of all the algorithms to throw into the allStats List that
     * is created in main.
     * 
     * @param algorithm, integer for what algo we're initializing.
     * @return HashMap <String, Integer> full of one algorithm stats.
     */
    public static HashMap<String, Integer> getNewAlgorithmStats(int algorithm) {

        HashMap<String, Integer> statistics = new HashMap<String, Integer>();

        // Throw all values in and return them. 
        statistics.put("Algorithm", algorithm);
        statistics.put("NF", 0);
        statistics.put("MA", 0);
        statistics.put("PF", 0);
        statistics.put("WD", 0);
        return statistics;

    }

    /**
     * Helper function called from main to parse out and check all of the
     * command line arguments before actually running the program.
     * 
     * @param args, String []
     * 
     * @return None
     */
    public static void commandLineChecks(String[] args) {

        // Must be 5 different arguments 
        if (args.length != 5) {
            System.out.println("Invalid format to run program :(");
            System.out.println("Expected:");
            System.out.println("java Vsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.out.println("Exiting Now...");
            System.exit(-1);
        } 
        
        // First arg has to be "-n"
        else if (args[0].equals("-n") == false) {
            System.out.println("Argument one was not the '-n' flag.");
            System.out.println("Expected:");
            System.out.println("java Vsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.out.println("Exiting Now...");
            System.exit(-1);
        } 
        
        // Second arg has to be an integer 
        else if (isNumeric(args[1]) == false) {
            System.out.println("Argument 2 was not a number");
            System.out.println("Expected:");
            System.out.println("java Vsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.out.println("Exiting Now...");
            System.exit(-1);
        } 
        
        // Third arg has to be the a flag
        else if (args[2].equals("-a") == false) {
            System.out.println("Argument 3 was not the '-a' flag.");
            System.out.println("Expected:");
            System.out.println("java Vsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.out.println("Exiting Now...");
            System.exit(-1);
        }

        String action = args[3];

        // Action has to be one of the following: 
        if (!action.equals("opt") && !action.equals("clock") &&
                !action.equals("lru") && !action.equals("nfu")) {
            System.out.println("Argument 4 was not the an expected action.");
            System.out.println("Expected:");
            System.out.println("java Vsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.out.println("Exiting Now...");
            System.exit(-1);
        }

        String tracefile = args[4];

        // File that was inputted has to be at least "<>.trace"
        if ((tracefile.length() >= 7) == false) {
            System.out.println("Argument 5 was not a tracefile.");
            System.out.println("Expected:");
            System.out.println("java Vsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.out.println("Exiting Now...");
            System.exit(-1);
        } 
        
        // File has to end in ".trace"
        else if (!tracefile.substring(tracefile.length() - 6, tracefile.length()).equals(".trace")) {
            System.out.println("Argument 5 was not a tracefile.");
            System.out.println("Expected:");
            System.out.println("java Vsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.out.println("Exiting Now...");
            System.exit(-1);
        }
    }



    /**
     * Helper function called from command line checker function
     * to check that a input was a number.
     * 
     * @param s, String
     * @return true is s is numeric, otherwise false.
     */
    public static boolean isNumeric(String s) {

        // Must be in a try/catch for parsing an int. 
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }



    /**
     * Function called from main to print out all the statistics for the four
     * different
     * algorithms.
     * 
     * @param allStats, An ArrayList filled with all of the statistics from the
     *                  four different algorithms.
     */
    public static void printOutSummary(ArrayList<HashMap<String, Integer>> allStats) {

        System.out.println("------------------------ SUMMARY ------------------------");

        // Loop through all four algos to get all the different stats.
        for (int i = 0; i < allStats.size(); i++) {

            // algorithm is going to be curr algorithm that we are looking at.
            HashMap<String, Integer> algorithm = allStats.get(i);
            String nameOfAlgo = "";

            // Statements to check what algorithm that we're looking at.
            if (algorithm.get("Algorithm") == 1) {
                nameOfAlgo = "OPT";
            } else if (algorithm.get("Algorithm") == 2) {
                nameOfAlgo = "Clock";
            } else if (algorithm.get("Algorithm") == 3) {
                nameOfAlgo = "LRU";
            } else if (algorithm.get("Algorithm") == 4) {
                nameOfAlgo = "NFU";
            }

            System.out.println();
            System.out.println("Algorithm: " + nameOfAlgo);
            System.out.printf("Number of frames: \t%d\n", algorithm.get("NF"));
            System.out.printf("Total memory accesses: \t%d\n", algorithm.get("MA"));
            System.out.printf("Total page faults: \t%d\n", algorithm.get("PF"));
            System.out.printf("Total writes to disk: \t%d\n", algorithm.get("WD"));
            System.out.println();
        }
    }

    
    /**
     * Inner class that represents an actual Page.
     */
    public class Page {

        boolean dirtyBit; 
        int pageId; 
        boolean referenced; 

        /**
         * Constructor
         */
        public Page (int pageId) {
            this.pageId = pageId; 
            dirtyBit = false; 
            referenced = true; 
        }

    }


    /**
     * Inner class that represents a Operation 
     */
    class Operation {
        Page page; 
        int offset; 
        String mode; 

        /**
         * Constructor
         */
        public Operation(Page page, int offset, String mode) {
            this.page = page; 
            this.offset = offset; 
            this.mode = mode; 
        }
    } // END Operation 



    /**
     * Inner interface used for all different algorithms. 
     */
    public interface EvicterInterface {
        public abstract void operation(Page[] frames, int frameID);
        public abstract int get_evictee(Page[] frames); 
    } // END EvictorInterface 


    
    class LRUEvictor implements EvicterInterface {

        HashMap<Integer, Integer> map; 
        HashSet<Integer> set; 
        int max; 
        int pageFaults; 
        int n; 


        /** 
         * Constructor 
         */ 
        public LRUEvictor(int max, int frameID, Page[] frames, int n) {
            set = new HashSet<>(max);
            map = new HashMap<>(); 
            pageFaults = 0; 
            this.max = max; 
            this.n = n; 
        }


        @Override
        public void operation(Vsim.Page[] frames, int frameID) {
            
            // Iterate through all them. 
            for (int i = 0; i < this.n; i++) {

                // Check if set can hold more pages. 
                if (set.size() < max) {

                    // Now check if the page is in there 
                    // already or not. 
                    if (!set.contains(frames[i].pageId)) {
                        set.add(frames[i].pageId);
                        pageFaults ++; 
                    }

                    // Last Recently Used index of every page. 
                    map.put(frames[i].pageId, i); 
                }


                // Otherwise we check if the page is in the set. 
                else {
                    if (!set.contains(frames[i].pageId)) {
                        int lru = Integer.MAX_VALUE, val=Integer.MIN_VALUE;

                        Iterator<Integer> iterator = set.iterator(); 

                        // Loop through until we get the least recent page 
                        // that is inside of the set. 
                        while (iterator.hasNext()) {
                            int temp = iterator.next(); 

                            if (map.get(temp) < lru) {
                                lru = map.get(temp); 
                                val = temp; 
                            }
                        }

                        set.remove(val); 
                        map.remove(val); 

                        // Add on to the page faults and to the set. 
                        set.add(frames[i].pageId); 
                        pageFaults++; 
                    }
                    map.put(frames[i].pageId, i);
                }
            }
        }

        @Override
        public int get_evictee(Vsim.Page[] frames) {
            
            // Return all the page faults here that were generated in the above 
            // function. 
            return pageFaults; 
        }
        
    }


    class ClockEvictor implements EvicterInterface {

        // Need to have a pointer of where the clock is at 
        // currently. 
        int clockHand = 0; 


        @Override
        public void operation(Vsim.Page[] frames, int id) {
            
            // Just set frame that we're looking referenced bit 
            // to true. Going around in a clock here. 
            frames[id].referenced = true; 
            
        }

        @Override
        public int get_evictee(Vsim.Page[] frames) {
            
            // First iterate through while true until we get our 
            // first unreferenced frame. 
            while (true) {

                // set new eID, then change where the clock is pointing to. 
                if (frames[clockHand].referenced == false) {
                    int eID = clockHand; 
                    clockHand = (clockHand + 1) % frames.length; 
                    return eID; 
                } 
                
                // Set it to not refrenced and then change where the clock is 
                // pointing. 
                else {
                    frames[clockHand].referenced = false; 
                    clockHand = (clockHand + 1) % frames.length; 
                }
            }
        }        
    } // END CLOCK EVICTOR 



    class OPTevictor implements EvicterInterface {

        int time = 0; 
        List<Integer> nextUsed;
        List<Integer> frameNextUsed = new ArrayList<Integer>(); 
        

        /**
         * Constructor
         */
        public OPTevictor(Operation[] operations) {
            this.nextUsed = new ArrayList<Integer>(operations.length); 
            HashMap<Page, Integer> used = new HashMap<Page, Integer>(); 

            for (int i = operations.length - 1; i > 0; i --) {

                Operation curOperation = operations[i]; 
                
                if (used.containsKey(curOperation.page)) { 
                    nextUsed.add(i, used.get(curOperation.page.pageId));
                } else { 
                    nextUsed.add(i, null);
                } 
                used.put(curOperation.page, i);
            } // END FOR LOOP 
        }


        @Override
        public void operation(Page[] frames, int frameID) {

            // Do our checks first
            if (frames.length > frameNextUsed.size()) {
                frameNextUsed.add(nextUsed.get(time)); 
            } else {
                frameNextUsed.add(frameID, nextUsed.get(time));
            }

            // Increment time 
            time ++; 
        }

        @Override
        public int get_evictee(Vsim.Page[] frames) {
            
            Integer largestNextUsed = Collections.max(frameNextUsed); 

            if (largestNextUsed != null) {
                return frameNextUsed.indexOf(largestNextUsed); 
            }

            List<Integer> ties = new ArrayList<Integer>(); 

            // Here we check for ties 
            for (int i = 0; i < frames.length; i ++) {
                if (frameNextUsed.get(i) == null) {
                    ties.add(frameNextUsed.get(i)); 
                }
            }
            return Collections.min(ties); 
        }
    } // END OPTEvictor 



    class PageTable {

        /**
         * This is the inner class needed to simulate a page table in memory. 
         */

        // Inital variables. 
        int pageFaultCount, memoryAccessCount, writeCount, maxFrameNumber; 

        // Eviction algorithm we are going to use. 
        int evictor = 0; 
        EvicterInterface evictorClass; 

        Page[] frames; 
        HashMap<Integer, Integer> frameIDCache; 

        public PageTable(int selectedEvictorClass, int frameNumber, Operation[] operations) {

            if (selectedEvictorClass == 1) {
                evictorClass = new OPTevictor(operations); 
            } else if (selectedEvictorClass == 2) {
                evictorClass = new ClockEvictor(); 
            }

            pageFaultCount = 0; 
            memoryAccessCount = 0; 
            writeCount = 0; 
            maxFrameNumber = frameNumber; 
            this.evictor = selectedEvictorClass; 
            frameIDCache = new HashMap<Integer, Integer>(); 
        } // END Constructor 


        /**
         * Look up ID, set the class to do operation, then increment memory access 
         * by one. 
         * 
         * @param id
         */
        public void write(String id) {
            int newId = frameIDLookup(id); 
            evictorClass.operation(frames, newId);
            this.memoryAccessCount += 1; 
        } // END write 


        /**
         * Lookup new ID, set the class to do operation, and increment the 
         * number of times the memory was accessed by one. 
         * @param id
         */
        public void read(String id) {
            int newId = frameIDLookup(id);
            evictorClass.operation(frames, newId);
            this.memoryAccessCount += 1; 

        } // END read

        /**
         * Method to assist with the frame lookup for the process inside 
         * of the Page Table. 
         * @param id
         * @return
         */
        public int frameIDLookup(String id) {

            if ((frames[frameIDCache.get(id)].pageId == Integer.parseInt(id)) && frameIDCache.containsKey(id)) {
                return frameIDCache.get(id); 
            }
            
            // If we get here we have a page fault. 
            pageFaultCount += 1; 

            // First check if we have any empty frames. 
            if (maxFrameNumber > frames.length) {
                Page[] newFrames = new Page[frames.length + 1]; 
                
                // Appending a new value to the array by looping through 
                for (int i = 0; i < frames.length; i ++) {
                    newFrames[i] = frames[i]; 
                }

                newFrames[newFrames.length - 1] = new Page(Integer.parseInt(id)); 
                frames = newFrames; 
                int fID = frames.length - 1; 
                frameIDCache.put(Integer.parseInt(id), fID); 
                return fID; 
            }

            // When we get here we know that we have to evict and replace 
            // some frame. 
            int evictID = evictorClass.get_evictee(frames); 

            if (frames[evictID].dirtyBit == true) { 
                writeCount += 1; 
            }

            // Create new frame, add to the cache, and then return the evictID. 
            frames[evictID] = new Page(Integer.parseInt(id)); 
            frameIDCache.put(Integer.parseInt(id), evictID); 
            return evictID; 
        }


    } // END PAGE TABLE

}
