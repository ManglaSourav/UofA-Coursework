/*
 * Author: Winston Zeng
 * File: vmsim.java
 * Class: CSC 452, Spring 2021
 * Assignment: Project 4: Virtual Memory Simulator
 * Date: 4/8/22
 * Purpose: This program compares the results of four different
 * algorithms on traces of memory references.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.lang.Math;
import java.util.ArrayList;

/*
 * Page class: page objects, each holds the page number, a boolean
 * indicating whether the page is in RAM, a boolean indicating
 * whether the page is clean or dirty, an arraylist holding the lines
 * that reference the page, the reference index into said arraylist,
 * the number of references for NFU, and the referenced binary digit
 * for clock.
 */
class Page {
	public int pageNum = 0;
	public int inRam = 0;
	public int clean = 0;
	public ArrayList<Integer> references = new ArrayList<Integer>();
	public int refNum = -1;
	public int uses = 0;
	public int R = 1;

	Page(int ID) {
		pageNum = ID;
	}
}

/*
 * Frame class: frame objects, each holds a page object, representing
 * a frame holding a page in RAM, and a pointer to the next frame
 * object (linked list).
 */
class Frame {
	Page page;
	Frame(Page pg) {
		page = pg;
	}
}

class vmsim {
	/*
	 * Implementation of C's atoi, converts strings to ints
	 */
	static int myAtoi(String str) {
		int res = 0;
		for(int i=0; i<str.length(); i++) {
			Boolean flag = Character.isDigit(str.charAt(i));
			if(!flag) return -1;
			res = res*10+str.charAt(i)-'0';
		}
		return res;
	}
	
	/*
	 * fillPages helper, fills in the length 2^19 array of pages with the
	 * contents from the passed in trace file.
	 *
	 * @param file: trace file
	 * @param pages: empty array of pages of length 2^19
	 */
	public static void fillPages(File file, Page[] pages) {
		int line = 0;
		try {
			Scanner scanner1 = new Scanner(file);
			while(scanner1.hasNextLine()) {
				String data = scanner1.nextLine();
				if(data.charAt(0) == '=' || data.charAt(0) == '-') {
					line++;
					continue;
				} else if(data.charAt(0) != 'I' && data.charAt(0) != ' ') {
					line++;
					continue;
				} else {
					// get the 8-digit hex address
					String[] arrOfData = data.split(" ");
					String hex = arrOfData[2].split(",")[0];
					// convert to integer
					int address = (int)Long.parseLong(hex, 16);
					// divide by 8KB (page size) to get page number
					int pageNumber = address >>> 13;
					if(pages[pageNumber] == null) pages[pageNumber] = new Page(pageNumber);
					// finally, append the file line number to the page
					// object's list of references (not used for all the
					// algorithms)
					pages[pageNumber].references.add(line);
				}
				line++;
			}
			scanner1.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Optimal page replacement algorithm.
	 *
	 * @param file: trace file
	 * @param pages: empty array of pages of length 2^19, to be filled in
	 * @param numFrames: desired number of frames in RAM
	 */
	public static int[] opt(File file, Page[] pages, int numFrames) {
		Frame[] frames = new Frame[numFrames];
		int memAccesses = 0;			// total memory accesses
		int pageFaults = 0;			// total page faults
		int writes = 0;				// total writes to disk
		int framesInRam = 0;			// number of frames
		int line = 1;				// file line counter

		fillPages(file, pages);
		try {
			Scanner scanner2 = new Scanner(file);
			while(scanner2.hasNextLine()) {
				String data = scanner2.nextLine();
				if(data.charAt(0) == '=' || data.charAt(0) == '-') {
					line++;
					continue;
				} else if(data.charAt(0) != 'I' && data.charAt(0) != ' ') {
					line++;
					continue;
				} else {
					String[] arrOfData = data.split(" ");
					String instr1 = arrOfData[0];
					String instr2 = arrOfData[1];
					// increment total memory accesses
					memAccesses++;
					// modify has an additional memory access
					if(instr2.equals("M")) memAccesses++;

					String hex = arrOfData[2].split(",")[0];
					int address = (int)Long.parseLong(hex, 16);
					int pageNumber = address >>> 13;
					pages[pageNumber].refNum++;

					if(framesInRam != numFrames) {
						if(pages[pageNumber].inRam == 0) {
							System.out.println("page fault - no eviction");
							pageFaults++;
							frames[framesInRam] = new Frame(pages[pageNumber]);
							framesInRam++;			// increment frame counter
							pages[pageNumber].inRam = 1;	// set the current page to indicate in RAM
						}
					} else if(pages[pageNumber].inRam == 0) {
						// eviction
						pageFaults++;
						int maxWait = 0;
						int breakFlag = 0;
						Frame max = frames[0];
						for(int i=0; i<numFrames; i++) {
							if(frames[i].page.refNum == frames[i].page.references.size()-1) {
								// if the current frame's page has no more future references,
								// swap in new page into frame
								frames[i].page.inRam = 0;
								if(frames[i].page.clean == 1) {
									System.out.println("page fault - evict dirty");
									writes++;
									frames[i].page.clean = 0;
								} else System.out.println("page fault - evict clean");
								frames[i].page = pages[pageNumber];
								pages[pageNumber].inRam = 1;
								breakFlag = 1;
								break;
							}
							// Calculate how long until the frame's page is next referenced
							int delay = frames[i].page.references.get(frames[i].page.refNum+1)-pages[pageNumber].references.get(pages[pageNumber].refNum);
							if(delay > maxWait) {
								maxWait = delay;
								max = frames[i];
							}
						}
						// if no page with no more references was found
						if(breakFlag == 0) {
							max.page.inRam = 0;
							if(max.page.clean == 1) {
								System.out.println("page fault - evict dirty");
								writes++;
								max.page.clean = 0;
							} else System.out.println("page fault - evict clean");
							max.page = pages[pageNumber];
							pages[pageNumber].inRam = 1;
						}
					} else System.out.println("hit");
					if(instr2.equals("S") || instr2.equals("M")) pages[pageNumber].clean = 1;
				}
			}
			scanner2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		int[] retval = {memAccesses, pageFaults, writes};
		return retval;
	}
	
	/*
	 * Clock page replacement algorithm.
	 *
	 * @param file: trace file
	 * @param pages: empty array of pages of 2^19 length, to be filled in
	 * @param numFrames: desired number of frames in RAM
	 */
	public static int[] clock(File file, Page[] pages, int numFrames) {
		Frame[] frames = new Frame[numFrames];
		int memAccesses = 0;			// total memory accesses
		int pageFaults = 0;			// total page faults
		int writes = 0;				// total writes to disk
		int framesInRam = 0;			// number of frames
		int hand = 0;

		fillPages(file, pages);
		try {
			Scanner scanner2 = new Scanner(file);
			while(scanner2.hasNextLine()) {
				String data = scanner2.nextLine();
				if(data.charAt(0) == '=' || data.charAt(0) == '-') continue;
				else if(data.charAt(0) != 'I' && data.charAt(0) != ' ') continue;
				else {
					String[] arrOfData = data.split(" ");
					String instr1 = arrOfData[0];
					String instr2 = arrOfData[1];
					// increment total memory accesses
					memAccesses++;
					if(instr2.equals("M")) memAccesses++;

					String hex = arrOfData[2].split(",")[0];
					int address = (int)Long.parseLong(hex, 16);
					int pageNumber = address >>> 13;

					if(pages[pageNumber].inRam == 1) pages[pageNumber].R = 1;
					if(framesInRam != numFrames) {
						if(pages[pageNumber].inRam == 0) {
							System.out.println("page fault - no eviction");
							pageFaults++;
							frames[framesInRam] = new Frame(pages[pageNumber]);
							framesInRam++;			// increment frame counter
							pages[pageNumber].inRam = 1;	// set the current page to indicate in RAM
						}
					} else if(pages[pageNumber].inRam == 0) {
						// eviction
						pageFaults++;
						while(frames[hand].page.R != 0) {
							frames[hand].page.R = 0;
							hand = (hand+1) % numFrames;
						}
						frames[hand].page.inRam = 0;
						if(frames[hand].page.clean == 1) {
							System.out.println("page fault - evict dirty");
							writes++;
							frames[hand].page.clean = 0;
						} else System.out.println("page fault - evict clean");
						frames[hand].page = pages[pageNumber];
						pages[pageNumber].inRam = 1;
						pages[pageNumber].R = 1;
						hand = (hand+1) % numFrames;
					} else System.out.println("hit");
					if(instr2.equals("S") || instr2.equals("M")) pages[pageNumber].clean = 1;
				}
			}
			scanner2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		int[] retval = {memAccesses, pageFaults, writes};
		return retval;
	}
	
	/*
	 * LRU page replacement algorithm.
	 *
	 * @param file: trace file
	 * @param pages: empty array of pages of length 2^19, to be filled in
	 * @param numFrames: desired number of frames in RAM
	 */
	public static int[] lru(File file, Page[] pages, int numFrames) {
		Frame[] frames = new Frame[numFrames];
		int memAccesses = 0;			// total memory accesses
		int pageFaults = 0;			// total page faults
		int writes = 0;				// total writes to disk
		int framesInRam = 0;			// number of frames
		int line = 1;				// file line counter

		fillPages(file, pages);
		try {
			Scanner scanner2 = new Scanner(file);
			while(scanner2.hasNextLine()) {
				String data = scanner2.nextLine();
				if(data.charAt(0) == '=' || data.charAt(0) == '-') continue;
				else if(data.charAt(0) != 'I' && data.charAt(0) != ' ') {
					line++;
					continue;
				} else {
					String[] arrOfData = data.split(" ");
					String instr1 = arrOfData[0];
					String instr2 = arrOfData[1];
					// increment total memory accesses
					memAccesses++;
					// modify has an additional memory access
					if(instr2.equals("M")) memAccesses++;

					String hex = arrOfData[2].split(",")[0];
					int address = (int)Long.parseLong(hex, 16);
					int pageNumber = address >>> 13;
					pages[pageNumber].refNum++;

					if(framesInRam != numFrames) {
						if(pages[pageNumber].inRam == 0) {
							System.out.println("page fault - no eviction");
							pageFaults++;
							frames[framesInRam] = new Frame(pages[pageNumber]);
							framesInRam++;			// increment frame counter
							pages[pageNumber].inRam = 1;	// set the current page to indicate in RAM
						}
					} else if(pages[pageNumber].inRam == 0) {
						// eviction
						pageFaults++;
						int maxWait = 0;
						Frame max = frames[0];
						for(int i=0; i<numFrames; i++) {
							// Calculate how long since the frame's page was last referenced
							int since = pages[pageNumber].references.get(pages[pageNumber].refNum)-frames[i].page.references.get(frames[i].page.refNum);
							if(since > maxWait) {
								maxWait = since;
								max = frames[i];
							}
						}
						max.page.inRam = 0;
						if(max.page.clean == 1) {
							System.out.println("page fault - evict dirty");
							writes++;
							max.page.clean = 0;
						} else System.out.println("page fault - evict clean");
						max.page = pages[pageNumber];
						pages[pageNumber].inRam = 1;
					} else System.out.println("hit");
					if(instr2.equals("S") || instr2.equals("M")) pages[pageNumber].clean = 1;
				}
			}
			scanner2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		int[] retval = {memAccesses, pageFaults, writes};
		return retval;
	}

	/*
	 * NFU page replacement algorithm.
	 *
	 * @param file: trace file
	 * @param pages: empty array of pages of length 2^19, to be filled in
	 * @param numFrames: desired number of frames
	 */
	public static int[] nfu(File file, Page[] pages, int numFrames) {
		Frame[] frames = new Frame[numFrames];
		int memAccesses = 0;			// total memory accesses
		int pageFaults = 0;			// total page faults
		int writes = 0;				// total writes to disk
		int framesInRam = 0;			// number of frames

		fillPages(file, pages);
		try {
			Scanner scanner2 = new Scanner(file);
			while(scanner2.hasNextLine()) {
				String data = scanner2.nextLine();
				if(data.charAt(0) == '=' || data.charAt(0) == '-') continue;
				else if(data.charAt(0) != 'I' && data.charAt(0) != ' ') continue;
				else {
					String[] arrOfData = data.split(" ");
					String instr1 = arrOfData[0];
					String instr2 = arrOfData[1];
					// increment total memory accesses
					memAccesses++;
					if(instr2.equals("M")) memAccesses++;

					String hex = arrOfData[2].split(",")[0];
					int address = (int)Long.parseLong(hex, 16);
					int pageNumber = address >>> 13;

					pages[pageNumber].uses++;
					if(framesInRam != numFrames) {
						if(pages[pageNumber].inRam == 0) {
							System.out.println("page fault - no eviction");
							pageFaults++;
							frames[framesInRam] = new Frame(pages[pageNumber]);
							framesInRam++;			// increment frame counter
							pages[pageNumber].inRam = 1;	// set the current page to indicate in RAM
						}
					} else if(pages[pageNumber].inRam == 0) {
						// eviction
						pageFaults++;
						Frame min = frames[0];
						int minSince = min.page.uses;
						for(int i=0; i<numFrames; i++) {
							if(frames[i].page.uses < minSince) {
								minSince = frames[i].page.uses;
								min = frames[i];
							}
						}
						min.page.inRam = 0;
						min.page.uses = 0;
						if(min.page.clean == 1) {
							System.out.println("page fault - evict dirty");
							writes++;
							min.page.clean = 0;
						} else System.out.println("page fault - evict clean");
						min.page = pages[pageNumber];
						pages[pageNumber].inRam = 1;
					} else System.out.println("hit");
					if(instr2.equals("S") || instr2.equals("M")) pages[pageNumber].clean = 1;
				}
			}
			scanner2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		int[] retval = {memAccesses, pageFaults, writes};
		return retval;
	}

	/*
	 * Main function
	 */
	public static void main(String[] args) {
		if(args.length != 5 || !args[0].equals("-n") || !args[2].equals("-a")) {
			System.out.println("usage: ./vmsim.py -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
			System.exit(0);
		}	
		int numFrames = myAtoi(args[1]);
		if(numFrames == -1) {
			System.out.println("nonnumerical input received for number of frames");
			System.out.println("usage: ./vmsim.py -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
			System.exit(0);
		}
		int[] retval = {0, 0, 0};
		Page[] pages = new Page[(int)Math.pow(2,19)];

		File myObj = new File(args[4]);
		if(args[3].equals("opt")) retval = opt(myObj, pages, numFrames);
		else if(args[3].equals("clock")) retval = clock(myObj, pages, numFrames);
		else if(args[3].equals("lru")) retval = lru(myObj, pages, numFrames);
		else if(args[3].equals("nfu")) retval = nfu(myObj, pages, numFrames);
		else {
			System.out.println("invalid algorithm received");
			System.out.println("usage: ./vmsim.py -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
			System.exit(0);
		}

		System.out.print("Algorithm: ");
		System.out.println(args[3]);
		System.out.print("Number of frames: ");
		System.out.println(numFrames);
		System.out.print("Total memory accesses: ");
		System.out.println(retval[0]);
		System.out.print("Total page faults: ");
		System.out.println(retval[1]);
		System.out.print("Total writes to disk: ");
		System.out.println(retval[2]);
		System.out.print("Total size of page table: ");
		int size = (int)Math.pow(2,19)*4;
		System.out.print(size);
		System.out.println(" bytes");
	}
}
