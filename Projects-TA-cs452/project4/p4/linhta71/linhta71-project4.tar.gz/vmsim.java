/**
	Author: Linh My Ta
	Project 4: vmsim
	Purpose: this project will simulate the vm to handle if there is page
	fault and eviction
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class vmsim {
    private static List<Character> commandType = Arrays.asList('I', 'M', 'S', 'L');
	// page size is 8kb per page
	private static int PAGE_SIZE = 8192;
	private static int TABLE_SIZE = 1 << 19; // 2^32 / 2^13 = 2^19
	private static int PAGE_ENTRY_SIZE = 4;
	private static int memAccess = 0;
	private static int pageFault = 0;
	private static int writeToDisk = 0;
	// stuff needed to run multiple algorithm
    private static Scanner scanner;
    private static long[] timeTable; // for lru, used to store timestamp
    private static long[] count;  // for nfu use, used to store count
    private static HashMap<Entry, Integer> indexMap; // for lru and nfu to keep track of entry to index to ram
    private static int oldestIndex; //for clock, this is the clock hand
	private static HashMap<Integer, TreeSet<Integer>> pageMap; // for opt
	private static ArrayList<Object[]> pageList; //for opt
	private static long curTime; 	// count timestamp for lru
	private static int commandNum;

    public static void main(String[] args) {
		//check the quality of arguments	
		if (args.length != 5 || !args[0].equals("-n") || !args[2].equals("-a")) {
			System.out.println(Arrays.toString(args));
			System.out.println("vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
			System.exit(1);
		}
		int numFrames = Integer.parseInt(args[1]);
		String algo = args[3];
		try {
			scanner = new Scanner(new File(args[4]));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		//initialize ram and table of all pages
		Entry[] pageTable = new Entry[TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; i++) {
			pageTable[i] = new Entry();
		}
		
		int[] ram = new int[numFrames];
		execute(algo, pageTable, ram, numFrames);
		//display the result
		System.out.println("Algorithm: " + algo);
		System.out.println("Number of frames:	"+numFrames);
		System.out.println("Total memory accesses:	"+memAccess);
		System.out.println("Total page faults:	"+pageFault);
		System.out.println("Total writes to disk:	"+writeToDisk);
		System.out.println("Total size of page table:	"+TABLE_SIZE * PAGE_ENTRY_SIZE + " bytes");
	}

	/**
		execute(algo, pageTable, ram, numFrames) will read in the file and
		execute everything, all depends on the algorithm passed in. it will
		handle page faults, memory access, evictions according to the algorithm,
		ram and number of frames
	 */
    private static void execute(String algo, Entry[] pageTable, int[] ram, int numFrames) {
        int pageCount = 0;
		curTime = 0;
		// initialize data structure according to the algorithm
		// since opt requires us to read everything first, we will call it separately
		if (algo.equals("opt")) {
			opt(pageTable, ram, numFrames);
			return;
		} else if (algo.equals("clock")) {
			oldestIndex = 0;
		} else if (algo.equals("lru")) {
			timeTable = new long[ram.length];
			indexMap = new HashMap<Entry, Integer>();
		} else if (algo.equals("nfu")) {
			indexMap = new HashMap<Entry, Integer>();
			count = new long[ram.length];
		}
		// read the entire file, and execute instruction
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine().trim();
			if (line.length() == 0 || !(commandType.contains(line.charAt(0)))) {
				continue;
			}
			String[] command = line.split("\\s+|,");
			System.out.print(line);
			String operation = command[0];
			long address = Long.parseLong(command[1], 16);
			int tableIndex = (int) (address / PAGE_SIZE);
			Entry entry = pageTable[tableIndex];
			if (entry.valid) {
				// if an entry is already in ram
				System.out.println(" (hit)");
				entry.ref = true;
				if (algo.equals("lru")) timeTable[indexMap.get(entry)] = curTime;
				else if (algo.equals("nfu")) count[indexMap.get(entry)]++;
			} else {
				// if it is not in ram
				if (pageCount >= numFrames) {
					// ram is full
					if (algo.equals("clock")) {
						evictClock(ram, pageTable, tableIndex);
					} else if (algo.equals("lru")) {
						evictLRU(ram, pageTable, tableIndex);
					} else if (algo.equals("nfu")) {
						evictNFU(ram, pageTable, tableIndex);
					}
				} else {
					// ram is not full yet
					initialPageFault(ram, pageTable, tableIndex, pageCount);
					if (algo.equals("lru") || algo.equals("nfu")) {
						indexMap.put(pageTable[tableIndex], pageCount);
						if (algo.equals("lru")) timeTable[pageCount] = curTime;
						else count[pageCount]++;
					}
					pageCount++;
				}
				// since page is not found, it is a page fault
				pageFault++;
				curTime++;
			}
			// instruction will do things to memory
			accessMemory(entry, operation);
		}
		scanner.close();
    }

	/**
		initialPageFault(ram, pageTable, tableIndex, pageCount) will execute what
		happend when there is page fault before the ram is full, it will just add
		the entry to ram, no eviction
	*/
	private static void initialPageFault(int[] ram, Entry[] pageTable, int tableIndex, int pageCount) {
		Entry entry = pageTable[tableIndex];
		System.out.println(" (page fault - no eviction)");
		entry.valid = true;
		entry.frame = pageCount;
		ram[pageCount] = tableIndex;
	}

	/**
		evictClock(ram, pageTable, tableIndex) will execute the eviction of the
		entry in ram to make place for a new entry by evicting using clock algorithm
	*/
	private static void evictClock(int[] ram, Entry[] pageTable, int tableIndex) {
		Entry entry = pageTable[tableIndex];
		int indexEvict = ram[oldestIndex];
		Entry entryEvict = pageTable[indexEvict];
		while (entryEvict.ref) {
			entryEvict.ref = false;
			oldestIndex++;
			if (oldestIndex >= ram.length) {
				oldestIndex = 0;
			}
			indexEvict = ram[oldestIndex];
			entryEvict = pageTable[indexEvict];
		}
		entry.frame = entryEvict.frame;
		entry.valid = true;
		if (entryEvict.dirty) {
			writeToDisk++;
			System.out.println(" (page fault - evict dirty)");
		} else {
			System.out.println(" (page fault - evict clean)");
		}
		entryEvict.evict();
		ram[oldestIndex] = tableIndex;
		oldestIndex = (oldestIndex + 1) % ram.length;
	}

	/**
		evictClock(ram, pageTable, tableIndex) will execute the eviction of the
		entry in ram to make place for a new entry by evicting using LRU algorithm.
		It will make use of an array same size of Ram for saving the timestamp,
		and a hashmap to map the entry to the index in ram
	*/
	private static void evictLRU(int[] ram, Entry[] pageTable, int tableIndex) {
		Entry entry = pageTable[tableIndex];
		int toEvict = 0;
		for (int i = 0 ; i < timeTable.length; i++) {
			if (timeTable[i] <= timeTable[toEvict]) {
				toEvict = i;
			}
		}
		int evictIndex = ram[toEvict];
		Entry entryEvict = pageTable[evictIndex];
		entry.frame = entryEvict.frame;
		entry.valid = true;
		if (entryEvict.dirty) {
			writeToDisk++;
			System.out.println(" (page fault - evict dirty)");
		} else {
			System.out.println(" (page fault - evict clean)");
		}
		entryEvict.evict();
		indexMap.put(pageTable[tableIndex], toEvict);
		ram[toEvict] = tableIndex;
		timeTable[toEvict] = curTime;
	}

	/**
		evictClock(ram, pageTable, tableIndex) will execute the eviction of the
		entry in ram to make place for a new entry by evicting using NFU algorithm.
		It will make use of an array same size of Ram for counting how frequently
		a slot is used and a hashmap to map the entry to the index in ram
	*/
	private static void evictNFU(int[] ram, Entry[] pageTable, int tableIndex) {
		Entry entry = pageTable[tableIndex];
		int toEvict = 0;
		for (int i = 0; i < count.length; i++) {
			if (count[i] < count[toEvict]) {
				toEvict = i;
			}
		}
		int evictIndex = ram[toEvict];
		Entry entryEvict = pageTable[evictIndex];
		entry.frame = entryEvict.frame;
		entry.valid = true;
		if (entryEvict.dirty) {
			writeToDisk++;
			System.out.println(" (page fault - evict dirty)");
		} else {
			System.out.println(" (page fault - evict clean)");
		}
		entryEvict.evict();
		indexMap.put(pageTable[tableIndex], toEvict);
		ram[toEvict] = tableIndex;
		count[toEvict] = 0;
	}

	/**
		opt(pageTable, ram, numFrames) perform evictions using opt algorithm. 
		Since we will pretend that we know what will happen in the future, 
		we will read the file in first before executing all instruction
	 */
	private static void opt(Entry[] pageTable, int[] ram, int numFrames) {
		int pageCount = 0;
		int oldestIndex = 0;
		pageMap = new HashMap<Integer, TreeSet<Integer>>();
		pageList = new ArrayList<Object[]>();
		optRead(ram, pageTable);
		commandNum = 1;
		for (Object[] step : pageList) {
			int tableIndex = (int) step[0];
			String operation = (String) step[1];
			String line = (String) step[2];
			Entry entry = pageTable[tableIndex];
			if (entry.valid) {
				System.out.println(line + " (hit)");
				entry.ref = true;
			} else {
				if (pageCount >= numFrames) {
					System.out.print(line);
					optEvict(ram, pageTable, tableIndex);
				} else {
					System.out.print(line);
					initialPageFault(ram, pageTable, tableIndex, pageCount);
					pageCount++;
				}
				pageFault++;
			}
			accessMemory(entry, operation);
			commandNum++;
		}
	}

	/**
		optEvict(ram, pageTable, tableIndex) will evict an entry
		by the longest time an entry will be used in the future.
	 */
	private static void optEvict(int[] ram, Entry[] pageTable, int tableIndex) {
		int furthestPage = -1;
		int maximum = -1;
		Entry entry = pageTable[tableIndex];
		// loop through all page in ram to determine which one will be
		// used furthes in the future
		for (int page : ram) {
			int occurNext;
			if (pageMap.get(page).isEmpty()) {
				occurNext = -1;
				break;
			} else {
				occurNext = pageMap.get(page).first();
				while (occurNext <= commandNum) {
					pageMap.get(page).remove(occurNext);
					if (pageMap.get(page).isEmpty()) {
						occurNext = -1;
						break;
					} else {
						occurNext = pageMap.get(page).first();
					}
				}
			}
			if (occurNext == -1) {
				furthestPage = page;
				break;
			}
			if (occurNext > maximum) {
				furthestPage = page;
				maximum = occurNext;
			}
		}
		// evict the chosen entry
		Entry entryEvict;
		if (furthestPage == -1) {
			entryEvict = pageTable[ram[0]];
		} else {
			entryEvict = pageTable[furthestPage];
		}
		entry.frame = entryEvict.frame;
		entry.valid = true;
		if (entryEvict.dirty) {
			writeToDisk++;
			System.out.println(" (page fault - evict dirty)");
		} else {
			System.out.println(" (page fault - evict clean)");
		}
		entryEvict.evict();
		ram[entry.frame] = tableIndex;
	}

	/**
		optRead(ram, pageTable, tableIndex) will read all the instruction
		and return so that the opt algorithm can be run
	 */
	private static void optRead(int[] ram, Entry[] pageTable) {
		commandNum = 1;
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine().trim();
			if (line.length() == 0 || !(commandType.contains(line.charAt(0)))) {
				continue;
			}
			String[] command = line.split("\\s+|,");
			String operation = command[0];
			long address = Long.parseLong(command[1], 16);
			int tableIndex = (int) (address / PAGE_SIZE);
			if (pageMap.get(tableIndex) == null) {
				pageMap.put(tableIndex, new TreeSet<Integer>());
			}
			pageMap.get(tableIndex).add(commandNum);
			pageList.add(new Object[] { tableIndex, operation, line });
			commandNum++;
		}
		scanner.close();
	}

	/**
		accessMemory will look at an operation to determine if an entry
		become dirty, and how many memoryaccess and operation can increase
	 */
	private static void accessMemory(Entry entry, String operation) {
		memAccess++;
		if (operation.equals("M")) {
			entry.dirty = true;
			memAccess ++;
		} else { 
			if (operation.equals("S")) {
				entry.dirty = true;
			}
		}
	}

	// this class will represent the entry in the page table
	static class Entry {
		boolean dirty;
		boolean valid;
		boolean ref;
		int frame;

		public Entry() {
			this.dirty = false;
			this.valid = false;
			this.ref = true;
			this.frame = -1;
		}

		public void evict() {
			this.dirty = false;
			this.valid = false;
			this.ref = true;
			this.frame = -1;
		}
	}
}