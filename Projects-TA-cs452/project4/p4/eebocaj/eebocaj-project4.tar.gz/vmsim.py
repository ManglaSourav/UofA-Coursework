"""
    File:
    Author: Jacob Edwards
    Class: CSC 452
    
    Simulates various page replacement algorithms
    Usage: vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>
"""

import sys
import time
import tracelib
from tracelib import VMSim as vm


def invalidUsage():
    print("Invalid Usage.")
    exit(1)

if len(sys.argv) != 6 or sys.argv[1] != "-n" or not sys.argv[2].isnumeric() \
    or sys.argv[3] != "-a" or sys.argv[4].lower() not in ["opt", "clock", "lru", "nfu"]:
    invalidUsage()


start = time.time()
response = tracelib.generateParseableStackTrace(sys.argv[5])

if (response["success"]):
    if sys.argv[4] == "clock":
        result = vm.clock(response["result"], int(sys.argv[2]))
    elif sys.argv[4] == "lru":
        result = vm.lru(response["result"], int(sys.argv[2]))
    elif sys.argv[4] == "nfu":
        result = vm.nfu(response["result"], int(sys.argv[2]))
    elif sys.argv[4] == "opt":
        result = vm.opt(response["result"], int(sys.argv[2]))
    
    end = time.time()

    # by only having one print, we can speed the process up significantly by reducing the
    # number of context switches the OS needs to make (40x faster when tested)
    print("\n".join(result.actions))  # takes 5.2 sec
    # [print(action) for action in res.actions]   # takes 2.5 min

    print()
    print(str(result))
    # print(end - start)
else:
    print("File not found.")
    exit(1)
