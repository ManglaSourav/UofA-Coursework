"""
    File:
    Author: Jacob Edwards
    Class: CSC 452
    
    Contains methods and classes for mapping virtual to physical memory.
"""

from inspect import stack
from typing import Dict, List


VIRTUAL_ADDRESS_SIZE = 32   # 32 bit operating system
PAGE_SIZE = 18              # 8 kb page size


class PageTableEntry:
    def __init__(self, addressRange=[]) -> None:
        self.dirty = False
        self.referenced = False
        self.valid = False
        self.pageFrameNumber = 0
        self.addressRange = addressRange
        self.timestamp = 0
        self.referencedCount = 0

    def __hash__(self) -> int:
        return hash(self.addressRange[0])

    def __repr__(self) -> str:
        return f"[{hex(self.addressRange[0]).rjust(10, '0')}-{hex(self.addressRange[1]).rjust(10, '0')}] {int(self.dirty)} {int(self.referenced)} {int(self.valid)} {self.pageFrameNumber}"

    def activate(self, pageFrameNumber=None) -> None:
        """
            Signifies that a page has been loaded into a frame, specified by pageFrameNumber
            This function should be called anytime a page is queried or modified in any way, and
            lets the page replacement algorithm know that this frame has been used recently.
        """
        self.referenced = True
        self.valid = True
        self.pageFrameNumber = pageFrameNumber if pageFrameNumber else self.pageFrameNumber

    def deactivate(self) -> None:
        """
            Resets all modifiable information about a page table entry.
            This function should be called anytime a page is removed from its frame
        """
        self.referenced = False
        self.valid = False
        self.dirty = False
        self.pageFrameNumber = 0
        self.timestamp = 0
        self.referencedCount = 0


class PageTable:
    def __init__(self, numFrames: int) -> None:
        self.numFrames: int = numFrames
        self.numPages: int = 2 ** (VIRTUAL_ADDRESS_SIZE - PAGE_SIZE)
        self.table: List[PageTableEntry] = [PageTableEntry(addressRange=[i * 2 ** PAGE_SIZE, (i + 1) * 2 ** PAGE_SIZE - 1])
                                            for i in range(self.numPages)]

    def __repr__(self) -> str:
        return "\n".join([repr(pte) for pte in self.table])

    def getPageTableEntry(self, address: int) -> Dict:
        """
            Returns the associated page table entry associated with this address
        """
        if address >= 2 ** VIRTUAL_ADDRESS_SIZE:
            return None
        return self.table[address // (2 ** PAGE_SIZE)]

    def isVirtualAddressValid(self, address: int) -> bool:
        """
            Determines if the page associated with this address is currently loaded into physical
            memory
        """
        pte: PageTableEntry = self.getPageTableEntry(address)
        if (pte):
            return pte.valid
        return False


class PhysicalMemory:
    def __init__(self, numFrames: int) -> None:
        self.pageTable: PageTable = PageTable(numFrames)
        self.numFrames: int = numFrames
        self.activeFrames: List[PageTableEntry] = []

    def allPagesInUse(self) -> bool:
        return len(self.activeFrames) == self.numFrames

    def findFrameLastReferenced(self) -> int:
        return min(self.activeFrames, key=lambda pte: pte.timestamp).pageFrameNumber

    def findFrameLeastUsed(self) -> int:
        return min(self.activeFrames, key=lambda pte: pte.referencedCount).pageFrameNumber

    def findFrameFurthestAwayFromUse(self, stackTrace, usage, instructionNo) -> int:
        # prune the usage data so that it only contains events in the future
        for frame in self.activeFrames:
            pageUsage = usage[frame]
            while pageUsage and pageUsage[0] < instructionNo:
                pageUsage.pop(0)
            
        # empty entries in usage mean that those pages will never request memory again, meaning
        # they should higher priority than anything for removal
        return max(self.activeFrames, 
                   key=lambda pte: usage[pte][0] if usage[pte] else len(stackTrace) + 1).pageFrameNumber