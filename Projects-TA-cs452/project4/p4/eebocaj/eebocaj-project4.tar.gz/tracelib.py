"""
    File:
    Author: Jacob Edwards
    Class: CSC 452
    
    Contains methods and classes for interacting with a stack trace
"""

from inspect import stack
from time import time
from hashlib import new
from typing import Dict, List
import memory


class Instruction:
    def __init__(self, type: str, raw_address: str, size: int) -> None:
        self.type: str = type
        self.raw_address: str = raw_address
        self.address: int = int(raw_address, 16)
        self.size: int = size

    def __repr__(self) -> str:
        out = "{\n"
        out += f"\ttype: {self.type}\n"
        out += f"\traw address: {self.raw_address}\n"
        out += f"\taddress: {self.address}\n"
        out += f"\tsize: {self.size}\n"
        out += "}"

        return out


class Summary:
    def __init__(self, algoName, frameCount):
        self.algoName = algoName
        self.frameCount = frameCount
        self.memoryAccessCount = 0
        self.pageFaultCount = 0
        self.diskWriteCount = 0
        self.actions = []
        self.pageTableSize = 0

    def __str__(self) -> str:
        return (
            f"Algorithm: {self.algoName}\n"
            + f"Number of frames:\t{self.frameCount}\n"
            + f"Total memory accesses:\t{self.memoryAccessCount}\n"
            + f"Total page faults:\t{self.pageFaultCount}\n"
            + f"Total writes to disk:\t{self.diskWriteCount}\n"
            + f"Total size of page table:\t{self.pageTableSize} bytes"
        )


class Clock:
    def __init__(self, cycleVal) -> None:
        self._timer = 0
        self._cycleVal = cycleVal

    def tick(self) -> int:
        self._timer += 1
        if self._timer == self._cycleVal:
            self._timer = 0
        return self._timer

    def value(self) -> int:
        return self._timer


def parseStringTrace(s: str) -> Dict:
    """
        Attempts to convert a line from the tracefile into an Instruction object
    """
    result = {"success": False, "address": "Undefined", "size": 0}
    for prefix in ["I  ", " S ", " L ", " M "]:
        if s.startswith(prefix):
            fetch = s.split()[-1].split(",")
            if len(fetch) == 2 and fetch[0].isalnum() and fetch[1].isnumeric():
                result = {
                    "success": True,
                    "instruction": Instruction(s.strip()[0], fetch[0], int(fetch[1])),
                }
                break
    return result


def generateParseableStackTrace(fname: str) -> Dict:
    """
        Converts the tracefile into a list of Instruction Objects
    """
    try:
        with open(fname) as file:
            contents = file.readlines()
    except FileNotFoundError:
        return {"success": False, "message": "File not found."}

    trace = []
    for line in contents:
        result = parseStringTrace(line)
        if result["success"]:
            trace.append(result["instruction"])

    return {"success": True, "result": trace}

def generateStackUsage(stackTrace: List[Instruction], pageTable: memory.PageTable) -> Dict:
    currentPte = None
    usage = {}
    for instructionNo, instruction in enumerate(stackTrace):
        # get the page table entry associated with this instruction
        nextPte = pageTable.getPageTableEntry(instruction.address)

        # if the assocated pte is not the current pte, this means that this is the start of one or
        # more instructions assicated with this page. we can store a run of instructions that
        # reference the same frame in one piece of information, the instructionNo of the start of
        # the run. during a run, nothing can interrupt us and make us load a new frame, so no info
        # is stored during a run for any page. most stacktraces contain large runs
        if nextPte is not currentPte:
            currentPte = nextPte
            if currentPte not in usage:
                usage[currentPte] = []
            usage[currentPte].append(instructionNo)

    return usage
            




class VMSim:
    @staticmethod
    def opt(stackTrace: List[Instruction], frameCount: int) -> Dict:
        """
        Simulates optimal page replacement
        """
        res = Summary("opt", frameCount)

        # creates our representation of memory, including the page table
        ram: memory.PhysicalMemory = memory.PhysicalMemory(frameCount)

        # creates the usage prediction
        usage = generateStackUsage(stackTrace, ram.pageTable)

        for instructionNo, instruction in enumerate(stackTrace):
            action = "hit"
            # count the number of memory accesses.
            # if the instruction is a modify, there are two memory accesses per instruction
            res.memoryAccessCount += 2 if instruction.type == "M" else 1

            # figure out what frame the address exists in and get it's page table entry
            pte = ram.pageTable.getPageTableEntry(instruction.address)

            # if the resource is already in physical memory, we don't need to cause a page fault
            if pte.valid:
                pte.activate()
            # if the resource is not in physical memory, we need to cause a page fault and change
            # what page a frame is assigned based on second-chance FIFO
            else:
                res.pageFaultCount += 1
                if not ram.allPagesInUse():
                    # if physical memory has available frame, we can just add the virtual address's
                    # page to an avaiable frame. The first cycle around the frames, we should just
                    # fix pte valid, pageFrameNumber, and referenced and add them to active frames.
                    pte: memory.PageTableEntry = ram.pageTable.getPageTableEntry(instruction.address)
                    pte.activate(len(ram.activeFrames))
                    ram.activeFrames.append(pte)
                    action = "page fault - no eviction"
                else:
                    # because physical memory does not have available frame, we need to decide
                    # which one to remove.
                    frameNo = ram.findFrameFurthestAwayFromUse(stackTrace, usage, instructionNo + 1)
                    frameToReplace = ram.activeFrames[frameNo]

                    # if the frame is dirty, we need to write it's contents to the disk before we
                    # can replace it's contents
                    if frameToReplace.dirty:
                        action = "page fault - evict dirty"
                        res.diskWriteCount += 1
                    else:
                        action = "page fault - evict clean"

                    # we need to deactivate frameToRepalce and swap it out for the new page.
                    # frameToReplace exists at frameNo. make sure to activate the new page table
                    # entry after you add it to the active frames
                    frameToReplace.deactivate()
                    ram.activeFrames[frameNo] = pte
                    pte.activate(frameNo)

            # after modifying our page table, we might need to update a specific table entry.
            # if this instruction modifies physical memory (modify, store), we need to set the
            # dirty bit of the pte to 1 so that we know to save the contents to disk before we
            # remove it from physical memory / override it's contents later on
            if instruction.type in "MS":
                pte.dirty = True

            # store the action taken for this instruction for printing later
            res.actions.append(action) 
        
        res.pageTableSize = ram.pageTable.__sizeof__()
        return res


    @staticmethod
    def clock(stackTrace: List[Instruction], frameCount: int) -> Dict:
        """
        Simulates Second Chance page replacement
        """
        res = Summary("clock", frameCount)

        # creates a new clock object that loops from 0 - frameCount. the value of count will always
        # be the index of the oldest element in our list of active frames (or the next empty frame,
        # until all frames are allocated)
        clock = Clock(frameCount)

        # creates our representation of memory, including the page table
        ram: memory.PhysicalMemory = memory.PhysicalMemory(frameCount)

        for instruction in stackTrace:
            action = "hit"
            # count the number of memory accesses.
            # if the instruction is a modify, there are two memory accesses per instruction
            res.memoryAccessCount += 2 if instruction.type == "M" else 1

            # figure out what frame the address exists in and get it's page table entry
            pte = ram.pageTable.getPageTableEntry(instruction.address)

            # if the resource is already in physical memory, we don't need to cause a page fault
            if pte.valid:
                pte.activate()
            # if the resource is not in physical memory, we need to cause a page fault and change
            # what page a frame is assigned based on second-chance FIFO
            else:
                res.pageFaultCount += 1
                if not ram.allPagesInUse():
                    # if physical memory has available frame, we can just add the virtual address's
                    # page to an avaiable frame. The first cycle around the frames, we should just
                    # fix pte valid, pageFrameNumber, and referenced and add them to active frames.
                    pte: memory.PageTableEntry = ram.pageTable.getPageTableEntry(instruction.address)
                    pte.activate(clock.value())
                    ram.activeFrames.append(pte)
                    action = "page fault - no eviction"
                else:
                    # because physical memory does not have available frame, we need to decide
                    # which one to remove. we should remove the oldest one whose referenced bit is
                    # 0. Because clock points to the oldest element, we can simply move through the clock
                    current = ram.activeFrames[clock.value()]

                    # until we find a frame that was not referenced, set all referenced bits to 0
                    while current.referenced:
                        current.referenced = False
                        current = ram.activeFrames[clock.tick()]

                    # current is now a frame that was not referenced. if current is dirty, we
                    # need to write it's contents to disk
                    if current.dirty:
                        res.diskWriteCount += 1
                        action = "page fault - evict dirty"
                    else:
                        action = "page fault - evict clean"

                    # we need to deactivate current and swap it out for the new page. current
                    # exists at clock.value(). make sure to activate the new page table entry
                    # after you add it to the active frames
                    current.deactivate()
                    ram.activeFrames[clock.value()] = pte
                    pte.activate(clock.value())

                # now that we have allocated a new frame in physical memory, we need to move
                # the clock to the right to point to the new empty slot/new oldest address.
                clock.tick()

            # after modifying our page table, we might need to update a specific table entry.
            # if this instruction modifies physical memory (modify, store), we need to set the
            # dirty bit of the pte to 1 so that we know to save the contents to disk before we
            # remove it from physical memory / override it's contents later on
            if instruction.type in "MS":
                pte.dirty = True

            # print the action taken for this instruction
            res.actions.append(action)

        res.pageTableSize = ram.pageTable.__sizeof__()
        return res

    @staticmethod
    def lru(stackTrace: List[Instruction], frameCount: int) -> Dict:
        """
        Simulates Last Recently Used page replacement
        """
        res = Summary("lru", frameCount)

        # creates our representation of memory, including the page table
        ram: memory.PhysicalMemory = memory.PhysicalMemory(frameCount)

        # create a counter to keep track of what timestamp an address is used at
        timestamp = 0

        for instruction in stackTrace:
            action = "hit"
            # count the number of memory accesses.
            # if the instruction is a modify, there are two memory accesses per instruction
            res.memoryAccessCount += 2 if instruction.type == "M" else 1

            # figure out what frame the address exists in and get it's page table entry
            pte = ram.pageTable.getPageTableEntry(instruction.address)

            # if the resource is already in physical memory, we don't need to cause a page fault
            if pte.valid:
                pte.activate()
            # if the resource is not in physical memory, we need to cause a page fault and change
            # what page a frame is assigned based on second-chance FIFO
            else:
                res.pageFaultCount += 1
                if not ram.allPagesInUse():
                    # if physical memory has available frame, we can just add the virtual address's
                    # page to an avaiable frame. The first cycle around the frames, we should just
                    # fix pte valid, pageFrameNumber, and referenced and add them to active frames.
                    pte: memory.PageTableEntry = ram.pageTable.getPageTableEntry(instruction.address)
                    pte.activate(len(ram.activeFrames))
                    ram.activeFrames.append(pte)
                    action = "page fault - no eviction"
                else:
                    # because physical memory does not have available frame, we need to decide
                    # which one to remove.
                    frameNo = ram.findFrameLastReferenced()
                    frameToReplace = ram.activeFrames[frameNo]

                    # if the frame is dirty, we need to write it's contents to the disk before we
                    # can replace it's contents
                    if frameToReplace.dirty:
                        action = "page fault - evict dirty"
                        res.diskWriteCount += 1
                    else:
                        action = "page fault - evict clean"

                    # we need to deactivate frameToRepalce and swap it out for the new page.
                    # frameToReplace exists at frameNo. make sure to activate the new page table
                    # entry after you add it to the active frames
                    frameToReplace.deactivate()
                    ram.activeFrames[frameNo] = pte
                    pte.activate(frameNo)

            # after modifying our page table, we might need to update a specific table entry.
            # if this instruction modifies physical memory (modify, store), we need to set the
            # dirty bit of the pte to 1 so that we know to save the contents to disk before we
            # remove it from physical memory / override it's contents later on
            if instruction.type in "MS":
                pte.dirty = True

            # set the pte's timestamp to let the page replacement algorithm know that that page
            # was used recently
            pte.timestamp = timestamp

            # store the action taken for this instruction for printing later
            res.actions.append(action)

            timestamp += 1
        
        res.pageTableSize = ram.pageTable.__sizeof__()
        return res

    @staticmethod
    def nfu(stackTrace: List[Instruction], frameCount: int) -> Dict:
        """
        Simulates Least Frequetly Used page replacement
        """
        res = Summary("nfu", frameCount)

        # creates our representation of memory, including the page table
        ram: memory.PhysicalMemory = memory.PhysicalMemory(frameCount)

        # create a counter to keep track of what timestamp an address is used at
        timestamp = 0

        for instruction in stackTrace:
            action = "hit"
            # count the number of memory accesses.
            # if the instruction is a modify, there are two memory accesses per instruction
            res.memoryAccessCount += 2 if instruction.type == "M" else 1

            # figure out what frame the address exists in and get it's page table entry
            pte = ram.pageTable.getPageTableEntry(instruction.address)

            # if the resource is already in physical memory, we don't need to cause a page fault
            if pte.valid:
                pte.activate()
            # if the resource is not in physical memory, we need to cause a page fault and change
            # what page a frame is assigned based on second-chance FIFO
            else:
                res.pageFaultCount += 1
                if not ram.allPagesInUse():
                    # if physical memory has available frame, we can just add the virtual address's
                    # page to an avaiable frame. The first cycle around the frames, we should just
                    # fix pte valid, pageFrameNumber, and referenced and add them to active frames.
                    pte: memory.PageTableEntry = ram.pageTable.getPageTableEntry(instruction.address)
                    pte.activate(len(ram.activeFrames))
                    ram.activeFrames.append(pte)
                    action = "page fault - no eviction"
                else:
                    # because physical memory does not have available frame, we need to decide
                    # which one to remove.
                    frameNo = ram.findFrameLeastUsed()
                    frameToReplace = ram.activeFrames[frameNo]

                    # if the frame is dirty, we need to write it's contents to the disk before we
                    # can replace it's contents
                    if frameToReplace.dirty:
                        action = "page fault - evict dirty"
                        res.diskWriteCount += 1
                    else:
                        action = "page fault - evict clean"

                    # we need to deactivate frameToRepalce and swap it out for the new page.
                    # frameToReplace exists at frameNo. make sure to activate the new page table
                    # entry after you add it to the active frames
                    frameToReplace.deactivate()
                    ram.activeFrames[frameNo] = pte
                    pte.activate(frameNo)

            # after modifying our page table, we might need to update a specific table entry.
            # if this instruction modifies physical memory (modify, store), we need to set the
            # dirty bit of the pte to 1 so that we know to save the contents to disk before we
            # remove it from physical memory / override it's contents later on
            if instruction.type in "MS":
                pte.dirty = True

            # set the pte's referencedCount to let the page replacement algorithm know that the page
            # was referenced while it was loaded
            pte.referencedCount += 1

            # store the action taken for this instruction for printing later
            res.actions.append(action)

            timestamp += 1
        
        res.pageTableSize = ram.pageTable.__sizeof__()
        return res
