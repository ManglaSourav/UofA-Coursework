import java.util.*;
import java.io.File;
import java.io.IOException;

/*
   Orlando Rodriguez
   Project 4
*/

class Entry {
    private boolean dirtyBit;
    private boolean referencedBit;
    private boolean validBit;
    private int pageFrameNumber;

    public Entry() {
	dirtyBit = false;
	referencedBit = false;
	validBit = false;
    }

    public boolean getDirtyBit() {
	return dirtyBit;
    }

    public boolean getReferencedBit() {
	return referencedBit;
    }

    public boolean getValidBit() {
	return validBit;
    }

    public int getPageFrameNumber() {
	return pageFrameNumber;
    }

    public void setDirtyBit(boolean newDirtyBit) {
	dirtyBit = newDirtyBit;
    }

    public void setReferencedBit(boolean newReferencedBit) {
	referencedBit = newReferencedBit;
    }

    public void setValidBit(boolean newValidBit) {
	validBit = newValidBit;
    }

    public void setPageFrameNumber(int newPageFrameNumber) {
	pageFrameNumber = newPageFrameNumber;
    }
}

public class VmSim {
    private static final int PAGE_SIZE = 8192;
    private static ArrayList<Entry> PT;
    private static ArrayList<Integer> RAM;
    private static ArrayList<String> fileLines;
    private static String fileName;
    private static String algorithm;
    private static int numFrames = 0;

    private static int memAccesses = 0;
    private static int pageFaults = 0;
    private static int totalDiskWrite = 0;

    public static void main(String[] args) throws IOException {
	readArguments(args);
	PT = new ArrayList<Entry>();
	RAM = new ArrayList<Integer>();

	setUpRAM();
	setUpPT();

	File file = new File(fileName);
	Scanner reader = new Scanner(file);

	fileLines = new ArrayList<String>();

	// Adds each line into an ArrayList
	while (reader.hasNextLine()) {
	    String data = reader.nextLine();
	    if (!((data.charAt(0) == '=') || (data.charAt(0) == '-')))
		fileLines.add(data);
	}

	// Reading through file
	for (String line : fileLines) {
	    // Splits line into tokens
	    String[] tokens = line.split("[ ,]+");
	    ArrayList<String> tokenList = new ArrayList<String>(Arrays.asList(tokens));
	    tokenList.removeAll(Arrays.asList(""));

	    // Tries to execute instruction
	    System.out.println(line);
	    handle(tokenList.get(0), Integer.parseInt(tokenList.get(1), 16));
	}
    }

    private static void opt() {
	for (int i = fileLines.size(); i >= 0; i--) {
	    String[] tokens = fileLines.get(i).split("[ ,]+");
	    ArrayList<String> tokenList = new ArrayList<String>(Arrays.asList(tokens));
	    tokenList.removeAll(Arrays.asList(""));
	    if ("ILMS".contains(tokenList.get(0))) {
		int VA = Integer.parseInt(tokenList.get(1), 16);
		int pageNum = VA / PAGE_SIZE;
		Entry entry = PT.get(pageNum);
		if (entry.getValidBit()) {
		    if (entry.getDirtyBit()) {
			entry.setDirtyBit(false);
			entry.setValidBit(false);
			RAM.set(entry.getPageFrameNumber(),0);
			System.out.println("page fault - evict dirty");
			return;
		    } else {
			entry.setValidBit(false);
			RAM.set(entry.getPageFrameNumber(),0);
			System.out.println("page fault - evict clean");
			return;
		    }
		}
	    }
	}
    }

    private static void handle(String flag, int VA) {
	// Page# = VA / PageSize
	int pageNum = VA / PAGE_SIZE;
	
	if (!PT.get(pageNum).getValidBit()) {
	    // handle page fault
	    int frameNumber = nextFreeRAM();
	    if (frameNumber != -1) {
		RAM.set(frameNumber, 1);
		PT.get(pageNum).setPageFrameNumber(frameNumber);
		System.out.println("page fault - no eviction");
	    } else {
		if (algorithm.equals("opt"))
		    opt();
		/*
		if (algorithm.equals("clock"))
		    clock();
		if (algorithm.equals("lru"))
		    lru();
		if (algorithm.equals("nfu"))
		    nfu();
		*/
		frameNumber = nextFreeRAM();
		RAM.set(frameNumber, 1);
		PT.get(pageNum).setPageFrameNumber(frameNumber);
	    }
	} else {
	    System.out.println("hit");
	}
 
	// Incrementing stats
	if ("ILS".contains(flag))
	    memAccesses++;
	if (flag.equals("M"))
	    memAccesses += 2;

	// Setting bits
	if ("SM".contains(flag))
	    PT.get(pageNum).setDirtyBit(true);
	if ("ILSM".contains(flag))
	    PT.get(pageNum).setReferencedBit(true);
    }

    private static void readArguments(String[] args) {
	for (int i = 0; i < args.length; i++) {
	    if (args[i].equals("-n"))
		numFrames = Integer.parseInt(args[++i]);
	    if (args[i].equals("-a"))
		algorithm = args[++i];
	    else
		fileName = args[i];
	}
    }

    private static void setUpRAM() {
	for (int i = 0; i < numFrames; i++) 
	    RAM.add(0);
    }

    private static void setUpPT() {
	int numPages = 524288;
	for (int i = 0; i < numPages; i++) 
	    PT.add(new Entry());
    }

    private static int nextFreeRAM() {
	for (int frame : RAM) {
	    if (frame == 0)
		return frame;
	}
	return -1;
    }


}
