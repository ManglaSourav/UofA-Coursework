/**
 * Author: Mark Oakeson
 * Course: CSc 452
 * Assignment: Project 4: Virtual Memory Simulator
 * Instructor: Dr. Misurda
 * Due date: 04/12/22
 *
 * Class for a table entry.
 * Contains frameNumber, index, isValid, referenced, and dirty.
 *
 **/
public class TableEntry {
    private Integer frameNumber; // 0 through Frame number
    private Integer index; // Index in Page table
    private Boolean isValid; // Tells us whether entry is stored in RAM or not
    private Boolean referenced; // Page has been used
    private Boolean dirty; // Has been modified

    public Integer getFrameNumber() {
        return frameNumber;
    }

    public Integer getIndex() {
        return index;
    }

    public Boolean getValid() {
        return isValid;
    }

    public Boolean getReferenced() {
        return referenced;
    }

    public Boolean getDirty() {
        return dirty;
    }

    public void setFrameNumber(Integer frameNumber) {
        this.frameNumber = frameNumber;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public void setValid(Boolean valid) {
        isValid = valid;
    }

    public void setReferenced(Boolean referenced) {
        this.referenced = referenced;
    }

    public void setDirty(Boolean dirty) {
        this.dirty = dirty;
    }

    public TableEntry(Integer index){
        this.frameNumber = -1;
        this.index = index;
        this.isValid = false;
        this.referenced = false;
        this.dirty = false;
    }
}
