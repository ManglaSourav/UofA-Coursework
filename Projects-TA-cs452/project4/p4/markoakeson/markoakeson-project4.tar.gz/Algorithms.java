/**
 * Author: Mark Oakeson
 * Course: CSc 452
 * Assignment: Project 4: Virtual Memory Simulator
 * Instructor: Dr. Misurda
 * Due date: 04/12/22
 *
 * The purpose of this program is to simulate memory from a given
 * trace file, and the program will count the number of page faults, memory accesses, and
 * writes to disk for the user input number of frames to have in RAM (8, 16, 32, 64) with a given
 * Virtual address space of 32-bit.
 * THe implemented algorithms (opt, clock, LRU, and NFU) all simulate the page replacement
 * algorithms for memory, and collect the statistics to print to console.
 *
 **/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Algorithms {
    private TableEntry[] table = createTable();
    private Integer framesInRAM = 0; // Track the current number of entries in RAM
    private Integer memAccess = 0; // Track number of accesses into memory
    private Integer pageFaults = 0; // Track number of page faults
    private Integer writes = 0; // Track when the evicted page is written to disk
    private TableEntry[] RAM;
    public final Integer PAGESIZE = (int) Math.pow(2,13); // Size of Page, 8KB
    public final Integer PAGETABLESIZE = (int) Math.pow(2,21); //Table size * 4 bytes for int

    public Algorithms(Integer numFrames){
        this.RAM = new TableEntry[numFrames];
    } // Init RAM to be an array with numFrames of frames

    /**
     * Method creates the Page Table for pages of size 8KB
     * @return A TableEntry array to act as the PAge Table
     */
    public TableEntry[] createTable(){
        Integer tableSize = (int) Math.pow(2,19); //2^32 - 2^13
        TableEntry[] tableEntries = new TableEntry[tableSize];
        for(int i = 0; i < tableSize; i++){
            TableEntry entry = new TableEntry(i); //Insert table entry into each index for Pagetable
            tableEntries[i] = entry;
        }
        return tableEntries;
    }

    /**
     * Method simulates the Least Recently Used Page REplacement Algorithm and tracks statistics to print to console.
     * Uses a timestamp method, by using HashMap with mappings of Key: Pageframe, Value: time of last use to
     * track pages in RAM and which to evict
     *
     * @param inputFile A file that is the unziped file of the memory trace
     */
    public void lru(File inputFile){
        Scanner scanner = null;
        try {
            scanner = new Scanner(inputFile);
        } catch (FileNotFoundException e){
            e.printStackTrace();
            System.exit(-1);
        }

        String algo = "LRU";
        HashMap<Integer, Integer> lastUse = new HashMap<>(); // Key: PageFrame, Value: time of last use

        try {
            scanner = new Scanner(inputFile);
        } catch (FileNotFoundException e){
            e.printStackTrace();
            System.exit(-1);
        }
        String action = null;

        while(scanner.hasNextLine()){ // Simulate Memory
            String lineString = scanner.nextLine();
            String op;
            String[] line = lineString.split(" ");
            if(line[0].length()<=1) { // Check if line is valid MEmory access and not just a comment
                memAccess++;

                String[] VA = line[2].split(",");
                Long address = Long.decode("0x" + VA[0]);
                int pageNumber = (int) (address / PAGESIZE); //Calculate page NUmber
                if (pageNumber < 0 || pageNumber > table.length) {
                    action = "page fault – no eviction"; // Accessing array out of bounds
                    pageFaults++;
                }
                op = line[1];
                if(op.equals("M")){
                    memAccess++; // Increment since operation M does both a load and a store
                }

                if (table[pageNumber].getValid()) { // Table entry is in RAM
                    if (op.equals("M") || op.equals("S")) { // Should handle the load/store op of M and S
                        RAM[table[pageNumber].getFrameNumber()].setDirty(true); // Write, so set table entry as dirty
                    }
                    lastUse.put(table[pageNumber].getFrameNumber(), memAccess); //Update time
                    action = "hit";
                } else {
                    if (framesInRAM < RAM.length) { // There is memory in RAM to use
                        pageFaults++;
                        if (op.equals("M") || op.equals("S")) { // operation writes, so set to dirty
                            table[pageNumber].setDirty(true);
                        }
                        table[pageNumber].setValid(true);
                        table[pageNumber].setReferenced(true);
                        table[pageNumber].setFrameNumber(framesInRAM);
                        RAM[framesInRAM] = table[pageNumber];
                        lastUse.put(framesInRAM, memAccess); //Update time
                        action = "page fault – no eviction";
                        framesInRAM++;
                    }
                    else { // No more room in RAM, Kick Frame out
                            pageFaults++;
                            Integer toEvict = null;

                            for (int i = 0; i < RAM.length; i++) {
                                if (toEvict == null || lastUse.get(i) < lastUse.get(toEvict)) {
                                    toEvict = i;
                                }
                            }
                            lastUse.put(toEvict, memAccess);
                            if (RAM[toEvict].getDirty()) {
                                writes++;
                                action = "page fault – evict dirty";
                            } else {
                                action = "page fault – evict clean";
                            }
                            replacePage(toEvict, pageNumber, op);
                        }
                }
                    System.out.println("Action: " + action);
            }
        }
        printAlgoStats(algo, RAM.length, memAccess, pageFaults, writes);
    }

    /**
     * Method implements the clock algorithm for page replacement with the better implementation
     * where it uses a 'circular' array (tracked with the oldestTime index) pointer to track the oldest
     * inserted page in RAM
     * @param inputFile A file that is the unziped file of the memory trace
     */
    public  void clock(File inputFile){
        Scanner scanner = null;
        try {
            scanner = new Scanner(inputFile);
        } catch (FileNotFoundException e){
            e.printStackTrace();
            System.exit(-1);
        }
        String algo = "CLOCK";
        Integer oldestPage = 0; // Index to keep track of oldest entry in the RAM

        String action = null;
        while (scanner.hasNextLine()) { // Simulate Memory
            String lineString = scanner.nextLine();
            String op;
            String[] line = lineString.split(" ");

            if (line[0].length()<=1) {// Check if line is valid MEmory access and not just a comment
                memAccess++;
                op = line[1];
                if (op.equals("M")) {// Increment since operation M does both a load and a store
                    memAccess++;
                }

                String[] VA = line[2].split(",");
                Long address = Long.decode("0x" + VA[0]);
                int pageNumber = (int) (address / PAGESIZE); // Calculate Page number

                if (pageNumber < 0 || pageNumber > table.length) {
                    action = "page fault – no eviction"; // Accessing array out of bounds
                    pageFaults++;
                } else if (table[pageNumber].getValid()) { // Table entry is in RAM
                    if (op.equals("M") || op.equals("S")) { // Should handle the load/store op of M and S
                        RAM[table[pageNumber].getFrameNumber()].setDirty(true); // OP is S, so set table entry as dirty
                    }
                    RAM[table[pageNumber].getFrameNumber()].setReferenced(true); // Revert referenced back to true for pages that may have been 'evicted'
                    action = "hit";
                } else {
                    if (framesInRAM < RAM.length) { // There is memory in RAM to use
                        pageFaults++;
                        if (op.equals("M") || op.equals("S")) { //Set dirty bit to 1 since we are writing
                            table[pageNumber].setDirty(true);
                        }
                        table[pageNumber].setReferenced(true);
                        table[pageNumber].setValid(true);
                        table[pageNumber].setFrameNumber(framesInRAM);
                        RAM[framesInRAM] = table[pageNumber];
                        action = "page fault – no eviction";
                        framesInRAM++;
                    } else { // No more room in RAM, Kick Frame out
                        pageFaults++;
                        Integer toEvict = -1;

                        while(toEvict == -1) {
                            if(RAM[oldestPage].getReferenced()){ // If page referenced, set to unreferenced but keep in RAM
                                RAM[oldestPage].setReferenced(false);
                            }
                            else{
                                toEvict = oldestPage; // Page not referenced, so evict
                                break;
                            }
                            oldestPage++;
                            if(oldestPage >= RAM.length){
                                oldestPage = 0;
                            }
                        }
                        if (RAM[toEvict].getDirty()) {
                            writes++;
                            action = "page fault – evict dirty";
                        } else {
                            action = "page fault – evict clean";
                        }

                        //Retrieve dirty frame to Remove and clean
                        replacePage(toEvict, pageNumber, op);
                        oldestPage++;
                        if(oldestPage >= RAM.length){
                            oldestPage = 0;
                        }
                    }
                }
                System.out.println("Action: " + action);//todo
            }
        }
        printAlgoStats(algo, RAM.length, memAccess, pageFaults, writes);
    }

    /**
     * Method implements the NFU algorithm for page replacement with a Hashmap
     * that tracks the frame number and frequency (number of times frame referenced while in RAM)
     *
     * @param inputFile A file that is the unziped file of the memory trace
     */
    public void nfu(File inputFile) {
        Scanner scanner = null;

        try {
            scanner = new Scanner(inputFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(-1);
        }
        String algo = "NFU";
        HashMap<Integer, Integer> frequency = new HashMap<Integer, Integer>(); // Key: frame number, Value: frequency of use
        String action = null;
        int count = 0;
        while (scanner.hasNextLine()) { // Simulate Memory
            String lineString = scanner.nextLine();
            String op;
            String[] line = lineString.split(" ");
            if (line[0].length()<=1) {// Check if line is valid MEmory access and not just a comment
                memAccess++;
                op = line[1];
                if (op.equals("M")) {// Increment since operation M does both a load and a store
                    memAccess++;
                }

                String[] VA = line[2].split(",");
                Long address = Long.decode("0x" + VA[0]);
                int pageNumber = (int) (address / PAGESIZE);

                if (pageNumber < 0 || pageNumber > table.length) {
                    action = "page fault – no eviction"; // Accessing array out of bounds
                    pageFaults++;
                } else if (table[pageNumber].getValid()) { // Table entry is in RAM
                    if (op.equals("M") || op.equals("S")) { // Should handle the load/store op of M and S
                        RAM[table[pageNumber].getFrameNumber()].setDirty(true); // OP is S, so set table entry as dirty
                    }
                    int curFrequency = frequency.get(table[pageNumber].getFrameNumber());
                    curFrequency++;
                    frequency.put(table[pageNumber].getFrameNumber(), curFrequency);
                    action = "hit";
                } else {
                    if (framesInRAM < RAM.length) { // There is memory in RAM to use
                        pageFaults++;
                        frequency.put(framesInRAM, 1);
                        if (op.equals("M") || op.equals("S")) { // Written to, so set dirty
                            table[pageNumber].setDirty(true);
                        }
                        table[pageNumber].setValid(true);
                        table[pageNumber].setReferenced(true);
                        table[pageNumber].setFrameNumber(framesInRAM);
                        RAM[framesInRAM] = table[pageNumber];
                        action = "page fault – no eviction";
                        framesInRAM++;
                    } else { // No more room in RAM, Kick Frame out

                            pageFaults++;
                            Integer toEvict = null;

                            for (int i = 0; i < RAM.length; i++) {
                                if (toEvict == null || frequency.get(i) < frequency.get(toEvict)) {
                                    // Track the lowest used entry to evict
                                    toEvict = i;
                                }
                            }
                            frequency.put(toEvict, 1);
                            if (RAM[toEvict].getDirty()) {
                                writes++;
                                action = "page fault – evict dirty";
                            } else {
                                action = "page fault – evict clean";
                            }

                            //Retrieve dirty frame to Remove and clean
                            replacePage(toEvict, pageNumber, op);
                    }
                }
            }
                    System.out.println("Action: " + action);
        }
        printAlgoStats(algo, RAM.length, memAccess, pageFaults, writes);
    }

    /**
     *Method implements the optimal algorithm for page replacement by
     * initializing an ArrayList of LinkedLists that track at what instruction number
     * each memory address is referenced in order to evict the page furthest in the future
     * @param inputFile A file that is the unziped file of the memory trace
     */
    public void optimal(File inputFile)  {
        Scanner scanner = null;
        try {
            scanner = new Scanner(inputFile);
        } catch (FileNotFoundException e){
            e.printStackTrace();
            System.exit(-1);
        }
        String algo = "Optimal";
        ArrayList<LinkedList<Integer>> futureUse = new ArrayList<LinkedList<Integer>>();
        for(int i = 0; i < (int) Math.pow(2,19); i++){
            futureUse.add(i, new LinkedList<>());
        }

        int instrNum = 0;
        while(scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] lineArray = line.split(" ");
            if (lineArray[0].length() <= 1) {
                String[] VA = lineArray[2].split(",");
                Long address = Long.decode("0x" + VA[0]);
                int index = (int) (address / PAGESIZE);
                futureUse.get(index).add(instrNum);
                instrNum++;
            }
        }

        try {
            scanner = new Scanner(inputFile);
        } catch (FileNotFoundException e){
            e.printStackTrace();
            System.exit(-1);
        }
        String action = null;
        while(scanner.hasNextLine()){ // Simulate Memory
            String lineString = scanner.nextLine();
            String op;
            String[] line = lineString.split(" ");

            if(line[0].length()<=1) {// Check if line is valid MEmory access and not just a comment
                memAccess++;
                String[] VA = line[2].split(",");
                Long address = Long.decode("0x" + VA[0]);
                int pageNumber = (int) (address / PAGESIZE);
                if (pageNumber < 0 || pageNumber > table.length) {
                    action = "page fault – no eviction"; // Accessing array out of bounds
                    pageFaults++;
                }
                op = line[1];
                if(op.equals("M")){ // Increment since operation M does both a load and a store
                    memAccess++;
                }

                 if (table[pageNumber].getValid()) { // Table entry is in RAM
                    if (op.equals("M") || op.equals("S")) { // Should handle the load/store op of M and S
                        RAM[table[pageNumber].getFrameNumber()].setDirty(true); // OP is S, so set table entry as dirty
                    }
                        futureUse.get(pageNumber).remove();
                    action = "hit";

                } else {
                    if (framesInRAM < RAM.length) { // There is memory in RAM to use
                        pageFaults++;
                            futureUse.get(pageNumber).remove();

                        if (op.equals("M") || op.equals("S")) {
                            table[pageNumber].setDirty(true);
                        }
                        table[pageNumber].setValid(true);
                        table[pageNumber].setReferenced(true);
                        table[pageNumber].setFrameNumber(framesInRAM);
                        RAM[framesInRAM] = table[pageNumber];
                        action = "page fault – no eviction";
                        framesInRAM++;
                    }
                    else { // No more room in RAM, Kick Frame out
                        pageFaults++;
                        Integer toEvict = -1;
                        futureUse.get(pageNumber).remove();

                        for (int i = 0; i < RAM.length; i++) {
                            Integer curPage = RAM[i].getIndex();
                            if (futureUse.get(curPage).peek() == null) { // No more uses, so kick it out of RAM
                                toEvict = i;
                                break;
                            } else {
                                if (toEvict == -1) { // Init evicted frame to the head of the LL RAM[i].getIndex()
                                    toEvict = i;
                                } else {
                                    Integer curFarthest = futureUse.get(RAM[toEvict].getIndex()).peek(); // current page we will evict
                                    if (curFarthest < futureUse.get(RAM[i].getIndex()).peek()) { // Get the current pages at index to see the next use, to test against the current farthest
                                        toEvict = i;
                                    }
                                }
                            }
                        }
                        if (RAM[toEvict].getDirty()) {
                            writes++;
                            action = "page fault – evict dirty";
                        } else {
                            action = "page fault – evict clean";
                        }
                        replacePage(toEvict, pageNumber, op);
                    }
                }
                    System.out.println("Action: " + action); //Todo
            }
        }
        printAlgoStats(algo, RAM.length, memAccess, pageFaults, writes);
    }

    /**
     * Method prints stats at the end of each algorithm
     * @param algo A String for which algorithm was just ran
     * @param frames An Integer for how many frames where used in RAM
     * @param mem An Integer for total memory accesses used in the trace file
     * @param faults An Integer for how many page faults the trace file had
     * @param writes An Integer for how many evicted frames had to be written to disk
     */
    public void printAlgoStats(String algo, Integer frames, Integer mem, Integer faults, Integer writes){
        System.out.println("Algorithm:                " + algo);
        System.out.println("Number of Frames:         " + frames);
        System.out.println("Total Memory Accesses:    " + mem);
        System.out.println("Total Page Faults:        " + faults);
        System.out.println("Total Writes to Disk:     " + writes);
        System.out.println("Total Size of Page Table: " + PAGETABLESIZE + " bytes");
    }

    /**
     * Method swaps and resets the evicted frame from RAM, and replaces it with
     * the replacement frame
     * @param toEvict An Integer of the index in RAM of the frame to remove
     * @param pageNumber An Integer of the Virtual Address
     * @param op A String of the operation to see if the new frame needs to be set to dirty
     */
    public void replacePage(Integer toEvict, Integer pageNumber, String op){
        int index = RAM[toEvict].getIndex();
        table[index].setDirty(false);
        table[index].setFrameNumber(-1);
        table[index].setValid(false);
        table[index].setReferenced(false);

        RAM[toEvict] = table[pageNumber]; //Insert new frame VA
        RAM[toEvict].setValid(true);
        RAM[toEvict].setReferenced(true);
        RAM[toEvict].setFrameNumber(toEvict);
        if (op.equals("S") || op.equals("M")) {
            RAM[toEvict].setDirty(true);
        }
    }
}
