/**
 * Author: Mark Oakeson
 * Course: CSc 452
 * Assignment: Project 4: Virtual Memory Simulator
 * Instructor: Dr. Misurda
 * Due date: 04/12/22
 *
 * The purpose of this program is to simulate memory from a given
 * trace file, and the program will count the number of page faults, memory accesses, and
 * writes to disk for the user input number of frames to have in RAM (8, 16, 32, 64)
 * with a given Virtual address space of 32-bit..
 *
 * Input format is as folows :
 *  vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>
 *
 *  TO RUN:
 *      Tracefile must be unziped before inserting into program
 **/

import java.io.*;

public class vmsim {
    public static void main(String[] args){
        //Format = vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>
        if(args.length != 5){
            System.out.println("ERROR: Wrong number of arguments, format is:");
            System.out.println("java vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
            System.exit(-1);
        }
        else if(!args[0].equals("-n")){
            System.out.println("ERROR: Expected '-n' as first argument.");
            System.exit(-1);
        }
        else if(Integer.valueOf(args[1]) > 64 || Integer.valueOf(args[1]) % 8 != 0 ){
            System.out.println("ERROR: Acceptable frame sizes are 8, 16, 32, and 64.");
            System.exit(-1);
        }
        else if(!args[2].equals("-a")){
            System.out.println("ERROR: Expected '-a' as first argument.");
            System.exit(-1);
        }

        else if(!args[3].equals("opt") && !args[3].equals("clock") && !args[3].equals("lru") && !args[3].equals("nfu") ){
            System.out.println("ERROR: Acceptable algorithms are: opt, clock, lru, or nfu.");
            System.exit(-1);
        }
        File file;
        file = new File(args[4]);
        if(!file.exists()){
            System.out.println("ERROR: No file exists for: " + args[2]);
            System.exit(-1);
        }
        Integer numFrames = Integer.valueOf(args[1]);
        Algorithms algoSim = new Algorithms(numFrames);
        String algo = args[3];
        if(algo.equals("opt")){
            algoSim.optimal(file);
        }
        else if(algo.equals("clock")){
            algoSim.clock(file);
        }
        else if(algo.equals("lru")){
            algoSim.lru(file);
            }
        else if(algo.equals("nfu")){
            algoSim.nfu(file);
            }
    }
}
