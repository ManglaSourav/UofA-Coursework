'''
Author: Amber Charlotte Converse
File: vmsim.py
Description: This file is meant to simulate the translation of virtual
    memory to physical memory using a variety of different algorithms
    that choose pages to evict with the goal of minimizing the number
    of page faults. The algorithms to choose from are:
        * OPT: Optimal and impossible algorithm. A perfect algorithm
            that knows the future and chooses the page to be used
            again farthest in the future.
        * Clock: First unreferenced page in the queue is evicted.
        * LRU: Evict the least recently used page.
        * NFU: Evict the page whose referenced count (frequency of
            use) since loaded is the lowest.

    The program is run as follows:
        python3 vmsim.py –n <num_frames> -a <opt|clock|lru|nfu> <tracefile>

    The tracefile is a file containing memory accesses generated using
    "lackey" in the following format:
        +------------------------------------------------------
        | I 0023C790,2 # instruction read at 0x0023C790 of size 2
        | I 0023C792,5
        |  S BE80199C,4 # data store at 0xBE80199C of size 4
        | I 0025242B,3
        |  L BE801950,4 # data load at 0xBE801950 of size 4
        | I 0023D476,7
        |  M 0025747C,1 # data modify at 0x0025747C of size 1
        | I 0023DC20,2
        |  L 00254962,1
        |  L BE801FB3,1
        | I 00252305,1
        |  L 00254AEB,1
        |  S 00257998,1
        +------------------------------------------------------
'''
import sys
import math

ADDRESS_WIDTH = 32
VM_SIZE = 2**ADDRESS_WIDTH
PAGE_SIZE  = 2**13 # 8KB
NUM_OFFSET_BITS = int(math.log(PAGE_SIZE, 2))

class PageTable:
    '''
    This class implements a single-level page table for a 32-bit
    address space. Pages are 8KB in size and the number of frames
    is specified by the num_frames parameter in the constructor.

    Initialization requires these parameters:
    num_frames (int): the number of frames in physical memory
    algo (str): the algorithm to use, either opt, clock, lru, or
        nfu.
    instructions (List[Tuple(String, Integer)]: for use with opt
        algorithm. A list of nstructions. Each instruction is a memory
        access to perform, either an access to an instruction itself, a
        load, a save, or modify. Each instruction is a string (either
        'I', 'L', 'S', or 'M') and an integer address.
    '''
    def __init__(self, num_frames, algo, instructions):
        self.frames_occupied = 0
        self.num_frames = num_frames

        self.pt = {} # using a python dictionary to avoid initial overhead

        self.algo = algo
        if algo == "opt":
            self.i = 0 # keep track of the current instruction
            self.instructions = instructions
            # create dict for prediction
            self.page_usage = initialize_page_usage(instructions)
            self.valid_ptes = set() # the set of all valid ptes which are in memory
        elif algo == "clock":
            self.clock = Clock()
        elif algo == "lru":
            self.i = 0
            self.last_usage = {}
        elif algo == "nfu":
            self.reference_counts = {}
        else:
            print("ERROR: Invalid algorithm. Please choose from opt, clock, lru, or nfu.")
            exit(1)

    def access_memory(self, pte, page_number):
        '''
        This method generalizes the access of memory to any type of access
        (whether load, store, modify, etc.). This method does not handle
        dirtying of memory. It returns 0 if there was no page fault, 1 if
        there was a page fault, but the table was not full, -1 if there
        was a page fault and a page needed to be evicted clean, and -2 if
        there was a page fault and a page needed to be evicted dirty.

        PARAM:
        pte (PageTableEntry): the page table entry for the page to access.
        page_number (int): the page number for the memory access

        RETURN:
        int: 0 if there was no page fault, 1 if there was a page
            fault, but the table was not full, -1 if there was a
            page fault and a page needed to be evicted clean, and
            -2 if there was a page fault and a page needed to be
            evicted dirty.
        '''
        if self.algo == "opt" or self.algo == "lru":
            self.i += 1
        if pte.valid:
            pte.referenced = True
            if self.algo == "lru":
                self.last_usage[page_number] = self.i
            elif self.algo == "nfu":
                if page_number not in self.reference_counts:
                    self.reference_counts[page_number] = 0
                self.reference_counts[page_number] += 1
            return 0
        elif self.frames_occupied < self.num_frames:
            pte.valid = True
            pte.referenced = True
            if self.algo == "opt":
                self.valid_ptes.add(pte)
            elif self.algo == "clock":
                self.clock.add(pte)
            elif self.algo == "lru":
                self.last_usage[page_number] = self.i
            elif self.algo == "nfu":
                self.reference_counts[page_number] = 1
            self.frames_occupied += 1
            return 1
        else:
            pte.valid = True
            pte.referenced = True
            if self.algo == "opt":
                ret = evict_opt(self.valid_ptes, self.i, \
                                self.instructions, self.page_usage)
                self.valid_ptes.add(pte)
            elif self.algo == "clock":
                ret = self.clock.choose(pte)
            elif self.algo == "lru":
                ret = evict_lru(self.last_usage, self.pt)
                self.last_usage[page_number] = self.i
            elif self.algo == "nfu":
                ret = evict_nfu(self.reference_counts, self.pt)
                self.reference_counts[page_number] = 1

            if ret == 0:
                return -1
            elif ret == 1:
                return -2

    def read(self, address):
        '''
        This method simulates reading data. It returns 0 if there was
        no page fault, 1 if there was a page fault, but the table was
        not full, -1 if there was a page fault and a page needed
        to be evicted clean, and -2 if there was a page fault and a
        page needed to be evicted dirty.

        PARAM:
        address (int): a 32-bit virtual address to translate into
            a frame number.

        RETURN:
        int: 0 if there was no page fault, 1 if there was a page
            fault, but the table was not full, -1 if there was a
            page fault and a page needed to be evicted clean, and
            -2 if there was a page fault and a page needed to be
            evicted dirty.
        '''
        page_number = address >> NUM_OFFSET_BITS
        if page_number not in self.pt:
            self.pt[page_number] = PageTableEntry(page_number)
        pte = self.pt[page_number]
        return self.access_memory(pte, page_number)

    def write(self, address):
        '''
        This method simulates writing data. It returns 0 if there was
        no page fault, 1 if there was a page fault, but the table was
        not full, -1 if there was a page fault and a page needed
        to be evicted clean, and -2 if there was a page fault and a
        page needed to be evicted dirty.

        PARAM:
        address (int): a 32-bit virtual address to translate into
            a frame number.

        RETURN:
        int: 0 if there was no page fault, 1 if there was a page
            fault, but the table was not full, -1 if there was a
            page fault and a page needed to be evicted clean, and
            -2 if there was a page fault and a page needed to be
            evicted dirty.
        '''
        page_number = address >> NUM_OFFSET_BITS
        if page_number not in self.pt:
            self.pt[page_number] = PageTableEntry(page_number)
        pte = self.pt[page_number]
        pte.dirty = True
        return self.access_memory(pte, page_number)

class PageTableEntry:
        '''
        This class represents a single page table entry.

        FIELDS:
        page_number (int): the page number of this entry
        dirty (bool): whether this entry has been modified
        referenced (bool): whether this entry has been referenced
        valid (bool): whether this entry is valid
        '''
        def __init__(self, page_number):
            self.page_number = page_number
            self.dirty = False
            self.referenced = False
            self.valid = False

class Clock:
    '''
    This class implements the clock ADT for the clock algorithm.

    Note: There is no way to delete a node from the clock. The
    ADT only requires adding of nodes until capacity and replacement
    of existing nodes.
    '''
    def __init__(self):
        self.head = None

    def add(self, pte):
        '''
        This method adds a new node to the clock.

        PARAM:
        pte (PageTableEntry): the PageTableEntry of the page to
            add.
        '''
        new_node = ClockNode(pte)
        if self.head == None: # Empty clock
            self.head = new_node
        elif self.head.next == None: # Clock with one node
            self.head.prev = new_node
            new_node.next = self.head
            new_node.prev = self.head
            self.head.next = new_node
        else: # Normal case
            self.head.prev.next = new_node
            new_node.prev = self.head.prev
            self.head.prev = new_node
            new_node.next = self.head

    def choose(self, pte):
        '''
        This method chooses a node to replace in the clock and
        reports the action taken (0 if replaced entry was clean,
        1 if it was dirty). This method will also edit the replaced
        page table entry to be invalid.

        PARAM:
        pte (PageTableEntry): the PageTableEntry of the page to
            insert into the clock.

        RETURN:
        int: 0 if replaced entry was clean, 1 if it was dirty.
        '''
        cur = self.head
        while cur.pte.referenced:
            cur.pte.referenced = False
            cur = cur.next

        replaced_pte = cur.pte
        cur.pte = pte
        replaced_pte.valid = False

        if replaced_pte.dirty:
            replaced_pte.dirty = False
            return 1
        else:
            return 0

class ClockNode:
    '''
    This class represents a single node in a clock ADT with
    a PageTableEntry as a value.

    FIELDS:
    pte (PageTableEntry): the page table entry represented by
        this node.
    next (ClockNode): the next node in the clock.
    prev (ClockNode): the previous node in the clock.
    '''
    def __init__(self, pte):
        self.pte = pte
        self.next = None
        self.prev = None

def initialize_page_usage(instructions):
    '''
    This function initializes a dictionary with page numbers as
    keys and lists of every usage (generally in the future) of the
    page (sorted).

    PARAM:
    instructions (List[Tuple(String, Integer)]: A list of instructions.
        Each instruction is a memory access to perform, either an access
        to an instruction itself, a load, a save, or modify. Each
        instruction is a string (either 'I', 'L', 'S', or 'M') and an
        integer address.

    RETURN:
    Dict<Integer, List[Integer]>: a dictionary with page numbers as keys
        and lists of every usage (generally in the future) of the page as
        values (sorted).
    '''
    page_usage = {}
    i = 0
    for instruction in instructions:
        page_number = instruction[1] >> NUM_OFFSET_BITS
        if page_number not in page_usage:
            page_usage[page_number] = []
        page_usage[page_number].append(i)
        i += 1
    return page_usage

def evict_opt(valid_ptes, next_instruction, instructions, page_usage):
    '''
    This function implements the optimal and impossible algorithm's
    solution to choosing a page to evict.

    PARAM:
    valid_ptes (Set<PageTableEntry>): the set of valid ptes in the page table
    next_instruction (int): the current count of instructions that have
        been completed, representing the index of the next instruction
        in instructions
    instructions (List[Tuple(String, Integer)]: For use with opt
        algorithm. A list of nstructions. Each instruction is a memory
        access to perform, either an access to an instruction itself, a
        load, a save, or modify. Each instruction is a string (either
        'I', 'L', 'S', or 'M') and an integer address.
    page_usage (Dict<Integer, List[Integer]>): a dictionary with page numbers
        as keys and lists of every usage (generally in the future) of the
        page as values (sorted).

    RETURN:
    int: 0 if the eviction was clean, 1 if the eviction was dirty.
    '''
    farthest_access = (None, float("-inf"))
    for pte in valid_ptes:
        usage = page_usage[pte.page_number]
        if len(usage) == 0:
            farthest_access = (pte, float("inf"))
            break
        next_use = usage[0]
        while next_use < next_instruction and len(usage) != 1:
            usage.remove(next_use)
            next_use = usage[0]
        if len(usage) == 1 and next_use < next_instruction:
            farthest_access = (pte, float("inf"))
            break
        elif next_use > farthest_access[1]:
            farthest_access = (pte, next_use)

    pte = farthest_access[0]
    pte.valid = False

    valid_ptes.remove(pte)

    if pte.dirty:
        pte.dirty = False
        return 1
    else:
        return 0

def evict_lru(last_usage, pt):
    '''
    This function chooses the least recently used page to be evicted.

    PARAM:
    last_usage (Dict<Integer, Integer>): a dictionary with the page
        numbers as keys and the number of ticks since the process
        start of the last access for that memory location as values.
    pt (Dict[Integer, PageTableEntry]): the page table to translate
        virtual addresses to physical addresses with page numbers as
        keys and PageTableEntries as values

    RETURN:
    int: 0 if the eviction was clean, 1 if the eviction was dirty.
    '''
    min_page = (None, float("inf"))
    for page_number, referenced in last_usage.items():
        if referenced < min_page[1]:
            min_page = (page_number, referenced)
    min_pte = pt[min_page[0]]

    min_pte.valid = False

    del last_usage[min_page[0]]

    if min_pte.dirty:
        min_pte.dirty = False
        return 1
    else:
        return 0

def evict_nfu(reference_counts, pt):
    '''
    This function chooses the page whose referenced count
    (frequency of use) since loaded is the lowest to be evicted.

    PARAM:
    reference_counts (Dict<Integer, Integer>): a dictionary with the page
        numbers as keys and the number of accesses for that memory
        location since loading into memory as values.
    pt (Dict[Integer, PageTableEntry]): the page table to translate
        virtual addresses to physical addresses with page numbers as
        keys and PageTableEntries as values

    RETURN:
    int: 0 if the eviction was clean, 1 if the eviction was dirty.
    '''
    min_page = (None, float("inf"))
    for page_number, count in reference_counts.items():
        if count < min_page[1]:
            min_page = (page_number, count)
    min_pte = pt[min_page[0]]

    min_pte.valid = False

    del reference_counts[min_pte.page_number]

    if min_pte.dirty:
        min_pte.dirty = False
        return 1
    else:
        return 0

def is_valid_instruction(line):
    '''
    This function validates a line to check if it is a valid instruction (i.e.
    starts with I, L, S, or M, then a space, then a hex number and a decimal
    integer separated by a comma.
    '''
    parts = line.split()
    if parts[0] not in ['I', 'L', 'S', 'M']:
        return False
    try:
        second_part = parts[1].split(',')
        _ = int(second_part[0], 16)
        _ = int(second_part[1])
    except:
        return False
    return True

def main():
    try:
        num_frames_index = sys.argv.index("-n") + 1
        algo_index = sys.argv.index("-a") + 1
        num_frames = int(sys.argv[num_frames_index])
        algo = sys.argv[algo_index]
        indices = [index for index in range(1,6) \
            if index not in [num_frames_index-1, num_frames_index, algo_index-1, algo_index]]
        tracefile = sys.argv[indices[0]]
    except:
        print("ERROR: Invalid arguments. Program should be run as:\n" + \
              "\tpython3 vmsim.py –n <num_frames> -a <opt|clock|lru|nfu> <tracefile>")
        exit(1)

    with open(tracefile, 'r') as f:
        lines = f.readlines()
    instructions = []
    for line in lines:
        parts = line.strip().split()
        if is_valid_instruction(line.strip()):
            instructions.append((parts[0],int(parts[1].split(',')[0], 16)))

    pt = PageTable(num_frames, algo, instructions)
    num_memory_accesses = 0
    num_page_faults = 0
    num_dirty_evictions = 0
    for instruction in instructions:
        if instruction[0] == 'I' or instruction[0] == 'L':
            ret = pt.read(instruction[1])
        elif instruction[0] == 'S':
            ret = pt.write(instruction[1])
        elif instruction[0] == 'M':
            ret = pt.write(instruction[1])
            num_memory_accesses += 1 # account for second memory access
        else:
            print(f"ERROR: Invalid instruction {instruction[0]} {instruction[1]}")
            exit(1)

        num_memory_accesses += 1
        if ret == 0:
            print(f"{instruction[0]} {hex(instruction[1])}: hit\n")
        elif ret == 1:
            num_page_faults += 1
            print(f"{instruction[0]} {hex(instruction[1])}: page fault, no eviction\n")
        elif ret == -1:
            num_page_faults += 1
            print(f"{instruction[0]} {hex(instruction[1])}: page fault, evict clean\n")
        elif ret == -2:
            num_page_faults += 1
            num_dirty_evictions += 1
            print(f"{instruction[0]} {hex(instruction[1])}: page fault, evict dirty\n")

    print(f"Algorithm: {algo}\n" + \
          f"Number of frames:\t{num_frames}\n" + \
          f"Total memory accesses:\t{num_memory_accesses}\n" + \
          f"Total page faults:\t{num_page_faults}\n" + \
          f"Total writes to disk:\t{num_dirty_evictions}\n" + \
          f"Total size of page table:\t{4 * (VM_SIZE // PAGE_SIZE)} bytes\n")

if __name__ == "__main__":
    main()
