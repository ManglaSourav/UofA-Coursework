/**
 * Represents one of the possible actions that could happen
 * when a page is accessed.
 */
public enum PageAction {
    
    HIT,
    FAULT_NO_EVICT,
    FAULT_EVICT_CLEAN,
    FAULT_EVICT_DIRTY;
    
}
