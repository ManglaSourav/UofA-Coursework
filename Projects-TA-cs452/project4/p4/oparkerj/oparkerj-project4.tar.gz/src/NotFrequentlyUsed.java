import java.util.HashMap;
import java.util.Map;

/**
 * Implementation of NFU.
 * This is done using a frequency map. Every time a page is accessed,
 * the frequency for that page is incremented.
 */
public class NotFrequentlyUsed extends PageHandler {
    
    private Map<Integer, Integer> counts;
    
    public NotFrequentlyUsed(int frameCount) {
        super(frameCount);
        counts = new HashMap<>();
    }
    
    @Override
    public PageAction needPage(int page) {
        // Increment the reference count of the page
        counts.merge(page, 1, Integer::sum);
        
        return super.needPage(page);
    }
    
    @Override
    public int chooseEvictPage() {
        // Choose the page with the smallest frequency value.
        var chosen = counts.entrySet().stream().min(Map.Entry.comparingByValue());
        var page = chosen.get().getKey();
        counts.remove(page);
        return page;
    }
    
}
