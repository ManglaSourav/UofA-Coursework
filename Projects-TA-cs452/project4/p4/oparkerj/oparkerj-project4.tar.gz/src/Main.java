import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Main {
    
    /**
     * Simulate a trace file.
     *
     * Args:
     * -n (frame count): Specify the number of available frames, greater than 0.
     * -a (algorithm): Specify the algorithm to use, opt, clock, lru, or nfu.
     * -noprint: Disable printing the action for each address (runs significantly faster)
     *
     * -t (trace file): Run tests, ignores the other options, runs every algorithm
     * with 8, 16, 32, and 64 frames. (Implicit -noprint).
     *
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        int frameCount = 0;
        String algorithm = null;
        Path path = null;
        String test = null;
        boolean printing = true;
    
        // Read args
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-n")) {
                if (i + 1 == args.length) {
                    System.out.println("Number of frames not specified.");
                    return;
                }
                i++;
                frameCount = Integer.parseInt(args[i]);
            }
            else if (args[i].equals("-a")) {
                if (i + 1 == args.length) {
                    System.out.println("Algorithm not specified.");
                    return;
                }
                i++;
                algorithm = args[i];
            }
            else if (args[i].equals("-t")) {
                if (i + 1 == args.length) {
                    System.out.println("Test file not specified.");
                    return;
                }
                i++;
                test = args[i];
            }
            else if (args[i].equals("-noprint")) {
                printing = false;
            }
            else {
                path = Path.of(args[i]);
            }
        }
    
        // Error checking
        if (test == null) {
            if (frameCount < 1) {
                System.out.println("Frame count must be specified greater than 0.");
                return;
            }
            if (algorithm == null) {
                System.out.println("Algorithm not specified.");
                return;
            }
        }
        else {
            path = Path.of(test);
        }
        // Check that the trace file exists
        if (path == null || !Files.isRegularFile(path)) {
            System.out.println("Trace file not specified or does not exist.");
            return;
        }
        
        // Read trace file
        System.out.println("Reading trace file...");
        var original = new ArrayList<Integer>();
        var data = traceToPages(path, original);
    
        if (test != null) {
            runAllTests(data, original);
        }
        else {
            // Choose which algorithm to use
            System.out.println("Setting up...");
            var handler = getHandler(algorithm, frameCount, data);
    
            if (handler == null) {
                System.out.println("Invalid algorithm.");
                return;
            }
    
            runTest(data, original, frameCount, algorithm, handler, printing);
        }
    }
    
    /**
     * Execute a simulation.
     *
     * @param data Data given by {@link Main#traceToPages(Path, List)}.
     * @param frameCount Number of frames.
     * @param algorithm Name of the algorithm.
     * @param handler Page handler implementation.
     */
    public static void runTest(List<Integer> data, List<Integer> original, int frameCount, String algorithm, PageHandler handler, boolean print) {
        var stats = new Statistics(algorithm, frameCount);
        stats.setPrint(print);
        handler.setStatReceiver(stats::recordAction);
    
        // Run through all the addresses in the trace file
        System.out.println("Simulating...");
        for (int i = 0; i < data.size(); i++) {
            handler.need(data.get(i), original.get(i));
        }
    
        System.out.println();
        System.out.println(stats);
    }
    
    /**
     * Run all algorithms and common frame counts on the given data.
     *
     * @param data Data given by {@link Main#traceToPages(Path, List)}
     */
    public static void runAllTests(List<Integer> data, List<Integer> original) {
        var algorithms = new String[] {"opt", "clock", "lru", "nfu"};
        var frames = new int[] {8, 16, 32, 64};
    
        for (String algorithm : algorithms) {
            for (int frame : frames) {
                System.out.println("Setting up...");
                runTest(data, original, frame, algorithm, getHandler(algorithm, frame, data), false);
                System.out.println();
            }
        }
    }
    
    /**
     * Get an instance of a page handler from the algorithm name.
     *
     * @param algorithm Name of the algorithm to get.
     * @param frameCount Number of frames.
     * @param data Data given by {@link Main#traceToPages(Path, List)}
     * @return Page handler implementation, or null if the algorithm is invalid.
     */
    public static PageHandler getHandler(String algorithm, int frameCount, List<Integer> data) {
        return switch (algorithm) {
            case "opt" -> new Optimal(frameCount, data);
            case "clock" -> new Clock(frameCount);
            case "lru" -> new LeastRecentlyUsed(frameCount);
            case "nfu" -> new NotFrequentlyUsed(frameCount);
            default -> null;
        };
    }
    
    /**
     * Convert a trace file to a list of page numbers.
     * The 0th bit is used to store whether the page access is for
     * a store operation.
     * To get a page number from one of the integers, perform an unsigned
     * right shift by one.
     *
     * All lines are expected to be in the format AAAXXXXXXXX,D
     * where AAA may be "I  " (instruction read), " L " (memory load),
     * " S " (memory store), " M " (modify, a load followed by a store).
     * Lines that begin with a different character are ignored.
     * XXXXXXXX represents a hexadecimal number, and D is some integer.
     *
     * @param path Trace file that is assumed to exist.
     * @param original
     * @return List of page numbers.
     * @throws IOException If there is a problem reading the file.
     */
    public static List<Integer> traceToPages(Path path, List<Integer> original) throws IOException {
        List<Integer> list = new ArrayList<>();
        
        Files.lines(path).filter(s -> {
            return s.startsWith("I") || s.startsWith(" ");
        }).forEach(s -> {
            int addr = Integer.parseUnsignedInt(s.substring(3, 11), 16);
            int page = addr >>> (PageHandler.PAGE_BITS - 1);
            page &= ~1;
            
            original.add(addr);
            if (s.startsWith("I")) {
                list.add(page);
            }
            else if (s.startsWith(" L")) {
                list.add(page);
            }
            else if (s.startsWith(" S")) {
                // Set the store bit
                list.add(page | 1);
            }
            else if (s.startsWith(" M")) {
                // Modify, both load and store
                list.add(page);
                list.add(page | 1);
                original.add(addr);
            }
        });
        
        return list;
    }
    
}
