import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Base class that tracks what pages are currently mapped to
 * memory frames, and also tracks which ones are dirty.
 * This class provides page management, and the implementation of this
 * class defines how to select a page for eviction.
 */
public abstract class PageHandler {
    
    public static final int PAGE_BITS = 13;
    
    protected final int frameCount;
    
    private Set<Integer> pageSet;
    private Set<Integer> dirty;
    
    private BiConsumer<PageAction, Integer> statReceiver;
    
    public PageHandler(int frameCount) {
        this.frameCount = frameCount;
        pageSet = new HashSet<>(frameCount);
        dirty = new HashSet<>(frameCount);
    }
    
    /**
     * Get the set of pages currently mapped to memory frames.
     * @return Mapped pages.
     */
    protected Set<Integer> getPageSet() {
        return pageSet;
    }
    
    /**
     * Indicate that a page is needed in physical memory. This will evict
     * a page if necessary and then mark the new page as loaded.
     * @param page Page number.
     */
    public PageAction needPage(int page) {
        if (pageSet.contains(page)) {
            return PageAction.HIT;
        }
        else if (pageSet.size() < frameCount) {
            pageSet.add(page);
            return PageAction.FAULT_NO_EVICT;
        }
        else {
            int evict = chooseEvictPage();
            pageSet.remove(evict);
            pageSet.add(page);
            return dirty.remove(evict) ? PageAction.FAULT_EVICT_DIRTY : PageAction.FAULT_EVICT_CLEAN;
        }
    }
    
    /**
     * Indicate that the given page data is needed. The first (0th) bit is not part
     * of the page number, but instead indicates whether the access is
     * for a store operation. This would mark the page as dirty.
     * Page data is expected to be in the format given by {@link Main#traceToPages(Path, java.util.List)}.
     * @param pageData Page number shifted left by 1, bit 0 is set if this
     * should represent a store operation.
     */
    public void need(int pageData, int addr) {
        if ((pageData & 1) > 0) {
            pageData >>>= 1;
            dirty.add(pageData);
        }
        else {
            pageData >>>= 1;
        }
        var action = needPage(pageData);
        statReceiver.accept(action, addr);
    }
    
    /**
     * Choose a page to evict from memory.
     * @return Page number.
     */
    public abstract int chooseEvictPage();
    
    public final int getFrameCount() {
        return frameCount;
    }
    
    public final BiConsumer<PageAction, Integer> getStatReceiver() {
        return statReceiver;
    }
    
    /**
     * Set the stat receiver, which receives the action that is taken for
     * each page action. The stat receiver is used to track statistics
     * for this handler.
     * @param statReceiver Stat tracking handler.
     */
    public final void setStatReceiver(BiConsumer<PageAction, Integer> statReceiver) {
        this.statReceiver = statReceiver;
    }
    
}
