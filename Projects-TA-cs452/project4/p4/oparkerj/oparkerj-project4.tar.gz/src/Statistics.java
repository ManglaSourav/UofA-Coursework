/**
 * Tracks the statistics that are output from a page handler.
 * Every time recordAction is called, increments the corresponding
 * values.
 */
public class Statistics {
    
    private String algorithm;
    private int frameCount;
    private int memoryAccesses;
    private int pageFaults;
    private int writesToDisk;
    
    private boolean print = true;
    
    public Statistics(String algorithm, int frameCount) {
        this.algorithm = algorithm;
        this.frameCount = frameCount;
    }
    
    public void recordAction(PageAction action, int address) {
        memoryAccesses++;
        if (action != PageAction.HIT) {
            pageFaults++;
        }
        if (action == PageAction.FAULT_EVICT_DIRTY) {
            writesToDisk++;
        }
    
        if (!print) return;
        var name = action.name();
        System.out.printf("%08X: %s%n", address, name);
    }
    
    public boolean willPrintActions() {
        return print;
    }
    
    public void setPrint(boolean print) {
        this.print = print;
    }
    
    @Override
    public String toString() {
        var builder = new StringBuilder();
        var newline = System.lineSeparator();
        builder.append(String.format("Algorithm:                %s", algorithm)).append(newline)
               .append(String.format("Number of frames:         %d", frameCount)).append(newline)
               .append(String.format("Total memory accesses:    %d", memoryAccesses)).append(newline)
               .append(String.format("Total page faults:        %d", pageFaults)).append(newline)
               .append(String.format("Total writes to disk:     %d", writesToDisk)).append(newline)
               .append(String.format("Total size of page table: %d bytes", (1 << (32 - PageHandler.PAGE_BITS + 2))));
        return builder.toString();
    }
    
}
