/**
 * Implementation of the least-recently used algorithm.
 * This is done with a simple linked list. Whenever a page is accessed,
 * it is moved to the end of the list, and when a page needs to be evicted,
 * a page is taken from the head of the list.
 */
public class LeastRecentlyUsed extends Clock {
    
    public LeastRecentlyUsed(int frameCount) {
        super(frameCount);
    }
    
    @Override
    protected void onNodeFound(PageNode node) {
        // Move the node to the end of the list
        if (node == head) {
            head = head.next;
        }
        else {
            node.unlink();
            node.insertBefore(head);
        }
    }
    
    @Override
    public int chooseEvictPage() {
        // The least recently used page is at the head of the list.
        var chosen = head;
        head = head.next;
        chosen.unlink();
        return chosen.page;
    }
    
}
