/**
 * Implement the clock algorithm (second-chance algorithm).
 *
 * This is done using a linked list. Whenever a page is accessed,
 * it is moved to the end of the list and the referenced bit is set.
 * When a page needs to be evicted, the first-non referenced page is taken.
 * Referenced pages are given a second chance at the cost of no longer
 * being referenced.
 */
public class Clock extends PageHandler {
    
    protected PageNode head;
    
    public Clock(int frameCount) {
        super(frameCount);
    }
    
    /**
     * Define what to do when a node is referenced and an entry already
     * exists in the clock list.
     * @param node Page node.
     */
    protected void onNodeFound(PageNode node) {
        // Set the page as referenced
        node.referenced = true;
    }
    
    @Override
    public PageAction needPage(int page) {
        // Make sure this page has an entry in the list, and if so
        // move it to the end.
        var node = PageNode.find(head, page);
        if (node == null) {
            // Create a node for this page
            node = new PageNode(page);
            if (head == null) {
                head = node;
            }
            else {
                node.insertBefore(head);
            }
        }
        else {
            onNodeFound(node);
        }
        
        return super.needPage(page);
    }
    
    @Override
    public int chooseEvictPage() {
        // Take the first page in the list that's not referenced,
        // giving a second chance to referenced pages.
        var current = head;
        while (current.referenced) {
            current.referenced = false;
            current = current.next;
        }
        head = current.next;
        current.unlink();
        return current.page;
    }
    
    
    
}
