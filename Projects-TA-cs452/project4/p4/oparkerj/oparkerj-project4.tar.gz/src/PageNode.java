/**
 * A doubly-linked list node. Stores a page number and whether it is
 * referenced.
 */
public class PageNode {
    
    int page;
    boolean referenced;
    PageNode prev;
    PageNode next;
    
    PageNode(int page) {
        this.page = page;
        referenced = true;
        prev = this;
        next = this;
    }
    
    /**
     * Search for the node for the given page. Starting at the head
     * and going backwards through the list, which gives preference to
     * more recently used pages.
     * @param page Page number.
     * @return Node for the given page, or else null.
     */
    static PageNode find(PageNode head, int page) {
        if (head == null) return null;
        
        var current = head;
        while (true) {
            if (current.page == page) return current;
            current = current.prev;
            if (current == head) return null;
        }
    }
    
    /**
     * Insert this node before the given node in the list.
     *
     * @param node List node.
     */
    void insertBefore(PageNode node) {
        prev = node.prev;
        node.prev.next = this;
        next = node;
        node.prev = this;
    }
    
    /**
     * Remove this node from the list it is in.
     * This node effectively becomes a 1-element list.
     */
    void unlink() {
        prev.next = next;
        next.prev = prev;
        prev = this;
        next = this;
    }
    
}