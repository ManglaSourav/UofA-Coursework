import java.nio.file.Path;
import java.util.*;

/**
 * Page handler that implements the optimal page algorithm.
 * This will choose a page to evict as if the system had perfect
 * knowledge of the future, and will choose the page that will not
 * be used for the longest time.
 * This is done by initializing with the times each page is accessed. When it
 * comes time to evict, we can immediately know which page is the best option.
 */
public class Optimal extends PageHandler {
    
    private Map<Integer, Deque<Integer>> usages;
    
    public Optimal(int frameCount, List<Integer> trace) {
        super(frameCount);
        
        buildUsages(trace);
    }
    
    /**
     * Build the map that contains the times each page is accessed.
     * @param trace Trace data as created by {@link Main#traceToPages(Path, List)}.
     */
    private void buildUsages(List<Integer> trace) {
        usages = new HashMap<>();
    
        for (int i = 0; i < trace.size(); i++) {
            int page = trace.get(i) >>> 1;
            int currentTime = i;
            
            usages.compute(page, (pg, times) -> {
                if (times == null) times = new ArrayDeque<>(8);
                times.addLast(currentTime);
                return times;
            });
        }
    }
    
    @Override
    public PageAction needPage(int page) {
        // When a page is accessed, remove the earliest time from the table.
        usages.computeIfPresent(page, (i, times) -> {
            if (times.size() == 1) return null;
            times.removeFirst();
            return times;
        });
        
        return super.needPage(page);
    }
    
    @Override
    public int chooseEvictPage() {
        // Get the times that the currently loaded pages are used.
        // Choose the one that will be used furthest in the future.
        var best = getPageSet().stream()
                               .map(page -> {
                                   var times = usages.getOrDefault(page, null);
                                   return new PageTime(page, times == null ? Integer.MAX_VALUE : times.peekFirst());
                               })
                               .max(Comparator.comparingInt(PageTime::time));
        return best.get().page();
    }
    
    // Store a page number and time.
    private record PageTime(int page, int time) { }
    
}
