# Filename: vmsim.py
# Author: Ember Chan
# Course: CSC452
# Descrpition: Simulates virtual memory

import sys
import re
from collections import deque
from heapq import *

# How to calculate size of page table?
# Make dict of form page -> queue of uses

# Get command line arguments
NUM_FRAMES = int(sys.argv[2])
ALGORITHM = sys.argv[4]
TRACEFILE = sys.argv[5]

if ALGORITHM not in ["opt", "clock", "lru", "nfu"]:
    print("incorrect algorithm argument")
    exit(1)

#things we want to keep track of
totalMemAccesses = 0
totalPageFaults = 0
totalWritesToDisk = 0
framesUsed = 0

#other globals
OPT = dict()
OPTheap = []
OPT_largest = -1
frames = []
pages = dict()
clock = 0


#TODO: Comment, Writeup


class Frame:
    time = 1
    
    def __init__(self):
        self.valid = False
        self.page = -1
        self.dirty = False
        self.ref = False
        self.reft = -1
        self.refc = 0

    def update(self, page, dirty):
        self.valid = True
        self.page = page
        self.dirty = dirty
        self.refc = 0
        self.hit()

    def hit(self):
        self.ref = True
        self.reft = Frame.time
        Frame.time += 1
        self.refc += 1;



def main():
    global frames, ALGORITHM
    
    setupOPT()
    
    for i in range(NUM_FRAMES):
        frames.append(Frame())

    i = 0
    f = open(TRACEFILE, 'r')
    line = f.readline()
    while line:
        if line[0] in ["-", "="]: #skip valgrind msgs
            line = f.readline()
            continue
        line = re.split("\s+|,", line)
        line = list(filter(None, line))
        addr = int(line[1], 16)
        page = addr >> 13
        #Pages are 8KB => 2^3 * 2^10 = 2^13
        #So our page number is the VA >> 13
        
        changed = line[0] in ["M", "S"]

        #Move handling a page to a sperate function?
        memAccess(page, changed)
       

        line = f.readline()
    f.close()
    printSummary()

def setupOPT(): #setups OPT queues
    global OPT, OPT_largest
    i = 1
    f = open(TRACEFILE, 'r')
    line = f.readline()
    while line:
        if line[0] in ["-", "="]: #skip valgrind msgs
            line = f.readline()
            continue
        
        line = re.split("\s+|,", line)
        line = list(filter(None, line))
        addr = int(line[1], 16)
        page = addr >> 13

        if page in OPT:
            OPT[page].append(i)
        else:
            OPT[page] = deque()
            OPT[page].append(i)
        i+=1
        line = f.readline()
    f.close()
    OPT_largest = i

def memAccess(page, changed):
    global pages, frames, totalMemAccesses, totalWritesToDisk, totalPageFaults
    global framesUsed, OPT

    OPT[page].popleft()
    totalMemAccesses += 1
    
    #If page already in frames, we're done (hit)
    if page in pages: 
        print("hit")
        frames[pages[page]].hit()
        return
    else:
        totalPageFaults+=1

    #If we have an empty frame, then fill a frame - no eviction
    if framesUsed < NUM_FRAMES:
        updateFrame(framesUsed, page, changed)
        pages[page] = framesUsed
        framesUsed += 1
        print("page fault - no eviction")
        return

    #Otherwise, use algorithm to pick a frame to evict, and evict it
    evictFrame = chooseFrameToEvict()
    if frames[evictFrame].dirty:
        print("Page fault - evict dirty")
        totalWritesToDisk += 1
    else:
        print("Page fault - evict clean")
    del pages[frames[evictFrame].page]
    updateFrame(evictFrame, page, changed)
    pages[page] = evictFrame

#Pick a frame to evict
def chooseFrameToEvict():
    global OPT, clock, frames
    
    if ALGORITHM == "opt":
        q = None
        for i in range(NUM_FRAMES):
            p = frames[i].page
            if(len(OPT[p]) == 0):
                return i
            nextRef = OPT[p].popleft()
            OPT[p].appendleft(nextRef)
            if q == None or nextRef > q:
                q = nextRef
                retval = i
        return retval
    
    if ALGORITHM == "clock":
        while frames[clock].ref:
            frames[clock].ref = False
            clock = (clock + 1)%NUM_FRAMES
        retval = clock
        clock = (clock + 1)%NUM_FRAMES
        return retval
    
    if ALGORITHM == "lru":
        q = None
        for i in range(NUM_FRAMES):
            reft = frames[i].reft
            if q == None or reft < q:
                q = reft
                retval = i
        return retval

    if ALGORITHM == "nfu":
        q = None
        for i in range(NUM_FRAMES):
            refc = frames[i].refc
            if q == None or refc < q:
                q = refc
                retval = i
        return retval

def updateFrame(index, page, changed):
    global frames, OPT, OPT_largest, OPTheap
    frames[index].update(page, changed)

def printSummary():
    print("Algorithm: " + ALGORITHM)
    print("Number of frames:       " + str(NUM_FRAMES))
    print("Total memory accesses:  " + str(totalMemAccesses))
    print("Total page faults:      " + str(totalPageFaults))
    print("Total writes to disk:   " + str(totalWritesToDisk))
    #Each entry in page table is 4B
    #And we have 2^32/2^13 = 2^19 entries
    #2^19*4=2097152
    print("Total size of page table:  2097152 bytes" )

main()
    
