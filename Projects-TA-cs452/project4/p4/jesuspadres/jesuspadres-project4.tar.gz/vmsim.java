/*
 * vmsim.java -- This program is simulating the various page replacement algorithms
 * used to evict page frames when accessing memory addresses. 
 * The program can run the optimum, clock, least recently used and 
 * not frequently used algorithms to evict page frames.
 * The output shows the number of frames used, the total memory accesses,
 * total page faults, total writes to disk, and the size of the page table.
 * 
 * Author: Jesus Padres
 * Class: CSc 452
 * Instructor: Jonathan Misurda
 * Due: Apr 12 2022
 * 
 * Built using Java 8
 * 
 * USAGE:
 *	vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>
 * OR
 *	vmsim -a <opt|clock|lru|nfu> <tracefile> –n <numframes>
 *
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class vmsim {
	private static HashMap<Long, List<Integer>> optQueue = new HashMap<>();
	private static HashMap<Long, Page> frames = new HashMap<>();
	private static int accesses = 0;
	private static int pageCapacity;
	private static int pageFaults = 0;
	private static int dirtyFaults = 0;
	private static List<Page> pages;
	private static int clockSize = 0;
	private static Clock latest = null;
	private static Clock oldest = null;
	private static int time = 0;
	private static String algo;
	

	public static void main(String[] args) throws IOException {
		runInput(args);
		
		if (algo.equals("opt")) {
			optAlgorithm();
			System.out.println("\nAlgorithm: " + "OPT");
		} else if (algo.equals("clock")) {
			clockAlgorithm();
			System.out.println("\nAlgorithm: " + "CLOCK");
		} else if (algo.equals("lru")) {
			lruAlgorithm();
			System.out.println("\nAlgorithm: " + "LRU");
		} else if (algo.equals("nfu")) {
			nfuAlgorithm();
			System.out.println("\nAlgorithm: " + "NFU");
		}
		
		System.out.println("Number of frames: " + pageCapacity);
		System.out.println("Total memory accesses: " + accesses);
		System.out.println("Total page faults: " + pageFaults);
		System.out.println("Total writes to disk: " + dirtyFaults);
		System.out.println("Total size of page table: " + (pageCapacity * 8192) + " bytes");
	} 
	
	/**
	 * Method runInput
	 * 
	 * Purpose: this method reads the inputs and makes sure they are valid.
	 * It then parses the tracefile and sets up some variables we'll use
	 * in our algorithms.
	 * 
	 * Pre-condition: valid command line input
	 * 
	 * Post-condition: page replacement algorithms will be ready to execute
	 * 
	 * @param args	the command line arguments of the program
	 * 
	 * @return void
	 */
	private static void runInput(String[] args) {
		boolean validInput = true;
		if(args[0].equals("-n")) {
			try {
		        pageCapacity = Integer.parseInt(args[1]);
		    } catch (NumberFormatException nfe) {
		        validInput = false;
		    }
			
			if (args[2].equals("-a") && validInput) {
				String alg = args[3];
				if (alg.equals("opt") || alg.equals("clock") || alg.equals("lru") || alg.equals("nfu")) {
					algo = alg;
					try {
						buildMap(args[4]);
					} catch (IOException e) {
						System.out.println("Invalid trace file");
						System.exit(0);
					}
				} else {
					validInput = false;
				}
			} else {
				validInput = false;
			}
		} else if (args[0].equals("-a")) {
			
			String alg = args[1];
			if (alg.equals("opt") || alg.equals("clock") || alg.equals("lru") || alg.equals("nfu")) {
				algo = alg;
				try {
					buildMap(args[2]);
				} catch (IOException e) {
					System.out.println("Invalid trace file");
					System.exit(0);
				}
			} else {
				validInput = false;
			}
			
			if (args[3].equals("-n")) {
				try {
			        pageCapacity = Integer.parseInt(args[4]);
			    } catch (NumberFormatException nfe) {
			        validInput = false;
			    }
			} else {
				validInput = false;
			}
		} else {
			validInput = false;
		}
		
		if (validInput == false) {
			System.out.println("Invalid input");
			System.out.println("USAGE:");
			System.out.println("\t vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
			System.out.println("OR");
			System.out.println("\t vmsim -a <opt|clock|lru|nfu> <tracefile> –n <numframes>");
			System.exit(0);
		}
	}
	
	/**
	 * Method buildMap
	 * 
	 * Purpose: reads the tracefile and copies its useful information into a list, to
	 * use those memory accesses with different algorithms. In addition, this method
	 * builds a hashmap containing memory addresses as keys, and a list as its value
	 * of which holds the index/timestamp of when that memory is accessed. This 
	 * hashmap will later be used to create the optimum page replacement algorithm.
	 * 
	 * Pre-condition: file is a valid tracefile
	 * 
	 * Post-condition: pages is a list composed of Page objects of every
	 * memory access from the tracefile. optQueue is composed of
	 * memory addresses as keys, and a list as its value
	 * of which holds the index/timestamp of when that memory is accessed.
	 * 
	 * @param file a tracefile of memory references
	 * 
	 * @return void
	 */
	private static void buildMap(String file) throws IOException {
		BufferedReader br
        = new BufferedReader(new FileReader(new File(file)));
		
		pages = new ArrayList<>();
		
		String str;
	    while ((str = br.readLine()) != null) {
	    	if (str.charAt(0) == ' ' || str.charAt(0) == 'I') {
	    		if (str.charAt(0) == ' ') {
	    			str = str.substring(1);
	    		}
	    		String[] list = str.split("\\s+");
	    		list[1] = list[1].split(",")[0];
	    		pages.add(new Page(list[0].charAt(0), Long.decode("0x"+list[1])));
	    		if (!optQueue.containsKey(Long.decode("0x"+list[1]))) {
	    			optQueue.put(Long.decode("0x"+list[1]), new ArrayList<Integer>());
	    		} 
	    		optQueue.get(Long.decode("0x"+list[1])).add(accesses);
		    	accesses++;
	    	}
		}
	}
	
	/**
	 * Method optAlgorithm
	 * 
	 * Purpose: this method runs through every memory reference we stored
	 * from the tracefile and performs an eviction if there is a page fault.
	 * dealOpt describes what makes this algorithm most optimal.
	 * 
	 * Pre-condition: pages is a list composed of Page objects of every
	 * memory access from the tracefile. optQueue is composed of
	 * memory addresses as keys, and a list as its value
	 * of which holds the index/timestamp of when that memory is accessed.
	 * 
	 * Post-condition: pageFaults and dirtyFaults are populated with
	 * the appropriate information
	 * 
	 * @param 
	 * 
	 * @return void
	 */
	private static void optAlgorithm() {
		for (Page p : pages) {
			if (!frames.containsKey(p.value)) {
				pageFaults++;
				dealOpt(p);
			} else {
				System.out.println("hit");
			}
			optQueue.get(p.value).remove(0);
		}
	}
	
	/**
	 * Method dealOpt
	 * 
	 * Purpose: The optimum algorithm i created looks at the pages in the current
	 * page frames, and evicts the one that will be reused the furthest in the future.
	 * It does this by looking at the optQueue to identify when a memory address
	 * will be next seen.
	 * 
	 * Pre-condition: frames holds the current pages in the page frame. 
	 * optQueue is composed of memory addresses as keys, and a list as its value
	 * of which holds the index/timestamp of when that memory is accessed.
	 * 
	 * Post-condition: the page used furthest in the future is evicted from frames
	 * and p is now added to frames
	 * 
	 * @param p next page to add to the page frame
	 * 
	 * @return void
	 */
	private static void dealOpt(Page p) {
		if (frames.size() < pageCapacity) {
			System.out.println("page fault - no eviction");
			frames.put(p.value, p);
			return;
		} 
		
		Page furthestPage = null;
		int currDist = 0;
		
		for (Long page : frames.keySet()) {
			List<Integer> list = optQueue.get(page);
			if (list.size() == 0) {
				furthestPage = frames.get(page);
				break;
			} 
			if (list.get(0) > currDist) {
				currDist = list.get(0);
				furthestPage = frames.get(page);
			}
		}
		
		frames.remove(furthestPage.value);
		frames.put(p.value, p);
		if (furthestPage.dirty) {
			System.out.println("page fault - evict dirty");
			dirtyFaults++;
		} else {
			System.out.println("page fault - evict clean");
		}
	}
	
	/**
	 * Method clockAlgorithm
	 * 
	 * Purpose: this method runs through every memory reference we stored
	 * from the tracefile and performs an eviction if there is a page fault.
	 * dealClock further describes how this algorithm works.
	 * 
	 * Pre-condition: pages is a list composed of Page objects of every
	 * memory access from the tracefile. 
	 * 
	 * Post-condition: pageFaults and dirtyFaults are populated with
	 * the appropriate information
	 * 
	 * @param 
	 * 
	 * @return void
	 */
	private static void clockAlgorithm() {
		setClock();
		
		for (Page p : pages) {
			if (!frames.containsKey(p.value)) {
				pageFaults++;
				dealClock(p);
			} else {
				System.out.println("hit");
			}
		}
	}
	
	/**
	 * Method setClock
	 * 
	 * Purpose: builds a linked list cycle, ready to be used
	 * as page frames for the clock page replacement algorithm
	 * 
	 * Pre-condition: oldest and latest variables are created.
	 * Clock class exists to be used as a doubly linked list.
	 * 
	 * Post-condition: oldest and latest nodes are ready to be used
	 * as page frames for the clock page replacement algorithm
	 * 
	 * @param 
	 * 
	 * @return void
	 */
	private static void setClock() {
		oldest = new Clock();
		Clock curr = oldest;
		for (int i = 1; i < pageCapacity; i++) {
			curr.next = new Clock();
			curr.next.prev = curr;
			curr = curr.next;
		}
		latest = curr;
		oldest.prev = latest;
		latest.next = oldest;
		latest = latest.next;
	}
	
	/**
	 * Method dealClock
	 * 
	 * Purpose: Deals with page faults as indicated by the clock
	 * page replacement algorithm. both latest and oldest nodes 
	 * work with frames to efficiently hold the current page frames
	 * 
	 * Pre-condition: setClock() executed correctly. 
	 * frames, latest and oldest hold the current pages in the page frame.
	 * 
	 * Post-condition: p replaces a page in the frame and clock nodes
	 * 
	 * @param p next page to add to the page frame
	 * 
	 * @return void
	 */
	private static void dealClock(Page p) {
		if (clockSize < pageCapacity) {
			latest.page = p;
			latest = latest.next;
			clockSize++;
			System.out.println("page fault - no eviction");
			frames.put(p.value, p);
			return;
		}
		
		while (oldest.page.referenced) {
			oldest.page.referenced = false;
			oldest = oldest.next;
			latest = latest.next;
		}
		
		if (oldest.page.dirty) {
			System.out.println("page fault - evict dirty");
			dirtyFaults++;
		} else {
			System.out.println("page fault - evict clean");
		}
		frames.remove(oldest.page.value);
		p.referenced = true;
		
		oldest.page = p;
		oldest = oldest.next;
		latest = latest.next;
		frames.put(p.value, p);
	}
	
	/**
	 * Method lruAlgorithm
	 * 
	 * Purpose: this method runs through every memory reference we stored
	 * from the tracefile and performs an eviction if there is a page fault.
	 * dealLRU further describes how this algorithm works.
	 * 
	 * Pre-condition: pages is a list composed of Page objects of every
	 * memory access from the tracefile. 
	 * 
	 * Post-condition: pageFaults and dirtyFaults are populated with
	 * the appropriate information
	 * 
	 * @param 
	 * 
	 * @return void
	 */
	private static void lruAlgorithm() {
		for (Page p : pages) {
			if (!frames.containsKey(p.value)) {
				pageFaults++;
				dealLRU(p);
			} else {
				System.out.println("hit");
				frames.get(p.value).lastUsed = time;
			}
			time++;
		}
	}
	
	/**
	 * Method dealLRU
	 * 
	 * Purpose: Deals with page faults as indicated by the least recently used
	 * page replacement algorithm.
	 * 
	 * Pre-condition: every Page node has the value of the last time it was used.
	 * frames holds the current pages in the page frame. 
	 * 
	 * Post-condition: p replaces the least recently used page in the frame
	 * 
	 * @param p next page to add to the page frame
	 * 
	 * @return void
	 */
	private static void dealLRU(Page p) {
		p.lastUsed = time;
		if (frames.size() < pageCapacity) {
			frames.put(p.value, p);
			System.out.println("page fault - no eviction");
			return;
		}
		
		Page LRU = null;
		int lastUsed = time;
		
		for (Long key : frames.keySet()) {
			Page temp = frames.get(key);
			if (frames.get(key).lastUsed < lastUsed) {
				LRU = temp;
				lastUsed = temp.lastUsed;
			}
		}
		
		if (LRU.dirty) {
			System.out.println("page fault - evict dirty");
			dirtyFaults++;
		} else {
			System.out.println("page fault - evict clean");
		}
		frames.remove(LRU.value);
		frames.put(p.value, p);
	}
	
	/**
	 * Method nfuAlgorithm
	 * 
	 * Purpose: this method runs through every memory reference we stored
	 * from the tracefile and performs an eviction if there is a page fault.
	 * dealNFU further describes how this algorithm works.
	 * 
	 * Pre-condition: pages is a list composed of Page objects of every
	 * memory access from the tracefile. 
	 * 
	 * Post-condition: pageFaults and dirtyFaults are populated with
	 * the appropriate information
	 * 
	 * @param 
	 * 
	 * @return void
	 */
	private static void nfuAlgorithm() {
		for (Page p : pages) {
			if (!frames.containsKey(p.value)) {
				pageFaults++;
				dealNFU(p);
			} else {
				System.out.println("hit");
				frames.get(p.value).refCount++;
			}
		}
	}
	
	/**
	 * Method dealNFU
	 * 
	 * Purpose: Deals with page faults as indicated by the not frequently used
	 * page replacement algorithm.
	 * 
	 * Pre-condition: Page nodes hold a refCount that indicates how frequently
	 * that memory address has been used since it has been on the page frame.
	 * frames holds the current pages in the page frame. 
	 * 
	 * Post-condition: p replaces the least frequently used page in the frame
	 * 
	 * @param p next page to add to the page frame
	 * 
	 * @return void
	 */
	private static void dealNFU(Page p) {
		p.refCount++;
		if (frames.size() < pageCapacity) {
			frames.put(p.value, p);
			System.out.println("page fault - no eviction");
			return;
		}
		
		Page NFU = null;
		int leastUsed = Integer.MAX_VALUE;
		
		for (Long key : frames.keySet()) {
			Page temp = frames.get(key);
			if (frames.get(key).refCount < leastUsed) {
				NFU = temp;
				leastUsed = temp.refCount;
			}
		}
		
		if (NFU.dirty) {
			System.out.println("page fault - evict dirty");
			dirtyFaults++;
		} else {
			System.out.println("page fault - evict clean");
		}
		frames.remove(NFU.value);
		frames.put(p.value, p);
	}

	/**
	 * Page class
	 * 
	 * Author: Jesus Padres
	 * 
	 * Purpose: Is an instance of the page table entry
	 * 
	 */
	private static class Page {
		boolean dirty = false;			// dirty bit
		boolean referenced = true;		// referenced/unreferenced for use in clock algorithm
		Long value;						// memory address
		char type;						// S:store, M:modify, L:load
		int lastUsed;					// last time used for use in LRU algorithm
		int refCount = 0;				// number of times used since loaded on page table for use in NFU algorithm
		
		public Page(char t, Long val) {
			value = val;
			type = t;
			
			if (type == 'S' || type == 'M') {
				dirty = true;
			}
		}
	}
	
	/**
	 * Clock class
	 * 
	 * Author: Jesus Padres
	 * 
	 * Purpose: holds a page in the page frame, for use in the clock
	 * view of the page frame. A doubly linked list that will be used as a cycle, like a clock.
	 * 
	 */
	private static class Clock {
		Page page;
		Clock prev = null;
		Clock next = null;
		
		public Clock() {
			page = null;
		}
	}
	
}


