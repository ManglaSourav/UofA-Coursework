# Jesse Chen
# CSC 452 PA4
import sys
import getopt
import re

# prints error if cmd line args not correct
def printError():
    print("Error! The correct usage is:\npython3 vmsim.py –n <numframes> -a <opt|clock|lru|nfu> <tracefile>")
    sys.exit()

# returns tuple from trace file if valid line, else None
def isValidLine(line):
    l = list(filter(None,re.split(r"[^a-zA-Z0-9]",line)))
            
    if (len(l)!=3):
        return None

    inst = l[0]
    page = l[1]
    size = l[2]

    if (not inst.isupper() or not size.isdigit()):
        return None    
        
    page = int(page,16)
    return (inst,page,size)

# class MMU
class MMU:

    __msg = ["hit", "page fault - no eviction", "page fault - evict clean", "page - evict dirty"]

    def __init__(self, capacity, algo, numOffsetBits, numPageNumBits):
        # for page table
        self.__pageTable = [[0,0,0]] * (2**numPageNumBits)
        self.__pte = None # [dirty bit, referenced bit, valid bit]

        # for frame table
        self.__size = 0
        self.__frameTable = [0]*capacity
        self.__capacity = capacity
        self.__algo = algo
        self.__numOffsetBits = numOffsetBits
        self.__pageNum = -1
        self.__stats = [0,0,0] # num of mem access, page faults, disk writes
        self.__traceLineInput = None # line from trace file -> [inst, page, size]
       
        # for page replacement algos
        self.__list = []
        self.__dict = {}
        self.__clockHand = 0
        self.__opt = {}
        self.__currIndex = -1 # counts number of instructions

    # =============================================================================
    def __incrMemAccess(self, n):
        self.__stats[0] += n
    
    def __incrPageFaults(self):
        self.__stats[1] += 1

    def __incrDiskWrites(self):
        self.__stats[2] += 1

    def __getMemAccess(self):
        return self.__stats[0]

    def __getPageFaults(self):
        return self.__stats[1]

    def __getDiskWrites(self):
        return self.__stats[2]

    # =============================================================================
    # replaces page in frame
    def __replaceThisPage(self, pageToRemove):
        return [self.__pageNum if i==pageToRemove else i for i in self.__frameTable] 

    # update removed pageTableEntry and some stats
    def __generalPostProcess(self, pageToRemove):
        # update some stats and pte's
            pte = self.__pageTable[pageToRemove].copy()
            if (pte[0] == 1): # if dirty, we write to disk
                self.__incrDiskWrites()
                print(self.__msg[3])
            else:
                print(self.__msg[2])
                pass

            self.__pageTable[pageToRemove] = [0,0,0] # reset this pte
    # =============================================================================
    # runs optimal page replacing algo, as if it had perfect knowledge of future
    def __preProcessOPT(self):
        pass

    def __runOPT(self):
        maxIndex = -1
        # pageToRemove = self.__frameTable[0]
        indexToRemove = 0
        # print("----------------")
        for i, pageNum in enumerate(self.__frameTable): 
            nextIndexOfPageNum = -1
            # print("pageNum, self.pageNum: %d, %d" %(pageNum, self.__pageNum))
            # print("len: ",len(self.__opt[pageNum]))
            # if(pageNum==8216):
            #     print(self.__opt[pageNum])
            while (len(self.__opt[pageNum]) > 0 and nextIndexOfPageNum <= self.__currIndex):
                nextIndexOfPageNum = self.__opt[pageNum].pop(0)
            # print("%d should be > %d" %(nextIndexOfPageNum, self.__currIndex))
            # print("\tpageNum, nextIndexOfPageNum, maxIndex: %d, %d, %d"%(pageNum, nextIndexOfPageNum, maxIndex))
            if (nextIndexOfPageNum == -1): # means not run ever again
                pageToRemove = pageNum
                indexToRemove = i
                break
            if (nextIndexOfPageNum > maxIndex):
                maxIndex = nextIndexOfPageNum
                pageToRemove = pageNum
                indexToRemove = i

        self.__frameTable[indexToRemove] = self.__pageNum # replace page in frame
        self.__generalPostProcess(pageToRemove)
   
    # =============================================================================
    # better implementation of the second-chance algorithm
    def __preProcessClock(self):
        pass

    def __runClock(self):
        for i in range(self.__size):
            i = (i+self.__clockHand) % self.__size
            pageToRemove = self.__frameTable[i]
            if(self.__pageTable[pageToRemove][1] == 0): # if R=0, then evict
                self.__frameTable[i] = self.__pageNum # replace with new page num
                self.__clockHand = (i+1) % self.__size # advance clockhand
                break
            else:
                self.__pageTable[pageToRemove][1] = 0 # clear bit

        self.__generalPostProcess(pageToRemove)

    # =============================================================================
    # evict the least recently used page
    # least recently used as head
    # most recently used as tail
    def __preProcessLRU(self):
        if (self.__pageNum in self.__list): # if page is in the list,
            self.__list.remove(self.__pageNum) # remove it
        
        self.__list.append(self.__pageNum) # insert page as mru (tail)

    def __runLRU(self):
        self.__preProcessLRU()

        pageToRemove = self.__list.pop(0) # get LRU (head)
        self.__frameTable = self.__replaceThisPage(pageToRemove) # replace page in frame table

        self.__generalPostProcess(pageToRemove)

    # =============================================================================
    # evict least referenced page 
    def __preProcessNFU(self):
        n = 1
        if (self.__inst == "M"):
            n = 2

        if(self.__dict.get(self.__pageNum)):
            self.__dict.update({self.__pageNum : self.__dict.get(self.__pageNum) + 1})
        else:
            self.__dict[self.__pageNum] = n
        
    def __runNFU(self):

        if (len(self.__dict) != 0):
            # maxIndex = min(self.__dict.values()) # page to remove is LFU
            # keys = [key for key, value in self.__dict.items() if value == maxIndex]
            # pageToRemove = min(keys)
            pageToRemove = min(self.__dict, key = self.__dict.get) # page to remove is LFU

            # remove LFU from dict and store in other dict
            # self.__dictNotInFrame[pageToRemove] = self.__dict.pop(pageToRemove)
            self.__dict.pop(pageToRemove)
            self.__frameTable = self.__replaceThisPage(pageToRemove) # replace page in frame

        self.__preProcessNFU() # update page ref counts

        self.__generalPostProcess(pageToRemove)

    # =============================================================================
    # choose desired page replacing algo based on cmd line input
    def __replacePagePreProcess(self):
        if (self.__algo == "opt"):
            self.__preProcessOPT()
        elif (self.__algo == "clock"):
            self.__preProcessClock()
        elif (self.__algo == "lru"):
            self.__preProcessLRU()
        elif (self.__algo == "nfu"):
            self.__preProcessNFU()

    # choose desired page replacing algo based on cmd line input
    def __replacePage(self):
        if (self.__algo == "opt"):
            self.__runOPT()
        elif (self.__algo == "clock"):
            self.__runClock()
        elif (self.__algo == "lru"):
            self.__runLRU()
        elif (self.__algo == "nfu"):
            self.__runNFU()

    # returns true if frame is full
    def __isFrameTableFull(self):
        return self.__size == self.__capacity
    
    # extracts info from line from trace file -> [inst, page, size]
    def __getFromTraceLineInput(self, traceLineInput):
        self.__inst = traceLineInput[0]
        self.__pageNum = traceLineInput[1] >> self.__numOffsetBits
        # size is unused (not the frameTable size)

    # sets current page table entry (and some other data structures)
    def __setPageTableEntry(self):
        self.__pte = self.__pageTable[self.__pageNum].copy()

    def __updateCounts(self):
        if (self.__inst=="I"):
            self.__incrMemAccess(1) # update num mem access
        elif (self.__inst=="L"):
            self.__incrMemAccess(1)
            self.__pte[1] = 1 # set referenced bit 
        elif (self.__inst=="S"):
            self.__incrMemAccess(1)
            self.__pte[0] = 1 # set dirty bit 
            self.__pte[1] = 1 # set referenced bit 
        elif (self.__inst=="M"): # load->store 
            self.__incrMemAccess(2)
            self.__pte[0] = 1 # set dirty bit
            self.__pte[1] = 1 # set referenced bit 

        if (self.__pte[2] == 0): # if page is not valid
           self.__incrPageFaults() # update num page faults
        
    def __preProcess(self, traceLineInput):
        self.__getFromTraceLineInput(traceLineInput)
        self.__setPageTableEntry()
        self.__updateCounts()
        self.__currIndex += 1
        # print("currIndex, pageNum: %d, %d " %(self.__currIndex, self.__pageNum))

    def __postProcess(self):
        self.__pageTable[self.__pageNum] = self.__pte.copy()

    # add page to frame table
    def addPage(self, traceLineInput):
        self.__preProcess(traceLineInput)

        if (self.__pageNum not in self.__frameTable):
            if (self.__isFrameTableFull()):
                self.__replacePage()
            else:
                self.__replacePagePreProcess()
                self.__frameTable[self.__size] = self.__pageNum
                self.__size += 1
                print(self.__msg[1])
        else:        
            print(self.__msg[0])

        self.__pte[2] = 1 # set valid bit
        self.__postProcess()

    def printFrameTable(self):
        print(self.__frameTable)
    
    def printOptTable(self):
        print(self.__opt)
    
    def printOptEntry(self,pageNum):
        print(self.__opt[pageNum])
    
    def initOptDict(self, traceLineInput, currIndex):
        self.__getFromTraceLineInput(traceLineInput)
        try:
            self.__opt[self.__pageNum].append(currIndex)
        except:
            self.__opt[self.__pageNum] = [currIndex]

    def getCurrPageNum(self):
        return self.__pageNum
    # Prints the following
    # Algorithm: %s
    # Number of frames:       %d
    # Total memory accesses:  %d
    # Total page faults:      %d
    # Total writes to disk:   %d
    def printStats(self):
        print()
        print("Algorithm:\t\t", self.__algo)
        print("Number of frames:\t", self.__capacity)
        print("Total memory accesses:\t", self.__getMemAccess())
        print("Total page faults:\t", self.__getPageFaults())
        print("Total writes to disk:\t", self.__getDiskWrites())
        pageTableSize = (2**32)/(2**self.__numOffsetBits)*(2**2) # 4 bytes = 32 bits
        print("Total size of page table:\t%d bytes" %(pageTableSize))
        print()

# main
if __name__ == "__main__":

    # read in cmd line args
    try: 
        opts, args = getopt.getopt(sys.argv[1:],"n:a:")
    except getopt.GetoptError:
        printError()

    if (len(args)!=1 or len(opts)!=2):
        printError()
       
    # get all cmd line args
    numFrames = int((opts[0])[1])
    algo = (opts[1])[1]
    traceFile = args[0]

    # bit shift values
    numOffsetBits = 13
    numPageNumBits = 19

    # create MMU object
    myMMU = MMU(numFrames, algo, numOffsetBits, numPageNumBits)

    # open and parse trace file
    with open(traceFile) as f:
        # create dict for opt, if opt
        if (algo == "opt"):
            nextIndexOfPageNum = 0
            for line in f:
                l = isValidLine(line)
                if (l is not None):
                    myMMU.initOptDict(l,nextIndexOfPageNum)
                    nextIndexOfPageNum += 1
            # myMMU.printOptTable()

    # open and parse trace file
    with open(traceFile) as f:
        # run main part of program, i.e. adding pages
        for line in f:
            l = isValidLine(line)
            if (l is not None):
                myMMU.addPage(l)

    myMMU.printStats()
