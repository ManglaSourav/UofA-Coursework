'''
This is the improved algorithm of the second chance algorithm
It uses a ciruclar queue instead of a regular queue

I am simulating the circular queue as a regular list but when I iterate through it:
    I use count % len(list) so I stay in the range until I find an unrefrenced page

kick out oldest unreferenced page

PTE = (D, R, V, frame#)


'''
from basics import *


class NFU:
    def __init__(self, num_frames, alg, tracefile, page_size, page_table, stats):
        self.num_frames = num_frames
        self.page_table = page_table

        self.stats = stats
        self.tracefile = tracefile
        
        self.elements = []
    
    def evict(self, new, bits):
        count = 0
        while(True):
            #check if unreferenced
            #oldest is in the front
            index = count % len(self.elements)
            page_num_curr = self.elements[ index ]
            PTE_curr = self.page_table[page_num_curr]
            frame_num = PTE_curr[3]
            #(D, R, V, Frame#)
            if(PTE_curr[1] == 0):
                print(f'EVICT: {page_num_curr} is not referenced')
                #kick this one out
                if(PTE_curr[0] == 1):
                    #needs to be written to disk
                    print(f'EVICT:{page_num_curr} write to disk')
                    self.stats['Total writes to disk']+=1

                PTE_curr = (0, 0, 0, 0)
                self.page_table[page_num_curr] = PTE_curr

                #Replace
                PTE = self.page_table[new]
                PTE = (bits[0], bits[1], bits[2], frame_num)
                self.page_table[new] = PTE
                print(f'EVICT: replace {page_num_curr} with {new}: {self.elements} -> ')
                self.elements[index] = new
                print(self.elements)
                return
            else:
                #unreference curr page
                PTE_curr = (PTE_curr[0], 0, PTE_curr[2], PTE_curr[3])
                self.page_table[page_num_curr] = PTE_curr

            count+=1
        r


    def CLOCK_page_fault(self, virtual_address, PTE, bits=(0, 1, 1)):
        '''This Frame hasn't been used yet
        '''
        #1) Determine faulting VA
        print(f'PAGE_FAULT CLOCK: Frame is invalid')
        page_num = virtual_address >> 13
        new = page_num
        self.stats["Total page faults"]+=1
        
        print(f'PAGE_FAULT CLOCK: trying to add {new} to {self.elements}')
        #2) If request is bad ?  -> I shouldn't care about this because I am not simulating OS
            
        #3) if request is good: I checked there are empty frames already
        if(self.num_frames <= 0):
            print(f'CLOCK: replace oldest unreferenced with: {new}')
            
            self.evict(new, bits)
            return
        if (new in self.elements):
            print(f'node already exists')
            return

        self.elements.append(new)

        #3A) Find empty frame
        frame_num = self.num_frames
        self.num_frames-=1
            
        

            #3B)Load page from disk --> I am not simulating OS -> Don't need it
        #3C) Update table 
        PTE = self.page_table[page_num]
        PTE = (bits[0], bits[1], bits[2], frame_num)
        self.page_table[new] = PTE
        

        
    def simulate_CLOCK(self, instruction, virtual_address):
        '''
        For this assg we only have 4 instructions:
        1) I -> fetches an instruction from disk
        2) S -> stores data at address (address) of size (size)
        3) L -> Load data at address (address, should be an address space) of size (size)
        4) M -> Modify data at address (should be an address space) of size (size)
        stats to care about:
        'Total memory accesses':  0,
        'Total page faults':      0,
        'Total writes to disk':   0,
        '''
        print(f'\n\n-------------------------')
        print(f'{instruction} 0x{virtual_address}')
        PTE = MMU(virtual_address, self.page_table)
        V = PTE[2] #>> 29
        R = PTE[1] #>> 30
        D = PTE[0] #>> 31
        print(f'D: {D}, R: {R}, V: {V}')
        print(f'Available Frames {self.num_frames}')
        
        if(instruction == 'I'):
            #instruction fetch
            #Must put page into RAM
            #and set it as referenced
            #       D, R, V
            #If instruction is in RAM then no page fault
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (0, 1, 1)
                self.CLOCK_page_fault(virtual_address, PTE, bits=bits)
                
            else:
                #change reference page to 1
                #not sure what to do?
                PTE = (D, 1, V, PTE[3])
                self.page_table[virtual_address>>13] = PTE
                print(f"'I': LRU: Fethcing a valid page| changed R=1\n\tVirtual_address: {virtual_address}, Frame# = {PTE[3]}")
            return 0

        if(instruction == 'S'):
            #set Dirty to 1 while keeping the other two as they are
            #should make sure that page is in RAM and is referenced
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (1, 1, 1)
                self.CLOCK_page_fault(virtual_address, PTE, bits=bits)
            else:
                #set Dirty to 1 while keeping the other two as they are
                #set reference bit to 1
                PTE = (1, 1, V, PTE[3])
                page_num = virtual_address >> 13
                self.page_table[page_num] = PTE
            
            return 0 

        if(instruction == 'L'):
            '''Works as lw
            loads some data to the page
            '''
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (1, 1, 1)
                self.CLOCK_page_fault(virtual_address, PTE, bits=bits)
            else:
                PTE = (D, 1, V, PTE[3])
                self.page_table[virtual_address>>13] = PTE
                print(f"'L' LRU: Loading from a valid Page| set R =1\n\tVirtual_address: {virtual_address}, Frame# = {PTE[3]}")
            return 0 
        if(instruction == 'M'):
            #because it is both load and store
            self.stats['Total memory accesses']+=2
            if(V == 0):
                bits = (1, 1, 1)
                self.CLOCK_page_fault(virtual_address, PTE, bits=bits)
            else:
                #set Dirty to 1 while keeping the other two as they are
                PTE = (1, 1, V, PTE[3])
                page_num = virtual_address >> 13
                self.page_table[page_num] = PTE
            return 0 

    

    def read_tracefile_CLOCK(self):
        '''
        This function reads the contents of the specified tracefile and simulate the commands

        Create a table with num_pages indexes -> page_table -> each index continue -1
        When read instruction:
            check is_in_table() -> calc physical address, make sure it is not -1 
            if (num_frames > 0):
                page_table[page_num] = num_frames
                num_frames-=1

        
        '''
        
        with open(self.tracefile, 'r+') as file:
            for line in file:
                #non instruction cases
                
                if(line.startswith('==') or line.startswith('--') or
                line.startswith('-') or line.startswith('total')):
                    #ignore
                    print(f'WARNING: skipped: {line}')
                    continue
                #process
                # Instruction address, size
                
                parts = line.split()
                
                instruction = parts[0]

                add_size = parts[1].split(',')
                address= int(f'0x{add_size[0]}', 16)
                size = add_size[1]
                
                self.simulate_CLOCK(instruction, address)
                
                
    def print_queue(self):
        curr = self.head
        q_str = 'Queue:\n'
        if(curr == None):
            q_str+='No elements in list'
            print(q_str)
            return
        
        count = 0
        print(self.elements)
        while count < len(self.elements):
            print(curr)
            q_str+= f'{curr} -> '
            curr = curr.next
            count+=1
        print(q_str)
        return
            
    def __str__(self):
        return f'''
    Algorithm: {self.stats['Algorithm']}
    Number of frames:       {self.stats['Number of frames']}
    Total memory accesses:  {self.stats['Total memory accesses']}
    Total page faults:      {self.stats['Total page faults']}
    Total writes to disk:   {self.stats['Total writes to disk']}
    Total size of page table: {self.stats['Total size of page table']} bytes
    '''



