'''
The least recently used uses a queue.

Front is recently used
    Add to front
    As you are adding make sure to not have duplicates
        if duplicate found-> move it to front

Back is not recently used
    Remove from back

'''
from basics import *

class LRU:
    def __init__(self, num_frames, algo, tracefile, page_size, page_table, stats):
        self.num_frames = num_frames
        self.algo = algo
        self.tracefile = tracefile
        self.page_size = page_size
        self.page_table = page_table
        self.stats = stats
        self.q = []
    def enqueue(self, page_num):
        '''
        adds element to the front of list O(N)
        '''
        q =self.q
        for i, page in enumerate(q):
            if(page == page_num):
                #must remove from here and add to front
                q.pop(i)
                return [page]+q     
        return [page_num]+q

    def LRU_evict(self, new_page_num):
        '''
        Simulates evicting a process using LRU algorithm
        The least used page is the one in the end of the queue
        '''
        #get last least_page_number
        #then clear page_table[least_page_number] => frame#
        '''
        (D, R, V)
        Check if dirty => increment "Total writes to disk"
        Don't change referenced
        Turn Valid to 0
        '''
        #page_table[new_page_number] = frame#
        if(len(self.q) == 0):
            print(f'ERR: queue len is 0')
            exit()
        least_page_num = self.q.pop()
        #(0, 0, 0, Frame#)
        least_PTE = self.page_table[least_page_num]
        least_D = least_PTE[0]
        frame_num = least_PTE[3]
        if(least_D == 1):
            #must rewrite to disk
            self.stats["Total writes to disk"]+=1
        self.page_table[new_page_num] = (0, 1, 1, frame_num)
        self.q = self.enqueue(new_page_num)
        self.page_table[least_page_num] = (0, 0, 0, 0)
        




    def LRU_page_fault(self, virtual_address, PTE, bits=(0, 1, 1)):
        '''This Frame hasn't been used yet
        '''
        #1) Determine faulting VA
        page_num = virtual_address >> 13

        #2) If request is bad ?  -> I shouldn't care about this because I am not simulating OS
            
        #3) if request is good: I checked there are empty frames already
        print(f'PAGE_FAULT LRU: Frame is invalid')
        print(f'curr q = {self.q}')
        self.stats['Total page faults']+=1
        
        V = bits[2] #<< 29
        R = bits[1] #<< 30
        D = bits[0] #<< 31


        #3A) Find empty frame
        if(self.num_frames <= 0):
            print(f'EVICT: {PTE}')
            self.LRU_evict(page_num)
            return
            
        Frame_n = self.num_frames

            #3B)Load page from disk --> I am not simulating OS -> Don't need it
            #3C) Update table 
        PTE = (D,R,V, Frame_n)
        
        
        self.q = self.enqueue(page_num)
        print(f'PAGE_FAULT LRU: q = {self.q}')
        self.page_table[page_num] = PTE
        self.num_frames -= 1
        
    def simulate_LRU(self, instruction, virtual_address):
        '''
        For this assg we only have 4 instructions:
        1) I -> fetches an instruction from disk
        2) S -> stores data at address (address) of size (size)
        3) L -> Load data at address (address, should be an address space) of size (size)
        4) M -> Modify data at address (should be an address space) of size (size)
        stats to care about:
        'Total memory accesses':  0,
        'Total page faults':      0,
        'Total writes to disk':   0,
        '''
        print(f'\n\n-------------------------')
        print(f'{instruction} 0x{virtual_address}')
        PTE = MMU(virtual_address, self.page_table)
        V = PTE[2] #>> 29
        R = PTE[1] #>> 30
        D = PTE[0] #>> 31
        print(f'D: {D}, R: {R}, V: {V}')
        print(f'Available Frames {self.num_frames}')
        
        if(instruction == 'I'):
            #instruction fetch
            #Must put page into RAM
            #and set it as referenced
            #       D, R, V
            #If instruction is in RAM then no page fault
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (0, 1, 1)
                self.LRU_page_fault(virtual_address, PTE, bits=bits)
                
            else:
                #change reference page to 1
                #not sure what to do?
                PTE = (D, 1, V, PTE[3])
                self.page_table[virtual_address>>13] = PTE
                print(f"'I': LRU: Fethcing a valid page| changed R=1\n\tVirtual_address: {virtual_address}, Frame# = {PTE[3]}")
            return 0

        if(instruction == 'S'):
            #set Dirty to 1 while keeping the other two as they are
            #should make sure that page is in RAM and is referenced
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (1, 1, 1)
                self.LRU_page_fault(virtual_address, PTE, bits=bits)
            else:
                #set Dirty to 1 while keeping the other two as they are
                #set reference bit to 1
                PTE = (1, 1, V, PTE[3])
                page_num = virtual_address >> 13
                self.page_table[page_num] = PTE
            
            return 0 

        if(instruction == 'L'):
            '''Works as lw
            loads some data to the page
            '''
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (1, 1, 1)
                self.LRU_page_fault(virtual_address, PTE, bits=bits)
            else:
                PTE = (D, 1, V, PTE[3])
                self.page_table[virtual_address>>13] = PTE
                print(f"'L' LRU: Loading from a valid Page| set R =1\n\tVirtual_address: {virtual_address}, Frame# = {PTE[3]}")
            return 0 
        if(instruction == 'M'):
            #because it is both load and store
            self.stats['Total memory accesses']+=2
            if(V == 0):
                bits = (1, 1, 1)
                self.LRU_page_fault(virtual_address, PTE, bits=bits)
            else:
                #set Dirty to 1 while keeping the other two as they are
                PTE = (1, 1, V, PTE[3])
                page_num = virtual_address >> 13
                self.page_table[page_num] = PTE
            return 0 


        
            

        
    

    def read_tracefile_LRU(self):
        '''
        This function reads the contents of the specified tracefile and simulate the commands

        Create a table with num_pages indexes -> page_table -> each index continue -1
        When read instruction:
            check is_in_table() -> calc physical address, make sure it is not -1 
            if (num_frames > 0):
                page_table[page_num] = num_frames
                num_frames-=1

        
        '''
        
        with open(self.tracefile, 'r+') as file:
            for line in file:
                #non instruction cases
                
                if(line.startswith('==') or line.startswith('--') or
                line.startswith('-') or line.startswith('total')):
                    #ignore
                    print(f'WARNING: skipped: {line}')
                    continue
                #process
                # Instruction address, size
                
                parts = line.split()
                
                instruction = parts[0]

                add_size = parts[1].split(',')
                address= int(f'0x{add_size[0]}', 16)
                size = add_size[1]
                
                self.simulate_LRU(instruction, address)


    def __str__(self):
        return f'''
    Algorithm: {self.stats['Algorithm']}
    Number of frames:       {self.stats['Number of frames']}
    Total memory accesses:  {self.stats['Total memory accesses']}
    Total page faults:      {self.stats['Total page faults']}
    Total writes to disk:   {self.stats['Total writes to disk']}
    Total size of page table: {self.stats['Total size of page table']} bytes
    '''
                
                

    


