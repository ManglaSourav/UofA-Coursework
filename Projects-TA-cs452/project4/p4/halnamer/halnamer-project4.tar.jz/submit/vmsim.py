#!/usr/bin/python3
from os import stat
import sys

from LRU import *
from CLOCK import *
from OPT import *
from NFU import *


def main():
    '''
    Read terminal input and run the rest of the progrma
    '''
    argv = sys.argv
    #parse command line args
    if(len(argv) < 6): 
        print( "Err: Invalid number of arguments", file=sys.stderr)
        return -1
    
    vmsim = (argv[0])
    arg1 = (argv[1])
    param1 = (argv[2])
    arg2 = (argv[3])
    param2 = (argv[4])
    tracefile = (argv[5])
    page_size = (2**3)*(2**10) #8KB
    #choose ordering
    
    if(arg1 == '-n'):
        num_frames =  int(param1)
        alg = param2
    else:
        num_frames =  int(param1)
        alg = param1
    #           32bit VA = 2**32 // 8KB = (2**3) * 2**10 = 2**19
    num_pages = ((2**32) // page_size)
    #               D, R, V, Frame#
    page_table = [(0, 0, 0, 0)] * num_pages
    stats = {
        'Algorithm': alg,
        'Number of frames':     num_frames,
        'Total memory accesses':  0,
        'Total page faults':      0,
        'Total writes to disk':   0,
        #                           H * W
        'Total size of page table': num_pages * 2**2
    }
    algorithm = None
    if(alg == 'lru'):
        algorithm = LRU(num_frames, alg, tracefile, page_size, page_table, stats)
        algorithm.read_tracefile_LRU()
    elif(alg == 'clock'):
        algorithm = CLOCK(num_frames, alg, tracefile, page_size, page_table, stats)
        algorithm.read_tracefile_CLOCK()

    elif(alg == 'opt'):
        algorithm = OPT(num_frames, alg, tracefile, page_size, page_table, stats)
        algorithm.read_tracefile_OPT()
    elif(alg == 'nfu'):
        algorithm = NFU(num_frames, alg, tracefile, page_size, page_table, stats)
        algorithm.read_tracefile_OPT()

    print(algorithm)
    

    
if __name__ == "__main__":
    main()