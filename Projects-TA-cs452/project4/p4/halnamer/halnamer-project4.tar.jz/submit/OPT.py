'''
This is the improved algorithm of the second chance algorithm
It uses a ciruclar queue instead of a regular queue

I am simulating the circular queue as a regular list but when I iterate through it:
    I use count % len(list) so I stay in the range until I find an unrefrenced page

kick out oldest unreferenced page

PTE = (D, R, V, frame#)


'''
from basics import *


class OPT:
    def __init__(self, num_frames, alg, tracefile, page_size, page_table, stats):
        self.num_frames = num_frames
        self.page_table = page_table

        self.stats = stats
        self.tracefile = tracefile
        
        self.elements = []
        #table that documents when each page is used

        self.use_table = [0] * len(self.page_table)

    def search(self, invoke_times, time):
        '''
        returns the range where I should search
        '''
        is_found = False
        
        lower_bound = 0
        higher_bound = len(invoke_times)
        #print(f'considering: {invoke_times[lower_bound:higher_bound]}')
        
        while(not is_found):
            range = higher_bound - lower_bound
            if(range < 0):
                print(f'ERR: search is bad')
                return (-1, -1)
            midpoint = range // 2
            
            if(time <= invoke_times[midpoint]):
                print(f'{time} <= {invoke_times[midpoint]}')
                is_found = True
                return (midpoint, higher_bound)
        
            if(time > invoke_times[midpoint]):
                lower_bound = midpoint
                higher_bound = higher_bound

        
              
        
        

    def evict(self, time, new, bits):
        print(f'-----------------Evict--------------------')
        #optimal lenght from this instruction = candidate page - curr instruction time
        opt_len = 0
        opt_page = 0
        opt_index = 0
        print(self.elements)
        for candidate_index, candidate in enumerate(self.elements):
            
            candidate_invoke_times = self.use_table[candidate]
            print(f'curr time: {time} - working on {candidate} ß')
            range = self.search(candidate_invoke_times, time)
            if(range == (-1, -1)):
                print(f'Err: something terrible with bound search')
                exit()
            for invoke_time in candidate_invoke_times[range[0]: range[1]]:

                duration_until_next_invocation = invoke_time - time
                print(f'duration_until_next_invocation: {duration_until_next_invocation}')
                if(duration_until_next_invocation > 0):
                    if(duration_until_next_invocation > opt_len):
                        opt_len = duration_until_next_invocation
                        opt_page = candidate
                        opt_index = candidate_index
                    break

        #kick out the furthes which is opt_page
        PTE_old = self.page_table[opt_page]
        frame_num = PTE_old[3]
        if(PTE_old[0] == 1):
            self.stats['Total writes to disk']+=1
        PTE_old = (0, 0, 0, 0)
        self.page_table[opt_page] = PTE_old

        PTE_new = self.page_table[new]
        PTE_new = (bits[0], bits[1], bits[2], frame_num)
        self.page_table[new] = PTE_new


        #remove from list and replace with new
        self.elements[opt_index] = new
        return

                    



    def OPT_page_fault(self, time, virtual_address, PTE, bits=(0, 1, 1)):
        '''This Frame hasn't been used yet
        '''
        #1) Determine faulting VA
        #print(f'PAGE_FAULT OPT: Frame is invalid')
        page_num = virtual_address >> 13
        new = page_num
        self.stats["Total page faults"]+=1
        
        #print(f'PAGE_FAULT OPT: trying to add {new} to {self.elements}')
        #2) If request is bad ?  -> I shouldn't care about this because I am not simulating OS
            
        #3) if request is good: I checked there are empty frames already
        if(self.num_frames <= 0):
            #print(f'CLOCK: replace oldest unreferenced with: {new}')
            
            self.evict(time, new, bits)
            return
        if (new in self.elements):
            #print(f'node already exists')
            return

        self.elements.append(new)

        #3A) Find empty frame
        frame_num = self.num_frames
        self.num_frames-=1
            
        

            #3B)Load page from disk --> I am not simulating OS -> Don't need it
        #3C) Update table 
        PTE = self.page_table[page_num]
        PTE = (bits[0], bits[1], bits[2], frame_num)
        self.page_table[new] = PTE
        

        
    def simulate_OPT(self, time, instruction, virtual_address):
        '''
        For this assg we only have 4 instructions:
        1) I -> fetches an instruction from disk
        2) S -> stores data at address (address) of size (size)
        3) L -> Load data at address (address, should be an address space) of size (size)
        4) M -> Modify data at address (should be an address space) of size (size)
        stats to care about:
        'Total memory accesses':  0,
        'Total page faults':      0,
        'Total writes to disk':   0,
        '''
        #print(f'\n\n-------------------------')
        #print(f'{instruction} 0x{virtual_address}')
        PTE = MMU(virtual_address, self.page_table)
        V = PTE[2] #>> 29
        R = PTE[1] #>> 30
        D = PTE[0] #>> 31
        #print(f'D: {D}, R: {R}, V: {V}')
        #print(f'Available Frames {self.num_frames}')
        
        if(instruction == 'I'):
            #instruction fetch
            #Must put page into RAM
            #and set it as referenced
            #       D, R, V
            #If instruction is in RAM then no page fault
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (0, 1, 1)
                self.OPT_page_fault(time, virtual_address, PTE, bits=bits)
                
            else:
                #change reference page to 1
                #not sure what to do?
                PTE = (D, 1, V, PTE[3])
                self.page_table[virtual_address>>13] = PTE
                #print(f"'I': LRU: Fethcing a valid page| changed R=1\n\tVirtual_address: {virtual_address}, Frame# = {PTE[3]}")
            return 0

        if(instruction == 'S'):
            #set Dirty to 1 while keeping the other two as they are
            #should make sure that page is in RAM and is referenced
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (1, 1, 1)
                self.OPT_page_fault(time, virtual_address, PTE, bits=bits)
            else:
                #set Dirty to 1 while keeping the other two as they are
                #set reference bit to 1
                PTE = (1, 1, V, PTE[3])
                page_num = virtual_address >> 13
                self.page_table[page_num] = PTE
            
            return 0 

        if(instruction == 'L'):
            '''Works as lw
            loads some data to the page
            '''
            self.stats['Total memory accesses']+=1
            if(V == 0):
                bits = (1, 1, 1)
                self.OPT_page_fault(time, virtual_address, PTE, bits=bits)
            else:
                PTE = (D, 1, V, PTE[3])
                self.page_table[virtual_address>>13] = PTE
                #print(f"'L' LRU: Loading from a valid Page| set R =1\n\tVirtual_address: {virtual_address}, Frame# = {PTE[3]}")
            return 0 
        if(instruction == 'M'):
            #because it is both load and store
            self.stats['Total memory accesses']+=2
            if(V == 0):
                bits = (1, 1, 1)
                self.OPT_page_fault(time, virtual_address, PTE, bits=bits)
            else:
                #set Dirty to 1 while keeping the other two as they are
                PTE = (1, 1, V, PTE[3])
                page_num = virtual_address >> 13
                self.page_table[page_num] = PTE
            return 0 

    
    def create_use_table(self):
        with open(self.tracefile, 'r+') as file:
            for i, line in enumerate(file.readlines()):
                #non instruction cases
                
                if(line.startswith('==') or line.startswith('--') or
                line.startswith('-') or line.startswith('total')):
                    #ignore
                    #print(f'WARNING: skipped: {line}')
                    continue
                #process
                # Instruction address, size
                
                parts = line.split()
                
                add_size = parts[1].split(',')
                address= int(f'0x{add_size[0]}', 16)

                page_num = address >> 13
                if(self.use_table[page_num] == 0):
                    self.use_table[page_num] = [i]
                else:
                    self.use_table[page_num].append(i)



    def read_tracefile_OPT(self):
        '''
        This function reads the contents of the specified tracefile and simulate the commands

        Create a table with num_pages indexes -> page_table -> each index continue -1
        When read instruction:
            check is_in_table() -> calc physical address, make sure it is not -1 
            if (num_frames > 0):
                page_table[page_num] = num_frames
                num_frames-=1

        
        '''
        self.create_use_table()
        
        with open(self.tracefile, 'r+') as file:
            for i, line in enumerate(file.readlines()):
                #non instruction cases
                
                if(line.startswith('==') or line.startswith('--') or
                line.startswith('-') or line.startswith('total')):
                    #ignore
                    #print(f'WARNING: skipped: {line}')
                    continue
                #process
                # Instruction address, size
                
                parts = line.split()
                
                instruction = parts[0]

                add_size = parts[1].split(',')
                address= int(f'0x{add_size[0]}', 16)
                size = add_size[1]
                
                self.simulate_OPT(i, instruction, address)
                
                
    def print_queue(self):
        curr = self.head
        q_str = 'Queue:\n'
        if(curr == None):
            q_str+='No elements in list'
            print(q_str)
            return
        
        count = 0
        print(self.elements)
        while count < len(self.elements):
            print(curr)
            q_str+= f'{curr} -> '
            curr = curr.next
            count+=1
        print(q_str)
        return
            
    def __str__(self):
        return f'''
    Algorithm: {self.stats['Algorithm']}
    Number of frames:       {self.stats['Number of frames']}
    Total memory accesses:  {self.stats['Total memory accesses']}
    Total page faults:      {self.stats['Total page faults']}
    Total writes to disk:   {self.stats['Total writes to disk']}
    Total size of page table: {self.stats['Total size of page table']} bytes
    '''



