

err = open('err.txt', 'w+')
def hex_to_decimal(address):
    return int(address, 16)

def MMU(virtual_address, page_table=[]):
    '''
    The virtual_address is given by the instruction
    The page_table is instatiated at the main and passed to simulate then passed here
    page_size is read in main and passed to simulate then passed here
    '''
    #virtual_address = hex_to_decimal(virtual_address)
    page_num = virtual_address >> 13 #should be bit shifting
    #offset = virtual_address & 2**12 #should be bit shifting 
    #we don't need the offset in this project
    if(page_num > len(page_table)):
        #print(f'ERR: page_num = {page_num}, len(table) = {len(page_table)}')
        return
    
    #print(f"MMU: page_table[page_num]= {page_table[page_num]}")
    PTE = page_table[page_num] 
    frame_num = page_table[page_num][3] 
    physical_address = frame_num << 13 
    
    return PTE

"""
def page_fault(virtual_address, PTE, stats, page_table, num_frames, bits=(0, 1, 1)):
    '''This Frame hasn't been used yet
    '''
    #1) Determine faulting VA
    #2) If request is bad ?  -> I shouldn't care about this because I am not simulating OS
        
    #3) if request is good: I checked there are empty frames already
    print(f'PAGE_FAULT: Frame is invalid')
    stats['Total page faults']+=1
    V = bits[2] #<< 29
    R = bits[1] #<< 30
    D = bits[0] #<< 31
    #3A) Find empty frame
    if(num_frames['#Frames'] <= 0):
        print(f'EVICT: {PTE}')
        evict(D, PTE)
        return
        
    Frame_n = num_frames['#Frames']
        #3B)Load page from disk --> I am not simulating OS -> Don't need it
        #3C) Update table 
    PTE = (D,R,V, Frame_n)
    
    page_num = virtual_address >> 13
    page_table[page_num] = PTE
    num_frames['#Frames'] -= 1
    

"""