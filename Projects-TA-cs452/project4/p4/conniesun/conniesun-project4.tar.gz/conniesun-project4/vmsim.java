import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;

import java.io.FileNotFoundException;

/*
 * Author: Connie Sun
 * Course: CSC 452 Spring 2022, Prof. Misurda
 * 
 * This class runs the VMSim program. It takes as input some number
 * of frames to simulate the size of RAM, a page replacemtn algorithm,
 * and a memory tracefile. The four supported algorithms are:
 *  - opt: optimal algorithm that uses perfect knowledge of the future
 *  - clock: second-chance algorithm using circular queue implementation
 *  - lru: evict the least recently used page
 *  - nfu: evict the least frequently used page since load
 * The VMSim program collects statistics about performance during the 
 * simulation: total memory accesses, number of page faults, and number
 * of writes to disk. 
 * 
 * Assumptions: all pages are 8KB in size, assume 32-bit address space
 * Usage: VMSim -n <numFrames> -a <opt|clock|lru|nfu> <tracefile>
 * 
 */

class vmsim{
    // the four algorithms that are implemented
    static final ArrayList<String> algs = new ArrayList<String>() {{
        add("opt"); add("clock"); add("lru"); add("nfu");
    }};

    // all pages are 8KB in size, assume 32-bit address space
    final static int PAGE_SIZE = 1 << 13;
    final static int NUM_PAGES = 1 << (32 - 13);
    // global statistics
    static int numPageFaults = 0;
    static int numWrites = 0;
    static int numAcc = 0;
    // global variables for simulation
    static ArrayList<PTEntry> pageTable;
    static FrameTable frameTable;
    static String alg;
    // for clock alg, track the head of the clock
    static int clockHead = 0;
    // for opt alg, use a list of lists to track all
    // times that pages are referenced
    static ArrayList<ArrayList<Integer>> refList;

    /* 
     * An entry in the page table, which is also stored in the
     * frames of the frame table.
     * 
     * Ints to track the the page number (index into page table),
     * number of references, and timestamp of last reference
     * (the memory access count). Booleans to track dirty and valid.
     */
    static class PTEntry {
        int referenced, pageNo, timestamp;
        boolean dirty, valid;

        /*
         * Constructor -- initially unreferenced, not dirty, and 
         * invalid. The pageNo is the index into the page table.
         */
        PTEntry(int index) {
            dirty = valid = false;
            referenced = 0;
            pageNo = index;
        }

        /*
         * Reset the fields that need to be reset when a page is 
         * evicted.
         */
        public void reset(){
            dirty = valid = false;
            referenced = 0;
        }
    }

    /*
     * Frame table that tracks pages currently in RAM
     * 
     * Responsible for updating validity in each page table
     * entry and guarantees a frame for a page not in RAM
     * 
     * Handles evictions and simulates writing to disk by
     * resetting evicted pages and incrementing numWrites if
     * dirty. Allocates the first n pages as frames 0 to n-1
     */
    static class FrameTable{
        PTEntry[] frames;
        int numFrames, numFull;

        /*
         * Constructor -- initialize the frames and set the
         * number of full frames to 0.
         */
        public FrameTable(int numFrames) {
            this.numFrames = numFrames;
            numFull = 0;
            frames = new PTEntry[numFrames];
            for(int i = 0; i < numFrames; i++)
                frames[i] = null;
        }

        /*
         * Get a frame for a page that has requested one. If
         * the frame table is not full, allocate the next frame
         * from 0 to n-1. If full, then call replaceFrame() method
         * and simulate writing to disk/resetting evicted pages.
         */
        public void getFrame(PTEntry pte){
            // the first n frames are empty
            if (numFull < numFrames){
                System.out.println("page fault - no eviction");
                frames[numFull] = pte;
                numFull++;
                pte.valid = true;
            } else {    // have allocated first n frames
                int rep = replaceFrame();
                PTEntry evicted = frames[rep];
                if (evicted.dirty)  {// sim writing to disk
                    System.out.println("page fault - evict dirty");
                    numWrites++;
                } else
                   System.out.println("page fault - evict clean");
                evicted.reset();
                frames[rep] = pte;
                pte.valid = true;
            }
        }

        /*
        * Calls corresponding replacement algorithm and returns the
        * algorithm's choice for frame to evict
        */
        public int replaceFrame(){
            if (alg.equals("opt")){
                return opt();
            } else if (alg.equals("clock")){
                return clock();
            } else if (alg.equals("lru")){
                return lru();
            } else if (alg.equals("nfu")){
                return nfu();
            } return -1;
        }
    }

    /*
     * Should only be called when chosen algorithm is "opt".
     * Initializes data structure used for the opt alg, which
     * is a list of lists. Scans the entire trace file and 
     * maps each VM pageNo to a list of instructions (in ascending
     * order) at which the page is referenced in the tracefile.
     * 
     * VERY space inefficient! 
     */
    public static void init_opt(String filename){
        refList = new ArrayList<ArrayList<Integer>>();
        for (int i = 0; i < NUM_PAGES; i++)
            refList.add(new ArrayList<Integer>());
        Scanner scan = null;
        try {
            File tracefile = new File(filename);
            scan = new Scanner(tracefile);
        } catch (FileNotFoundException e){
            System.out.println("File " + filename + " not found");
            System.exit(1);
        }
        int accCount = 0;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            if (line.charAt(0) == 'I') {
                accCount++;
            } else if (line.charAt(0) == ' ') {
                if (line.charAt(1) == 'L' || line.charAt(1) == 'S')
                    accCount++;
                else if (line.charAt(1) == 'M')
                    accCount += 2;
                else continue;
            }
            else continue;
            // address starts at index 3 and is length 8
            long address = Long.parseLong(line.substring(3, 11), 16);
            int pageNo = (int) (address >> 13);
            refList.get(pageNo).add(accCount);
        }
        scan.close();
    }

    /* 
     * Implements the optimal replacement algorithm
     * 
     * On replace, the algorithm indexes into each page currently
     * in the frame table using the page's pageNo using numAcc.
     * Find the next highest access time, and if not found, then
     * set to infinity
     * Page with max access time is evicted
     * 
     * implement preferring clean to dirty pages?
     * implement with queue and remove as we go?
     */
    public static int opt(){
        PTEntry pte;
        ArrayList<Integer> refsToPage;
        int nextAcc;
        int maxVal = 0, maxIndex = -1;
        for (int i = 0; i < frameTable.numFrames; i++){
            pte = frameTable.frames[i];
            refsToPage = refList.get(pte.pageNo);
            nextAcc = Integer.MAX_VALUE;
            for (int j = 0; j < refsToPage.size(); j++){
                if (refsToPage.get(j) > numAcc) {
                    nextAcc = refsToPage.get(j);
                    break;
                }
            }
            if (nextAcc > maxVal){
                maxVal = nextAcc;
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    /*
     * Second chance algorithm using a circular queue, which is
     * implemented as an index tracker into the frame table. The
     * clockHead marks the index in the frame table of the "oldest"
     * page. If the page has been referenced, set the page to 
     * unreferenced and increment head. First unreferenced page is 
     * returned as the choice for eviction and head is incremented
     * to the next frame.
     * 
     * Average case n/2
     */
    public static int clock(){
        // if referenced, set to unreferenced
        // first unreferenced page will be replaced
        while (frameTable.frames[clockHead].referenced > 0){
            frameTable.frames[clockHead].referenced = 0;
            clockHead = (clockHead + 1) % frameTable.numFrames;
        }
        int replace = clockHead;
        clockHead = (clockHead + 1) % frameTable.numFrames;
        return replace;
    }

    /*
     * Evict the least recently used page, tracked with the
     * timestamp field in each page table entry. This simulates
     * LRU with hardware support (e.g., each page has a counter
     * that is updated with each reference).
     * 
     * Average case n/2
     */
    public static int lru(){
        int minIndex = 0;
        int minValue = frameTable.frames[0].timestamp;
        for (int i = 1; i < frameTable.numFrames; i++) {
            if (frameTable.frames[i].timestamp < minValue) {
                minValue = frameTable.frames[i].timestamp;
                minIndex = i;
            }
        }
        return minIndex;
    }

    /*
     * Evict the page with the lowest number of references, tracked
     * with the referenced field in each page table entry.
     * 
     * Average case n/2
     */
    public static int nfu(){
        int minIndex = 0;
        int minValue = frameTable.frames[0].referenced;
        for (int i = 1; i < frameTable.numFrames; i++){
            if (frameTable.frames[i].referenced < minValue){
                minValue = frameTable.frames[i].referenced;
                minIndex = i;
            }
        }
        return minIndex;
    }


    /*
     * Given virtual address, gets the page number and corresponding
     * page table entry. Updates the timestamp, referenced, and dirty
     * variables. If the entry is invalid, then a page fault occurs
     * and asks the frame table to find a frame for the page.
     */
    public static void mmu(long virtAddr, boolean write){
        // page number is top 19 bits
        int pageNo = (int) (virtAddr >> 13);
        PTEntry pte = pageTable.get(pageNo);
        pte.timestamp = numAcc; // instruction of last access (for LRU)
        pte.referenced++;       // should be 1 on load
        if (write)
            pte.dirty = true;
        if (! pte.valid) {      // page fault
            numPageFaults++;
            // find a free frame and put page in RAM
            frameTable.getFrame(pte);
        } else
            System.out.println("hit");
    }

    /*
     * Parses the memory trace file and calls the MMU algorithm
     * for each memory access. Instructions, stores, and loads are
     * each one access. Modifies count as both a store and load.
     * Any store event counts as a write.
     */
    public static void simMemory(String filename){
        Scanner scan = null;
        try {   // open tracefile
            File tracefile = new File(filename);
            scan = new Scanner(tracefile);
        } catch (FileNotFoundException e){
            System.out.println("File " + filename + " not found");
            System.exit(1);
        }
        boolean write;
        while (scan.hasNextLine()) {    // read each line
            write = false;
            String line = scan.nextLine();
            if (line.charAt(0) == 'I')              // instruction
                numAcc++;
            else if (line.charAt(0) == ' ') {
                if (line.charAt(1) == 'L')          // load
                    numAcc++;
                // store and modify are writes
                else if (line.charAt(1) == 'S') {   // store
                    write = true;
                    numAcc++;
                } // modify counts as store and load
                else if (line.charAt(1) == 'M') {   // modify
                    write = true;
                    numAcc += 2;
                } else continue;
            }
            else continue;
            // address starts at index 3 and is length 8
            long address = Long.parseLong(line.substring(3, 11), 16);
            mmu(address, write);
        }
        scan.close();
    }

    public static void main(String[] args){
        int numFrames = -1;
        // command-line validity checking
        if (args.length != 5 || !args[0].equals("-n") ||
            !args[2].equals("-a") || !algs.contains(args[3])) {
            System.out.println("Usage: VMSim -n <numFrames> -a <opt|clock|lru|nfu> <tracefile>");
            System.exit(1);
        }
        try {
            numFrames = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.err.println("Argument -n <" + args[0] + "> must be an integer.");
            System.exit(1);
        }
        alg = args[3];
        String filename = args[4];
        // init page table
        pageTable = new ArrayList<PTEntry>();
        for (int i = 0; i < NUM_PAGES; i++)
            pageTable.add(new PTEntry(i));
        // init frame table
        frameTable = new FrameTable(numFrames);
        if (alg.equals("opt"))
            init_opt(filename);
        // initialization done, now simulate memory using tracefile
        simMemory(filename);
        // print summary stats
        System.out.println("Algorithm: " + alg);
        System.out.println("Number of frames:\t" + numFrames);
        System.out.println("Total memory accesses:\t" + (numAcc));
        System.out.println("Total page faults:\t" + numPageFaults);
        System.out.println("Total writes to disk:\t" + numWrites);
        System.out.println("Total size of page table:\t\t" + NUM_PAGES * 4 + " bytes");
    }
}
