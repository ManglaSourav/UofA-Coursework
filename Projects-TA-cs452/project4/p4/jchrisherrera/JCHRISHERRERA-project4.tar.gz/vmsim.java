import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;


/*
 * CSC 452 vmsim - Chris Herrera
 * This program implements a single-level page table for a 32-bit address space. All pages will be 8KB in size.
 * The number of frames will be a parameter to the execution of the program.
 * The program will then run through the memory references of a given file and display the action taken for each
 * address (hit, page fault - no eviction, page fault - evict clean, page fault - evict dirty). 
 */
public class vmsim {
	// Tracker variables
	private int memoryAccesses = 0;
	private int pageFaults = 0;
	private int diskWrites = 0;
	private int numFrames;
	private int openFrames;
	private int frameTracker;
	private String algo;
	private String traceFile;
	private final int pageTableSize = 2097152; // bytes.  8KB page size = 8192 bytes (2^13) 
													   // 32-bit VA space = 2^32 bytes 
													   // 2^32 / 2^13 = 2^19 (524288 table entries)
													   // Each entry is 4 bytes so 524288 * 4 = 2097152 bytes
	private final int pageSize = 8192; // bytes
	// Data structures to help implementation
	private List<PageTableEntry> pageTable;
	private Map<Integer, Integer> frameToPage; // frame number -> page table number
	private LinkedList<PageTableEntry> lruList;
	private LinkedList<PageTableEntry> clockList;
	private int oldest;
	

	public vmsim(String frames, String algorithm, String file) {
		try {
			this.numFrames = Integer.valueOf(frames);
		}
		catch (NumberFormatException e) {
			System.out.println("Invalid argument given for -n\n Enter a number after -n");
			System.exit(0);
		}
		this.openFrames = numFrames;
		this.frameTracker = 0;
		this.frameToPage = new HashMap<Integer, Integer>();
		this.lruList = new LinkedList<PageTableEntry>();
		this.clockList = new LinkedList<PageTableEntry>();
		this.oldest = 0;
		this.algo = algorithm;
		this.traceFile = file;
		this.pageTable = new ArrayList<PageTableEntry>(pageTableSize / 4);
		for (int i = 0; i < pageTableSize / 4; i++) {
			PageTableEntry newEntry = new PageTableEntry();
			pageTable.add(newEntry);
		}
	}
	
	
	public static void main(String[] args) {
		if (args.length < 5 | !args[0].equals("-n") | !args[2].equals("-a")) {
			System.out.println("Call the program like this: java vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>");
			System.exit(0);
		}
		
		vmsim simulator = new vmsim(args[1], args[3], args[4]);
		
		if (simulator.getAlgo().equals("opt")) {
			simulator.optSetup();
		}
		simulator.simulate();
	}
	
	
	public String getAlgo() {
		return this.algo;
	}
	

	/*
	 * Translate virtualAddress into a page number use as index into page table to get frame #
	 */
	public int translate(String virtualAddress) {
		// VA / pageSize 
    	long hexAddr = Long.parseUnsignedLong(virtualAddress, 16);
    	long pageNum = hexAddr / this.pageSize;
    	return (int) pageNum;
	}
	
	
	/*
	 * Parse the trace file to track locations of each page so that
	 * we can use them for the optimal algorithm which looks into the future
	 */
	public void optSetup() {
		int headerCount = 0;
		boolean pastHeader = false;
		
		// Parse the trace file & track locations
		File trace = new File(traceFile);
		String line;
		String[] addressParts = null;
		int lineNum = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(trace))) {
    	    while ((line = br.readLine()) != null) {
    	    	String address = "", instructionAndAddr = "";
    	    	if (line.charAt(0) == '-' | line.charAt(0) == '=') {
    	    		if (pastHeader) {
    	    			lineNum++;
    	    		}
    	    		headerCount++;
    	    		if (headerCount == 37) {
    	    			pastHeader = true;
    	    		}
    	    		continue;
    	    	}

    	        String[] lineParts = line.split(",");
    	        if (lineParts.length > 1) {
    	        	
	    	        instructionAndAddr = lineParts[0];

	    	        addressParts = instructionAndAddr.split(" ");
	    	        
	    	        if (addressParts.length == 3) {
	    	        	address = addressParts[2];
	        	        int pageNum;
	    	        	pageNum = translate(address);
	    	        	PageTableEntry pte = pageTable.get(pageNum);
	    	        	pte.addLocation(lineNum);
	    	        }
	    	        else {
	    	        	lineNum++;
	    	        	continue; // Just in case formatting is strange for some trace file, skip the line
	    	        }
    	        }
    	        else {
    	        	lineNum++;
    	        	continue; // Just in case formatting is strange for some trace file, skip the line
    	        }
        		
            	lineNum++;
            	
    	    }  
    	    
		} catch (FileNotFoundException e) {
			System.out.println("File not found.  Double check arguments");
			System.exit(0);
		} catch (IOException e) {
			System.out.println("IOException; Could not read file?");
			System.exit(0);
		}
	}
	

	public int lruEvict() {
			PageTableEntry toEvict = lruList.removeLast();
			int fr = toEvict.getFrame();
			return frameToPage.get(fr);
	}
	
	
	/*
	 * Starting at lineNum, look into the future to find which frame
	 * is holding a page table entry which won't be referenced again for the longest possible time
	 */
	public int optEvict(int lineNum) {
		
		List<Integer> possibles = new ArrayList<Integer>();
		int farthestDistance;
		
		// For each frame
		for (int frameNum = 0; frameNum < numFrames; frameNum++) {
			int possiblePage = frameToPage.get(frameNum); // page num of a possible eviction
			PageTableEntry pte = pageTable.get(possiblePage);
			int location = pte.removeLocation();
			if (location == -1) { // never seen again, evict it
				return possiblePage;
			}
			else {
				while (location < lineNum && location != -1) { // old location we don't care about
					location = pte.removeLocation();
				}
			}
			int distance = location - lineNum;
			possibles.add(distance);
		}
		
		farthestDistance = Collections.max(possibles);

		int retval = frameToPage.get(possibles.indexOf(farthestDistance));
	
	    return retval;
	}


	/*
	 * Adjust the pointer into the clock linked list and adjust reference bits
	 * as necessary to find the oldest unreferenced page so we can evict it
	 */
	public int clockEvict() {
		while (true) {
			if (oldest >= 8) {
				oldest = 0;
			}
			PageTableEntry toCheck = clockList.get(oldest);
			if (toCheck.getReferenced()) {
				toCheck.setReferenced(false); // survives this time
			}
			else {
				int fr = toCheck.getFrame();
				return frameToPage.get(fr);
			}
			oldest++;
		}
	}
	
	
	/*
	 * Find the page which has been referenced the least amount of times since loaded into a frame
	 */
	public int nfuEvict() {
		
		int leastReferenced;

		List<Integer> possibles = new ArrayList<Integer>();
		
		for (int frameNum = 0; frameNum < numFrames; frameNum++) {
			int possiblePage = frameToPage.get(frameNum); // page num of a possible eviction
			PageTableEntry pte = pageTable.get(possiblePage);
			possibles.add(pte.getReferencedCount());
		}
		
		leastReferenced = Collections.min(possibles);

		int retval = frameToPage.get(possibles.indexOf(leastReferenced));
	
	    return retval;
	}
	
	
	/*
	 * Simulate the page table process
	 */
	public void simulate() {
		int headerCount = 0;
		boolean pastHeader = false;
		File trace = new File(traceFile);
		String line;
		String[] addressParts = null;
		int lineNum = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(trace))) {
	    	    while ((line = br.readLine()) != null) {
	    	    	String address = "", instructionAndAddr = "", 
	    	    			firstEvent = "", secondEvent = "";
	    	    	if (line.charAt(0) == '-' | line.charAt(0) == '=') {
	    	    		if (pastHeader) {
	    	    			lineNum++;
	    	    		}
	    	    		headerCount++;
	    	    		if (headerCount == 37) {
	    	    			pastHeader = true;
	    	    		}
	    	    		continue;
	    	    	}
	    	        String[] lineParts = line.split(",");
	    	        if (lineParts.length > 1) {
		    	        instructionAndAddr = lineParts[0];

		    	        addressParts = instructionAndAddr.split(" ");
		    	        
		    	        if (addressParts.length == 3) {
			    	        firstEvent = addressParts[0];
			    	        secondEvent = addressParts[1];
		    	        	address = addressParts[2];
		    	        }
		    	        else {
		    	        	continue;
		    	        }
	    	        }
	    	        else {
	    	        	continue;
	    	        }

	    	        int pageNum;
    	        	pageNum = translate(address);
    	        	
    	        	PageTableEntry pte = pageTable.get(pageNum);
    	        	pte.setReferenced(true);
    	        	pte.addReferenced();
    	        	if (algo.equals("lru")) { // For lru, we move elements in a linked list to determine least recently used
        	        	if (lruList.contains(pte)) {
        	        		lruList.remove(pte);
        	        		lruList.addFirst(pte);
        	        	}
        	        	else {
        	        		lruList.addFirst(pte);
        	        	}
    	        	}
    	        	
	    	        if (firstEvent.equals("I") && secondEvent.equals("")) { // fetch from ram
	    	        	memoryAccesses++;
	    	        }
	    	        else if (firstEvent.equals("") && secondEvent.equals("S")) { // write
	    	        	pte.setDirty(true);
	    	        	memoryAccesses++;
	    	        }
	    	        else if (firstEvent.equals("") && secondEvent.equals("L")) { // load (read)
	    	        	memoryAccesses++;
	    	        }
	    	        else if (firstEvent.equals("") && secondEvent.equals("M")) { // write
	    	        	pte.setDirty(true);
	    	        	memoryAccesses += 2;
	    	        }
	    	        if (pte.getValid()) { // already in RAM, just continue
	    	        	System.out.println("hit");
	    	        	lineNum++;
	    	        	continue;
	    	        }
	    	        else { // invalid, not in RAM!
	    	        	pageFaults++;
	    	        	if (openFrames == 0) { // RAM full, must evict
	    	        		int pageToEvict = -1;
	    	        		if (algo.equals("clock")) {
	    	        			pageToEvict = clockEvict(); 
	    	        		}
	    	        		else if (algo.equals("lru")) {
	    	        			pageToEvict = lruEvict(); 
	    	        		}
	    	        		else if (algo.equals("nfu")) {
	    	        			pageToEvict = nfuEvict();
	    	        		}
	    	        		else if (algo.equals("opt")) {
		    	        		pageToEvict = optEvict(lineNum);
	    	        		}
	    	        		
	    	        		PageTableEntry evicted = pageTable.get(pageToEvict);
	    	        		if (evicted.getDirty()) { // Page has been written since it was loaded, so write it to disk 
	    	        								// before evicting it
	    	        			System.out.println("page fault - evict dirty");
		    	        		evicted.setDirty(false);
	    	        			diskWrites++;
	    	        		}	
	    	        		else {
	    	        			System.out.println("page fault - evict clean");
	    	        		}
	    	        		
	    	        		evicted.setValid(false);
	    	        		evicted.setReferenced(false);
	    	        		evicted.resetRefCount();
	 
	    	        		int evictedFrame = evicted.getFrame();
	
	    	        		frameToPage.put(evictedFrame, pageNum);
	    	        		pte.setFrame(evictedFrame);
	    	        		pte.setValid(true);
	    	        		
	    	        		if (algo.equals("clock")) {
		    	        		clockList.set(oldest, pte);
		    	        		oldest++;
	    	        		}
  	      
	    	        	}
	    	        	else { // There's an empty frame, just give it away
	    	        		System.out.println("page fault - no eviction");
	    	        		frameToPage.put(frameTracker, pageNum);
	    	        		pte.setFrame(frameTracker++);
	    	        		openFrames--;
	    	        		pte.setValid(true);
	    	    	        clockList.add(pte);
	    	    	        pageTable.set(pageNum, pte);
	    	        	}
	    	        }   	   
	    	    	lineNum++;
	    	    }  
		} catch (FileNotFoundException e) {
			System.out.println("File not found.  Double check arguments");
			System.exit(0);
		} catch (IOException e) {
			System.out.println("IOException; Could not read file?");
			System.exit(0);
		}
		
		// Summary statistics
		System.out.println("Algorithm: "+algo);
		System.out.println("Number of frames: "+String.valueOf(numFrames));
		System.out.println("Total memory accesses: "+String.valueOf(memoryAccesses));
		System.out.println("Total page faults: "+String.valueOf(pageFaults));
		System.out.println("Total writes to disk: "+String.valueOf(diskWrites));
		System.out.println("Total size of page table: "+String.valueOf(pageTableSize)+" bytes");
		
	}
	
	
	/*
	 * Simple object to hold data for each PTE
	 */
	class PageTableEntry {
		private boolean valid;
		private boolean referenced;
		private int referencedCount;
		private boolean dirty;
		private int frame;
		private Queue<Integer> locations;
		
		public PageTableEntry() {
			this.valid = false;
			this.referenced = false;
			this.dirty = false;
			this.referencedCount = 0;
			this.locations = new LinkedList<Integer>();
		}
		
		public void resetRefCount() {
			this.referencedCount = 0;
		}
		
		public void addLocation(int line) {
			locations.add(line);
		}
		
		public int removeLocation() {
			if (locations.size() > 1) {
				return locations.remove();
			}
			return -1; // if -1 returns, this pte is only in 1 location which means it's never seen again
		}
		
		public void addReferenced() {
			referencedCount++;
		}
		
		public int getReferencedCount() {
			return referencedCount;
		}
		
		public void setDirty(boolean modified) {
			dirty = modified;
		}
		
		public boolean getDirty() {
			return dirty;
		}
		
		public void setValid(boolean validity) {
			valid = validity;
		}
		
		public boolean getValid() {
			return valid;
		}
		
		public void setReferenced(boolean ref) {
			referenced = ref;
		}
		
		public boolean getReferenced() {
			return referenced;
		}
		
		public void setFrame(int frameNum) {
			this.frame = frameNum;
		}
		
		public int getFrame() {
			return frame;
		}

	}
	
	
}
