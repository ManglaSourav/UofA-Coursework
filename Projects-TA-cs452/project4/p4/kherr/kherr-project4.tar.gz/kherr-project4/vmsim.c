/*
* File: vmsim.c
* Author: Kaden Herr
* Date Created: April 5, 2022
* Last editted: April 11, 2022
* Purpose: A program that evaluates different page replacement algorithms.
* Info: If there is an error when running this program, it will return 1.
* Compile Note: gcc vmsim.c -o vmsim
* Run Instructions: vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/* Constants */
#define EXPECTED_ARG_COUNT 6
#define PAGE_SIZE 8192 // 8KB or 8192 bytes
#define PAGE_TABLE_SIZE 524288

/* Structs*/
struct pageEntry {
    int dirty;
    int referenced;
    int valid;
    int frameNumber;
};

struct memStruct {
    struct pageEntry *page;
    struct memStruct *next;
    struct memStruct *prev;
};

struct optPage {
    int valid;
    int dirty;
    struct time *nextRef;
    struct time *addRef;  
};
struct time {
    int time;
    struct time *next;  
};
struct optMemStruct {
    struct optPage *page;
    struct optMemStruct *next;
    struct optMemStruct *prev;
};


/* Prototypes */
void pageTableInit();
void countMemAccesses(FILE *fp);
void addressTranslate(FILE *fp);
// LRU
void algoLRU(FILE *fp, int memSpace);
void insertAfter(struct memStruct *item, struct memStruct *curItem);
void insertNewAfter(struct memStruct *new, struct memStruct *curItem);
// NFU
void algoNFU(FILE *fp, int memSpace);
struct memStruct *findMin(struct memStruct *head, int memSpace);
// Clock
void algoClock(FILE *fp, int memSpace);
struct memStruct *findOldUnrefed(struct memStruct *head);
// OPT
void optTableInit();
void optTableCompile(FILE *fp);
void algoOPT(FILE *fp, int memSpace);
void optInsertNewAfter(struct optMemStruct *new, struct optMemStruct *curItem);
struct optMemStruct *findFurthest(struct optMemStruct *head, int memSpace);



/* Global variables */
int totalMemAccesses = 0;
int diskWriteCount = 0;
int totalPageFaults = 0;
int cleanEvictCount = 0;
int dirtyEvictCount = 0;
struct pageEntry *pageTable[PAGE_TABLE_SIZE];
struct optPage *optPageTable[PAGE_TABLE_SIZE];


int main(int argc, char *argv[]) {
    int i, numFrames;
    char algoName[6];
    int frmCntFound = 0;
    int algoArgFound = 0;

    FILE *fp = NULL;

    // Make sure there is a correct number of command-line arguments
    if(argc != EXPECTED_ARG_COUNT) {
        fprintf(stderr,
            "ERROR: Incorrect number of command-line arguments.\n");
        return 1;
    }

    // Parse the command line arguments
    for(i=1; i<EXPECTED_ARG_COUNT; i++) {
        if(strcmp(argv[i],"-n") == 0) {
            i++;
            // Store the number of frames
            numFrames = atoi(argv[i]);
            frmCntFound = 1;
        } else if(strcmp(argv[i],"-a") == 0) {
            i++;
            strncpy(algoName, argv[i], 6);
            algoArgFound = 1;
        } else {
            // Open the file
            fp = fopen(argv[i], "r");
            if(fp == NULL) {
                perror(argv[i]);
                return 1;
            }
        }
    }

    // Check that all arguments were parsed correctly
    if(algoArgFound != 1 || frmCntFound != 1) {
        fprintf(stderr,"ERROR: Incorrect command-line arguments given.\n");
    }

    // Initialize the page table for clock, lru, and nfu algorithms
    if(strcmp(algoName,"opt") != 0) {
        pageTableInit();
    }
    

    // Determine what algorithm to run
    if(strcmp(algoName,"opt") == 0) {
        optTableInit();
        optTableCompile(fp);
        rewind(fp);
        algoOPT(fp, numFrames);
    } else if(strcmp(algoName,"clock") == 0) {
        algoClock(fp, numFrames);
    } else if(strcmp(algoName,"lru") == 0) {
        algoLRU(fp, numFrames);
    } else if(strcmp(algoName,"nfu") == 0) {
        algoNFU(fp, numFrames);
    } else {
        fprintf(stderr,"ERROR: Algorithm name not recognized\n");
        return 1;
    }


    // Print the results
    printf("Total Clean Evicts:        %d\n",cleanEvictCount);
    printf("Total Dirty Evicts:        %d\n",dirtyEvictCount);
    printf("Algorithm: %s\n",algoName);
    printf("Number of frames:          %d\n",numFrames);
    printf("Total memory accesses:     %d\n",totalMemAccesses);
    printf("Total page faults:         %d\n",totalPageFaults);
    printf("Total writes to disk:      %d\n",diskWriteCount);
    printf("Total size of page table:  %d bytes\n",PAGE_TABLE_SIZE*4);//Each entry is 4 bytes


    // Close the file
    if(fclose(fp) == EOF) {
        fprintf(stderr,
            "ERROR: Encountered problem when trying to close file.\n");
        return 1;
    }


    return 0;
}


/*
* void pageTableInit() - Initialize the page table by mallocing space and
* setting the default values for each struct element in the table.
*/
void pageTableInit() {
    int i;
    for(i=0; i<PAGE_TABLE_SIZE; i++) {
        pageTable[i] = (struct pageEntry *) malloc(sizeof(struct pageEntry));
        pageTable[i]->dirty = 0;
        pageTable[i]-> referenced = 0;
        pageTable[i]->valid = 0;
        pageTable[i]->frameNumber = -1;
    }
}


/*
* void algoLRU(FILE*, int) - Run the LRU algorithm and print data. Second
* parameter is the number of frames that can fit in RAM.
*/
void algoLRU(FILE *fp, int memSpace) {
    int retVal, pageNum;
    long virtualAddress;
    char c1, c2;
    char address[9];
    char *line = NULL;
    size_t sz = 0;

    int time = 0;
    int framesInMem = 0;
    struct memStruct *memHead = NULL;

    // Read from the file and collect statistics
    while(getline(&line, &sz, fp) > 0) {
        // Read a line of the file
        retVal = sscanf(line, "%c%c %8s", &c1,&c2, address);

        // Skip blank lines.
        if(retVal < 1) {
            continue;
        }

        // Make sure that the line is valid information
        if(c1 == 'I' || c1 == ' ') {
            // Memory access
            totalMemAccesses++;
            // Increment the time stamp counter
            time++;
            // Convert string hex virtual address into an integer
            virtualAddress = strtol(address, NULL, 16);
            // Convert virtual address into page number
            pageNum = (int) (virtualAddress / PAGE_SIZE);

            // See if the page is in memory already
            if(pageTable[pageNum]->valid) {
                printf("Address %s is a HIT.\n",address);
                // Stamp the frame so it can be located in memory
                pageTable[pageNum]->frameNumber = time;
                // Find the frame in memory
                struct memStruct *cur = memHead;
                while(cur->page->frameNumber != time) {
                    cur = cur->prev;
                }
                // Place it at the head of the memory list
                insertAfter(cur,memHead);
                memHead = cur;
            } else {
                // Page Fault
                totalPageFaults++;

                if(framesInMem < memSpace) {
                    // See if there is room in RAM for another page.
                    printf("Address %s is a PAGE FAULT - NO EVICTION\n",address);
                    framesInMem++;
                    // Check if the memory list needs to be initialized
                    if(memHead == NULL) {
                        memHead = (struct memStruct *) malloc(sizeof(struct memStruct));
                        // Make it self-looping
                        memHead->prev = memHead;
                        memHead->next = memHead;
                    } else {
                        struct memStruct *temp = (struct memStruct *) malloc(sizeof(struct memStruct));
                        insertNewAfter(temp,memHead);
                        memHead = temp;
                    }
                } else {
                    // No room. Evict least recently used page.
                    memHead = memHead->next;
                    // See if it was dirty or not
                    if(memHead->page->dirty) {
                        printf("Address %s is a PAGE FAULT - EVICT DIRTY\n",address);
                        dirtyEvictCount++;
                        diskWriteCount++;
                        // If it was dirty, reset it.
                        memHead->page->dirty = 0;
                    } else {
                        printf("Address %s is a PAGE FAULT - EVICT CLEAN\n",address);
                        cleanEvictCount++;
                    }
                    // Mark the page as nolonger being in memory
                    memHead->page->valid = 0;
                }
                // Set up the page
                memHead->page = pageTable[pageNum];
                pageTable[pageNum]->valid = 1;
                pageTable[pageNum]->frameNumber = time;
            }

            if(c2 == 'S') {
                // Store instruction is a disk write, page is now dirty
                pageTable[pageNum]->dirty = 1;
            } else if(c2 == 'M') {
                // Modify instruction is a Load and Store instuction combo.
                totalMemAccesses++;
                // Disk write instruction, page is now dirty
                pageTable[pageNum]->dirty = 1;
            }
        }
    }
}


/*
* void insertAfter(struct memStruct, struct memStruct) - Insert the given item
* after the current item.
*/
void insertAfter(struct memStruct *item, struct memStruct *curItem) {
    if(item == curItem) {
        // The item cannot insert after itself
        return;
    }
    // Remove item from the list
    item->prev->next = item->next;
    item->next->prev = item->prev;
    // Re-insert item into the list
    item->next = curItem->next;
    item->prev = curItem;
    item->next->prev = item;
    curItem->next = item;
}


/*
* void insertNewAfter(struct memStruct*, struct memStruct*) - Insert a new
* item after the current item.
*/
void insertNewAfter(struct memStruct *new, struct memStruct *curItem) {
    // Insert item into the list
    new->next = curItem->next;
    new->prev = curItem;
    new->next->prev = new;
    curItem->next = new;
}


/*
* void algoNFU(FILE*, int) - Run the NFU algorithm and print data. Second
* parameter is the number of frames that can fit in RAM.
*/
void algoNFU(FILE *fp, int memSpace) {
    int retVal, pageNum;
    long virtualAddress;
    char c1, c2;
    char address[9];
    char *line = NULL;
    size_t sz = 0;

    int framesInMem = 0;
    struct memStruct *memHead = NULL;

    // Read from the file and collect statistics
    while(getline(&line, &sz, fp) > 0) {
        // Read a line of the file
        retVal = sscanf(line, "%c%c %8s", &c1,&c2, address);

        // Skip blank lines.
        if(retVal < 1) {
            continue;
        }

        // Make sure that the line is valid information
        if(c1 == 'I' || c1 == ' ') {
            // Memory access
            totalMemAccesses++;
            // Convert string hex virtual address into an integer
            virtualAddress = strtol(address, NULL, 16);
            // Convert virtual address into page number
            pageNum = (int) (virtualAddress / PAGE_SIZE);
            // Increase the referenced count of the page
            pageTable[pageNum]->referenced++;

            // See if the page is in memory already
            if(pageTable[pageNum]->valid) {
                printf("Address %s is a HIT.\n",address);
            } else {
                // Page Fault
                totalPageFaults++;

                if(framesInMem < memSpace) {
                    // See if there is room in RAM for another page.
                    printf("Address %s is a PAGE FAULT - NO EVICTION\n",address);
                    framesInMem++;
                    // Check if the memory list needs to be initialized
                    if(memHead == NULL) {
                        memHead = (struct memStruct *) malloc(sizeof(struct memStruct));
                        // Make it self-looping
                        memHead->prev = memHead;
                        memHead->next = memHead;
                    } else {
                        struct memStruct *temp = (struct memStruct *) malloc(sizeof(struct memStruct));
                        insertNewAfter(temp,memHead);
                        memHead = temp;
                    }
                } else {
                    // No room. Evict the page whose referenced count since
                    // loaded is the lowest.

                    // Find the lowest and set it to be the head of the list
                    memHead = findMin(memHead,memSpace);
                    // See if it was dirty or not
                    if(memHead->page->dirty) {
                        printf("Address %s is a PAGE FAULT - EVICT DIRTY\n",address);
                        dirtyEvictCount++;
                        diskWriteCount++;
                        // If it was dirty, reset it.
                        memHead->page->dirty = 0;
                    } else {
                        printf("Address %s is a PAGE FAULT - EVICT CLEAN\n",address);
                        cleanEvictCount++;
                    }
                    // Mark the page as no longer being in memory
                    memHead->page->valid = 0;
                    // Reset its referenced count to zero
                    memHead->page->referenced = 0;
                }
                // Set up the page in the list
                memHead->page = pageTable[pageNum];
                pageTable[pageNum]->valid = 1;
            }

            if(c2 == 'S') {
                // Store instruction is a disk write, page is now dirty
                pageTable[pageNum]->dirty = 1;
            } else if(c2 == 'M') {
                // Modify instruction is a Load and Store instuction combo.
                totalMemAccesses++;
                // Disk write instruction, page is now dirty
                pageTable[pageNum]->dirty = 1;
            }
        }
    }
}


/*
* struct memStruct *findMin(struct memStruct*, int) - Using a given memStruct
* list pointer, find the element with the fewest references and return it. The
* second parameter is the number of elements in the list.
*/
struct memStruct *findMin(struct memStruct *head, int memSpace) {
    int i;
    int min = INT_MAX;
    struct memStruct *minStruct;
    struct memStruct *cur = head;

    // Find the element with the lowest number of references
    for(i=0; i<memSpace; i++) {
        if(cur->page->referenced <= min) {
            // If this element has the smallest referenced count, save it.
            if(cur->page->referenced < min) {
                min = cur->page->referenced;
                minStruct = cur;
            }
            // If this element's referenced count is equal to the smallest and
            // it is clean, then save it.
            if(cur->page->dirty == 0) {
                minStruct = cur;
            }
        }
        cur = cur->next;
    }
    // Reset the frame number to -1
    cur->page->frameNumber = -1;
    // Check the final element in the list
    if(cur->page->referenced < min) {
        min = cur->page->referenced;
        minStruct = cur;
    }

    return minStruct;
}


/*
* void algoClock(FILE*, int) - Run a more efficent implementation of the
* second change algorithm, known as the clock algoritm, and print data. The
* second parameter is the number of frames that can fit in RAM.
*/
void algoClock(FILE *fp, int memSpace) {
    int retVal, pageNum;
    long virtualAddress;
    char c1, c2;
    char address[9];
    char *line = NULL;
    size_t sz = 0;

    int framesInMem = 0;
    // The memHead repressent the oldest element in the list. The element
    // directly behind the memHead is the newest element.
    struct memStruct *memHead = NULL;

    // Read from the file and collect statistics
    while(getline(&line, &sz, fp) > 0) {
        // Read a line of the file
        retVal = sscanf(line, "%c%c %8s", &c1,&c2, address);

        // Skip blank lines.
        if(retVal < 1) {
            continue;
        }

        // Make sure that the line is valid information
        if(c1 == 'I' || c1 == ' ') {
            // Memory access
            totalMemAccesses++;
            // Convert string hex virtual address into an integer
            virtualAddress = strtol(address, NULL, 16);
            // Convert virtual address into page number
            pageNum = (int) (virtualAddress / PAGE_SIZE);
            // Mark the page as referenced
            pageTable[pageNum]->referenced = 1;

            // See if the page is in memory already
            if(pageTable[pageNum]->valid) {
                printf("Address %s is a HIT.\n",address);
            } else {
                // Page Fault
                totalPageFaults++;

                if(framesInMem < memSpace) {
                    // See if there is room in RAM for another page.
                    printf("Address %s is a PAGE FAULT - NO EVICTION\n",address);
                    framesInMem++;
                    // Check if the memory list needs to be initialized
                    if(memHead == NULL) {
                        memHead = (struct memStruct *) malloc(sizeof(struct memStruct));
                        // Make it self-looping
                        memHead->prev = memHead;
                        memHead->next = memHead;
                    } else {
                        struct memStruct *temp = (struct memStruct *) malloc(sizeof(struct memStruct));
                        insertNewAfter(temp,memHead);
                        memHead = temp;
                    }
                } else {
                    // No room. Evict oldest page whose is not referenced

                    // Set the headpointer to this page
                    memHead = findOldUnrefed(memHead);
                    // See if it was dirty or not
                    if(memHead->page->dirty) {
                        printf("Address %s is a PAGE FAULT - EVICT DIRTY\n",address);
                        dirtyEvictCount++;
                        diskWriteCount++;
                        // If it was dirty, reset it.
                        memHead->page->dirty = 0;
                    } else {
                        printf("Address %s is a PAGE FAULT - EVICT CLEAN\n",address);
                        cleanEvictCount++;
                    }
                    // Mark the page as no longer being in memory
                    memHead->page->valid = 0;
                }
                // Set up the page in the list
                memHead->page = pageTable[pageNum];
                pageTable[pageNum]->valid = 1;
                // Set this page to be the newest in the list
                memHead = memHead->next;
            }

            if(c2 == 'S') {
                // Store instruction is a disk write, page is now dirty
                pageTable[pageNum]->dirty = 1;
            } else if(c2 == 'M') {
                // Modify instruction is a Load and Store instuction combo.
                totalMemAccesses++;
                // Disk write instruction, page is now dirty
                pageTable[pageNum]->dirty = 1;
            }
        }
    }
}


/*
* struct memStruct *findOldUnrefed(struct memStruct*) - Given the head of an
* memStruct list, find the oldest unreferenced bit. While searching the list,
* set the referenced field to 0 for every element encountered before reaching
* the oldest unreferenced element.
*/
struct memStruct *findOldUnrefed(struct memStruct *head) {
    struct memStruct *cur = head;

    while(cur->page->referenced != 0) {
        cur->page->referenced = 0;
        cur = cur->next;
    }

    return cur;
}



/*
* void optTableInit() - Initialize special page table for the opt algorithm.
* element in the table.
*/
void optTableInit() {
    int i;
    // Malloc space and set the default values for each struct
    for(i=0; i<PAGE_TABLE_SIZE; i++) {
        optPageTable[i] = (struct optPage *) malloc(sizeof(struct optPage));
        optPageTable[i]->valid = 0;
        optPageTable[i]->dirty = 0;
        optPageTable[i]->nextRef = NULL;
        optPageTable[i]->addRef = NULL;
    }
}


/*
* void optTableCompile(FILE*) - Compile the special page table that is used
* for the OPT algorithm by reading through the given file and time stamping
* when each page is used.
*/
void optTableCompile(FILE *fp) {
    int retVal, pageNum;
    long virtualAddress;
    char c1, c2;
    char address[9];
    char *line = NULL;
    size_t sz = 0;
    int time = 0;
    struct time *temp;


    // Read from the file and collect time stamps for each page
    while(getline(&line, &sz, fp) > 0) {
        // Read a line of the file
        retVal = sscanf(line, "%c%c %8s", &c1,&c2, address);

        // Skip blank lines.
        if(retVal < 1) {
            continue;
        }

        // Make sure that the line is valid information
        if(c1 == 'I' || c1 == ' ') {
            // Increment time
            time++;
            // Convert string hex virtual address into an integer
            virtualAddress = strtol(address, NULL, 16);
            // Convert virtual address into page number
            pageNum = (int) (virtualAddress / PAGE_SIZE);

            // Add a referenced time stamp to the page
            if(optPageTable[pageNum]->addRef == NULL) {
                // First time this page is referenced, init refrence count.
                optPageTable[pageNum]->addRef = (struct time *) malloc(sizeof(struct time));
                optPageTable[pageNum]->nextRef = optPageTable[pageNum]->addRef;
            } else {
                // Create another node in the time list to hold the next time stamp
                optPageTable[pageNum]->addRef->next = (struct time *) malloc(sizeof(struct time));
                optPageTable[pageNum]->addRef = optPageTable[pageNum]->addRef->next;
            }
            // Add a time stamp to the page
            optPageTable[pageNum]->addRef->time = time;
            optPageTable[pageNum]->addRef->next = NULL;
        }
    }
}


/*
* void algoOPT(FILE*, int) - Run the OPT algorithm and print data. Second
* parameter is the number of frames that can fit in RAM.
*/
void algoOPT(FILE *fp, int memSpace) {
    int retVal, pageNum;
    long virtualAddress;
    char c1, c2;
    char address[9];
    char *line = NULL;
    size_t sz = 0;

    int framesInMem = 0;
    struct optMemStruct *memHead = NULL;
    struct time *temp;

    // Read from the file and collect statistics
    while(getline(&line, &sz, fp) > 0) {
        // Read a line of the file
        retVal = sscanf(line, "%c%c %8s", &c1,&c2, address);

        // Skip blank lines.
        if(retVal < 1) {
            continue;
        }

        // Make sure that the line is valid information
        if(c1 == 'I' || c1 == ' ') {
            // Memory access
            totalMemAccesses++;
            // Convert string hex virtual address into an integer
            virtualAddress = strtol(address, NULL, 16);
            // Convert virtual address into page number
            pageNum = (int) (virtualAddress / PAGE_SIZE);
            // Remove the time stamp from the page
            temp = optPageTable[pageNum]->nextRef;
            optPageTable[pageNum]->nextRef = optPageTable[pageNum]->nextRef->next;
            free(temp);            

            // See if the page is in memory already
            if(optPageTable[pageNum]->valid) {
                printf("Address %s is a HIT.\n",address);
            } else {
                // Page Fault
                totalPageFaults++;

                if(framesInMem < memSpace) {
                    // See if there is room in RAM for another page.
                    printf("Address %s is a PAGE FAULT - NO EVICTION\n",address);
                    framesInMem++;
                    // Check if the memory list needs to be initialized
                    if(memHead == NULL) {
                        memHead = (struct optMemStruct *) malloc(sizeof(struct optMemStruct));
                        // Make it self-looping
                        memHead->prev = memHead;
                        memHead->next = memHead;
                    } else {
                        struct optMemStruct *temp = (struct optMemStruct *) malloc(sizeof(struct optMemStruct));
                        optInsertNewAfter(temp,memHead);
                        memHead = temp;
                    }
                } else {
                    // No room. Evict the page will be used again furthest in
                    // the future and assign that as the head of the list.
                    memHead = findFurthest(memHead,memSpace);
                    // See if it was dirty or not
                    if(memHead->page->dirty) {
                        printf("Address %s is a PAGE FAULT - EVICT DIRTY\n",address);
                        dirtyEvictCount++;
                        diskWriteCount++;
                        // If it was dirty, reset it.
                        memHead->page->dirty = 0;
                    } else {
                        printf("Address %s is a PAGE FAULT - EVICT CLEAN\n",address);
                        cleanEvictCount++;
                    }
                    // Mark the page as no longer being in memory
                    memHead->page->valid = 0;
                }
                // Set up the page in the list
                memHead->page = optPageTable[pageNum];
                optPageTable[pageNum]->valid = 1;
            }

            if(c2 == 'S') {
                // Store instruction is a disk write, page is now dirty
                optPageTable[pageNum]->dirty = 1;
            } else if(c2 == 'M') {
                // Modify instruction is a Load and Store instuction combo.
                totalMemAccesses++;
                // Disk write instruction, page is now dirty
                optPageTable[pageNum]->dirty = 1;
            }
        }
    }
}


/*
* void optInsertNewAfter(struct optMemStruct*, struct optMemStruct*) - Insert
* a new item after the current item.
*/
void optInsertNewAfter(struct optMemStruct *new, struct optMemStruct *curItem) {
    // Insert item into the list
    new->next = curItem->next;
    new->prev = curItem;
    new->next->prev = new;
    curItem->next = new;
}


/*
* struct optMemStruct findFurthest(struct optMemStruct*, int) - Using the head
* of a optMemStruct list, find the item that will be reference furthest in the
* future. Return that item. The second parameter is how many items are in the
* list.
*/
struct optMemStruct *findFurthest(struct optMemStruct *head, int memSpace) {
    int i;
    int max = 0;
    struct optMemStruct *maxStruct;
    struct optMemStruct *cur = head;

    // Find the element with the largest time stamp
    for(i=0; i<memSpace; i++) {
        // This element will never be used again
        if(cur->page->nextRef == NULL) {
            return cur;
        }
        // Find largest
        if(cur->page->nextRef->time > max) {
            max = cur->page->nextRef->time;
            maxStruct = cur;            
        }
        cur = cur->next;
    }

    return maxStruct;
}