#ifndef _INCL_GUARD
#define _INCL_GUARD

#include <string>

using std::string;


typedef struct page Page;

struct page{
    unsigned int addr; // address of page
    unsigned int refCount; // reference for page
    bool modified; // dirty bit

    /** Use for sort algorithm*/
	inline bool operator<(const Page& rhs) const{
		return refCount < rhs.refCount;
	}
    /** Use for finding same page*/
    inline bool operator==(const Page& rhs) const{
		return addr == rhs.addr; 
	}
};


// page replace function
void optAlgorithm(const string& fileName, const unsigned int nframe);
void lruAlgorithm(const string& fileName, const unsigned int nframe);
void nfuAlgorithm(const string& fileName, const unsigned int nframe);
void clockAlgorithm(const string& fileName, const unsigned int nframe);

#endif