#include <vector>
#include <list>
#include <string>
#include <deque>
#include <fstream>
#include <iostream>
#include <sstream>
#include <unordered_map>
#include <algorithm>

#include "util.hpp"

using namespace std;

/** Globale Var**/
unsigned int memoryAccessCount,pageFaultCount,diskWriteCount;
const int PAGESIZE{13}; // each page is 8KB

/** private helper function */
void statics(char mode);
void printInfo(bool modified,bool memoryFull);
unsigned int get_page_addr(const string& line);
vector<string> split(const string& line,const string& delim);
unordered_map<unsigned int,deque<unsigned int> > construct_distance_map (const string& fileName);


/** Key Page function Implementation*/

void optAlgorithm(const string& fileName, const unsigned int nframe){
    unordered_map<unsigned int,deque<unsigned int> > distance_map = construct_distance_map(fileName);
    ifstream file(fileName);
    vector<Page> memory;
    if(file.is_open()){
        string line;
        unsigned int addr,index;
        bool modified;
        index = 0;
        while(getline(file,line)) {
            vector<string>  words = split(line," ");
            if(words[0].size()!= 1 || words.size() != 2){
                words.clear();
                continue;
            }
            statics(words[0][0]); /** Mark memory access according Instruction Type **/
            index ++;
            addr = get_page_addr(words[1]);
            modified = false;
            bool writePageTodisk{false};
            bool memoryFull{memory.size() == nframe};
            if(words[0][0] == 'M' || words[0][0] == 'S')
                modified = true;
            Page curPage{addr,0,modified};
            vector<Page>::iterator iterator = find(memory.begin(),memory.end(),curPage);
            if(iterator != memory.end()){
                iterator->modified = curPage.modified | iterator->modified;
                cout<<"HIT"<<endl;
            } else { /** Occur a page fault **/
                pageFaultCount ++;
                if (memoryFull) { /** Evit a page **/
                    vector<Page>::iterator victim = memory.begin();
                    unsigned int furthest = 0;
                    /** find page evit to disk **/
                    for(vector<Page>::iterator itr = memory.begin(); itr != memory.end() ; itr++){
                        if(distance_map.at(itr->addr).empty()){
                            victim = itr;
                            break;
                        }
                        unsigned int next{0};
                        /* we can not simply access the first one  because this one can be obsolete*/ 
                        // for(int i{0};i<distance_map.at(itr->addr).size();i++){
                        //     if(distance_map.at(itr->addr).at(i) > index){
                        //         next = distance_map.at(itr->addr).at(i);
                        //         break;
                        //     }
                        // }
                        while(true){
                            if(!distance_map.at(itr->addr).empty()){
                                if (distance_map.at(itr->addr).front() < index)
                                    distance_map.at(itr->addr).pop_front();
                                else{
                                    next = distance_map.at(itr->addr).front();
                                    break;
                                }
                            }else
                                break;
                        }
                        if(next > furthest){
                            victim = itr;
                            furthest = next;
                        }
                    } 
                    if(victim->modified) {/** Write back to disk **/
                        diskWriteCount++;
                        writePageTodisk = true;
                    }
                    memory.erase(victim);
                }
                memory.push_back(curPage); /** Inset page into memory**/
            }// end if
            printInfo(writePageTodisk,memoryFull); 
        }
    } else {
        cout<<"Can not Find trace file: "<<fileName<<endl;
        exit(-1);
    }
}

void lruAlgorithm(const string& fileName, const unsigned int nframe) {
    ifstream file(fileName);
    list<Page> memory;
    if (file.is_open()){
        string line;
        unsigned int addr;
        bool modified;
        while(getline(file,line)) {
            vector<string>  words = split(line," ");
            if(words[0].size()!= 1 || words.size() != 2){
                words.clear();
                continue;
            }
            statics(words[0][0]); /** Mark memory access according Instruction Type **/
            addr = get_page_addr(words[1]);
            modified = false;
            bool writePageTodisk{false};
            bool memoryFull{memory.size() == nframe};
            if(words[0][0] == 'M' || words[0][0] == 'S')
                modified = true;
            Page page{addr,0,modified};
            list<Page>::iterator itr = find(memory.begin(), memory.end(), page);
            if(itr != memory.end()){/** place find_page into first **/
                //cout << "HIT!" << endl;
                itr->modified |= page.modified;
                Page reinsertPage{itr->addr,itr->refCount,itr->modified};
                memory.erase(itr);
			    memory.push_front(reinsertPage); 
            } else {
                pageFaultCount ++;
                if(memoryFull) {
                    Page victim = memory.back();
                    if(victim.modified){
                        diskWriteCount++;
                        writePageTodisk = true;
                    }
                    memory.pop_back();
                }
                memory.push_front(page);
            }
            printInfo(writePageTodisk,memoryFull); 
        }
    }
    file.close();
}


void nfuAlgorithm(const string& fileName, const unsigned int nframe){
    ifstream file(fileName);
    list<Page> memory;
    if (file.is_open()){
        string line;
        unsigned int addr;
        bool modified;
        while(getline(file,line)) {
            vector<string>  words = split(line," ");
            if(words[0].size()!= 1 || words.size() != 2){
                words.clear();
                continue;
            }
            statics(words[0][0]); /** Mark memory access according Instruction Type **/
            addr = get_page_addr(words[1]);
            modified = false;
            bool writePageTodisk{false};
            bool memoryFull{memory.size() == nframe};
            if(words[0][0] == 'M' || words[0][0] == 'S')
                modified = true;
            Page page{addr,0,modified};
            list<Page>::iterator itr = find(memory.begin(), memory.end(), page);
            if(itr != memory.end()){
                //cout << "HIT!" << endl;
                itr->modified |= page.modified;
                itr->refCount += 1;
                Page reinsertPage{itr->addr,itr->refCount,itr->modified};
                memory.erase(itr);
			    memory.push_front(reinsertPage); 
            } else {
                pageFaultCount ++;
                bool memoryFull {memory.size() == nframe};
                if(memoryFull) { /** Pop Not Frequent Used page**/
                    memory.sort();
                    Page victim = memory.back();
                    if(victim.modified){
                        diskWriteCount++;
                        writePageTodisk = true;
                    }
                    memory.pop_back();
                }
                memory.push_front(page);
            }
            printInfo(writePageTodisk,memoryFull);
        }
    }
    file.close();
}

void clockAlgorithm(const string& fileName, const unsigned int nframe){
    ifstream file(fileName);
    vector<Page> memory;
    if (file.is_open()){
        string line;
        unsigned int addr;
        int curPos{0};
        bool modified;
        while(getline(file,line)) {
            vector<string>  words = split(line," ");
            if(words[0].size()!= 1 || words.size() != 2){
                words.clear();
                continue;
            }
            statics(words[0][0]); /** Mark memory access according Instruction Type **/
            addr = get_page_addr(words[1]);
            modified = false;
            bool writePageTodisk{false};
            bool memoryFull{memory.size() == nframe};
            if(words[0][0] == 'M' || words[0][0] == 'S')
                modified = true;
            Page page{addr,0,modified};
            vector<Page>::iterator itr = find(memory.begin(), memory.end(), page);
            if(itr != memory.end()){/** set page refCount to 1 **/
                cout << "HIT!" << endl;
                itr->modified |= page.modified;
                itr->refCount = 1;
            } else {
                pageFaultCount ++;
                if(memoryFull) {
                    bool find{false};
                    while(!find) {
                        if(memory.at(curPos).refCount == 1){
                            memory.at(curPos).refCount = 0;
                            curPos = (curPos + 1) % nframe;
                            continue;
                        }
                        // remove page at index curPos
                        if(memory[curPos].modified){
                            diskWriteCount++;
                            writePageTodisk = true;
                        }
                        memory.erase(memory.begin() + curPos);
                        // insert new page at index curPos
                        find = true;
                    }
                }
                //memory.push_front(page);
                //memory.insert(memory.begin(),1,page);
                printInfo(writePageTodisk,memoryFull);
                memory.push_back(page);
            }
        }
    }
    file.close();
}

/** Helper function implementation*/
void statics(char mode){
    if(mode == 'M'){
        memoryAccessCount += 2;
    }else if(mode == 'L' || mode == 'S' || mode == 'I'){
        memoryAccessCount ++;
    }else {
        cout<<"Error Instructions!"<<endl;
    }
}

void printInfo(bool modified,bool memoryFull) {
    if(memoryFull){
        if(modified) /* Need write back to disk*/
		    cout << "Page Fault -- Evict Dirty." << endl;
        else
			cout << "Page Fault -- Evict Clean." << endl;
    } else {
        cout << "Page Fault -- No Eviction." << endl;
    }
}

vector<string> split(const string& line,const string& delim) {
    vector<string> tokens;
    ssize_t start = line.find_first_not_of(delim), end = 0;

    while((end = line.find_first_of(delim, start)) != -1)
    {
        tokens.push_back(line.substr(start, end - start));
        start = line.find_first_not_of(delim, end);
    }
    if(start != -1)
        tokens.push_back(line.substr(start));

    return tokens;
}

unsigned int get_page_addr(const string& line) {
    vector<string> addr =  split(line,",");
    if(addr.size () != 2){
        addr.clear();
        return 0;
    }
    unsigned long ul;
    stringstream ss;
    ss<<hex<<addr[0];
    ss >>ul;
    return (unsigned int)ul >> PAGESIZE;
}

unordered_map<unsigned int,deque<unsigned int> > construct_distance_map (const string& fileName) {
    ifstream file(fileName);
    unordered_map<unsigned int,deque<unsigned int> > distance_map;
    unsigned int addr,distance = {0};
    if (file.is_open()) {
        string line;
        /* while loop for constructing distance map*/
        while(getline(file,line)) {
            // split line with " "
            vector<string>  words = split(line," ");
            if(words[0].size()!= 1 || words.size() != 2){
                words.clear();
                continue;
            }
            addr = get_page_addr(words[1]);
            if(distance_map.find(addr) == distance_map.end()){
                distance_map.insert(make_pair(addr, deque<unsigned int>()));
            }
            distance_map.at(addr).push_back(distance);
            distance++;
        }
    }
    file.close();
    return distance_map;
}