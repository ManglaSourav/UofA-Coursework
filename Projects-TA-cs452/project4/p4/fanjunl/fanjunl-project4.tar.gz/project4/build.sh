echo "opt Algorithm: 4" >> statics.txt 
./vmsim -n 4 -a opt gcc.trace >> statics.txt
echo "opt Algorithm: 8" >> statics.txt 
./vmsim -n 8 -a opt gcc.trace >> statics.txt
echo "opt Algorithm: 16" >> statics.txt 
./vmsim -n 16 -a opt gcc.trace >> statics.txt
echo "opt Algorithm: 32" >> statics.txt 
./vmsim -n 32 -a opt gcc.trace >> statics.txt
echo "opt Algorithm: 64" >> statics.txt 
./vmsim -n 64 -a opt gcc.trace >> statics.txt

echo "\n" >> statics.txt 
echo "lru Algorithm: 4" >> statics.txt 
./vmsim -n 4 -a lru gcc.trace >> statics.txt
echo "lru Algorithm: 8" >> statics.txt 
./vmsim -n 8 -a lru gcc.trace >> statics.txt
echo "lru Algorithm: 16" >> statics.txt 
./vmsim -n 16 -a lru gcc.trace >> statics.txt
echo "lru Algorithm: 32" >> statics.txt 
./vmsim -n 32 -a lru gcc.trace >> statics.txt
echo "lru Algorithm: 64" >> statics.txt 
./vmsim -n 64 -a lru gcc.trace >> statics.txt

echo "\n" >> statics.txt 
echo "nfu Algorithm: 4" >> statics.txt 
./vmsim -n 4 -a nfu gcc.trace >> statics.txt
echo "nfu Algorithm: 8" >> statics.txt 
./vmsim -n 8 -a nfu gcc.trace >> statics.txt
echo "nfu Algorithm: 16" >> statics.txt 
./vmsim -n 16 -a nfu gcc.trace >> statics.txt
echo "nfu Algorithm: 32" >> statics.txt 
./vmsim -n 32 -a nfu gcc.trace >> statics.txt
echo "nfu Algorithm: 64" >> statics.txt 
./vmsim -n 64 -a nfu gcc.trace >> statics.txt

echo "\n" >> statics.txt 
echo "Clock Algorithm: 4" >> statics.txt 
./vmsim -n 4 -a clock gcc.trace >> statics.txt
echo "Clock Algorithm: 8" >> statics.txt 
./vmsim -n 8 -a clock gcc.trace >> statics.txt
echo "Clock Algorithm: 16" >> statics.txt 
./vmsim -n 16 -a clock gcc.trace >> statics.txt
echo "Clock Algorithm: 32" >> statics.txt 
./vmsim -n 32 -a clock gcc.trace >> statics.txt
echo "Clock Algorithm: 64" >> statics.txt 
./vmsim -n 64 -a clock gcc.trace >> statics.txt
