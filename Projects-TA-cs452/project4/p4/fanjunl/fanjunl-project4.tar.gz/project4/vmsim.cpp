#include <iostream>
#include <string>
#include "util.hpp"

using namespace std;
extern unsigned int  memoryAccessCount,pageFaultCount,diskWriteCount;
const long int TotalBytes {1<<(32-13+8)};

int main(int argc, char* argv[]) {
    
    if (argc != 6) {
        cout<<"ERROR USAGE! "<<endl;
        cout<<"USAGE:./vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>"<<endl;
        exit(-1);
    }
    //parse command line arguments
    const int numOfFrame {atoi(argv[2])};
    const string algorithm {argv[4]};
    const string fileName {argv[5]};
    
    if (algorithm == "opt"){
        optAlgorithm(fileName,numOfFrame);
    }else if (algorithm == "clock") {
        clockAlgorithm(fileName,numOfFrame);
    }else if (algorithm == "lru") {
        lruAlgorithm(fileName,numOfFrame);
    }else if (algorithm == "nfu") {
        nfuAlgorithm(fileName,numOfFrame);
    }else{
        cout<<"ERROR USAGE! "<<endl;
        cout<<"USAGE:./vmsim -n <numframes> -a <opt|clock|lru|nfu> <tracefile>"<<endl;
        exit(-1);
    }
    cout<<"memory Access: "<<memoryAccessCount<<endl;
    cout<<"Page Fault : "<<pageFaultCount<<endl;
    cout<<"Disk Write : "<<diskWriteCount <<endl;
    cout<<"Total Bytes : "<<TotalBytes<<endl; 

    return 0;
}




