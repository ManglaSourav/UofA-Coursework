/*
	AUTHOR: Hyoseo Kwag
	DATE: Project 4: Virtual Memory Simulator
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

// print result out in form
int printResult(char *chosenalg, int numframes, int memaccess, int pagefault, int writedisk) {
	printf("Algorithm: %s\n", chosenalg);
	printf("Number of frames:\t%d\n", numframes);
	printf("Total memory accesses:\t%d\n", memaccess);
	printf("Total page faults:\t%d\n", pagefault);
	printf("Total writes to disk:\t%d\n", writedisk);
	printf("Total size of page table:\t%d bytes\n", numframes*256);
	return 0;
}

// opt algorithm
int opt() {
//	printf("OPT ALGORITHM\n");
	return 0;
}

// clock algorithm
int clock() {
//	printf("CLOCK ALGORITHM\n");
	return 0;
}

// lru algorithm
int lru() {
//	printf("LRU ALGORITHM");
	return 0;
}

// nfu algorithm
int nfu() {
//	printf("NFU ALGORITHM\n");
	return 0;
}



int main(int argc, char *argv[]) {
	// command line arguments
	char *argframes = argv[2];
	int numframes = atoi(argframes);
	char *chosenalg = argv[4];
	char *tracefile = argv[5];

	char frames[numframes];
	int frametable[256];	//8kb table in 32bit address space
	int f;
	int start;
	int curr;
	int offset;
	int pagefault = 0;
	int freeframe = -1;

	int memaccess = 0;
	int writedisk = 0;

	int i = 0;

	int pagetable[256];
	for (i=0; i<256; i++) {
		pagetable[i]=-1;
		frametable[i]=-1;
	}

	FILE *fp;
	char *line = NULL;
	size_t len = 0;
	ssize_t read;
	char type;
	u_int32_t address;
	int size;

	fp = fopen(tracefile, "r");
	if (fp == NULL) {
		printf("TRACE FILE NOT FOUND!\n");
		return 1;
	}

	while ((read=getline(&line,&len,fp))!=-1) {
		if (line[0]!='=' && line[0]!='-') {	// skip comment from trace file
//			printf("%s", line);
			sscanf(line,"%c %d,%d",&type,&address,&size);
			if (type != 'I') {
				// instructions were L, S or M
				sscanf(line, " %c %d,%d",&type,&address,&size);
			}
//			printf("%c %x %d\n", type,address,size);
			if (strcmp(chosenalg, "opt")==0) {
				opt();
			} else if (strcmp(chosenalg, "clock")==0) {
				clock();
			} else if (strcmp(chosenalg, "lru")==0) {
				lru();
			} else if (strcmp(chosenalg, "nfu")==0) {
				nfu();
			} else {
				printf("INVALID ALGORITHM\n");
				return 1;
			}


		}
	}

//	for (i=0; i<50; i++) {
//		fscanf(fp, " %c %d,%d", &type, &address, &size);
//		printf("%c %d %d\n", type, address, size);
//	}
	fclose(fp);

	return 0;
}
