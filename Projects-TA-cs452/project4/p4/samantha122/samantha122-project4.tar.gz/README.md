Project 4 Virtual Memory Simulation

Language: Python 
Version: 3.9

Commandline: 

	python3 ./vmsim.py –n <numframes> -a <opt|clock|lru|nfu> <tracefile>