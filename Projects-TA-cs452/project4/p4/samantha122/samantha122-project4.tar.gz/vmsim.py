"""
Author: Samantha Mathis
Class: CSC 452
PURPOSE: This file acts as a virtual memory simulator. It takes in arguments from the commandline
in the format: vmsim –n <numframes> -a <opt|clock|lru|nfu> <tracefile>

It then enacts one of the four algorithms, and produces a summary of the statistics including
the algorithm, the number of memory accesses, page faults, writes to disk and total table size.  
"""

import sys

PAGE_TABLE = []
RAM = []
NUM_FRAMES = 0
MEMORY_ACCESSES = 0
PAGE_FAULTS = 0
WRITES_TO_DISK = 0
SIZE_TABLE = (2 ** 19) * 4
DISK = []
CLOCK_INDEX = -1


class PageTableEntry:
    """
    This class creates a page table entry that keeps track of the frame num, page num 
    as well as if the PTE is in RAM
    """
    def __init__(self, in_frame, frame_num, page_num):
        self.in_frame = in_frame
        self.frame_num = frame_num
        self.page_num = page_num


class RAMFrame:
    """
    This class creates a RAMFrame which is an object that is stored in RAM 
    that keeps track of the start address, if the frame is dirty, how times it has been accessed, 
    when it was last accessed and the page table entry.
    """
    def __init__(self, start_address, dirty, num_access, last_access, page):
        self.start_address = start_address
        self.dirty = dirty
        self.num_access = num_access
        self.last_access = last_access
        self.page = page


def convert_bits_to_int(bits):
    """
    This function converts binary to decimal
    bits: which the binary number we are converting
    returns
        the integer conversion
    """
    result = 0
    for i in bits:
        result = result * 2 + int(i)
    return result
        
def convert_hex_to_bits(hex):
    """
    This function converts hexadecimal to binary
    hex: which the hexadecimal number we are converting
    returns
        the binary conversion
    """
    bit_string = ""
    for elem in hex.upper():
        if elem == "0":
            bit_string += "0000"
        elif elem == "1":
            bit_string += "0001"
        elif elem == "2":
            bit_string += "0010"
        elif elem == "3":
            bit_string += "0011"
        elif elem == "4":
            bit_string += "0100"
        elif elem == "5":
            bit_string += "0101"
        elif elem == "6":
            bit_string += "0110"
        elif elem == "7":
            bit_string += "0111"
        elif elem == "8":
            bit_string += "1000"
        elif elem == "9":
            bit_string += "1001"
        elif elem == "A":
            bit_string += "1010"
        elif elem == "B":
            bit_string += "1011"
        elif elem == "C":
            bit_string += "1100"
        elif elem == "D":
            bit_string += "1101"
        elif elem == "E":
            bit_string += "1110"
        elif elem == "F":
            bit_string += "1111"
    return bit_string
        


def preprocessing(file_contents):
    """
    This function creates a dictionary that keeps track of the positions 
    for each virtual address for each instruction from the file
    file_contents: which is the contents from the trace file 
    returns:
        the dicitonary which maps pageNumInt to a dictionary that maps positions to a list
        of positions as well as the current index.
    """
    positions = {}
    for i in range(len(file_contents)):
        if (file_contents[i].startswith("=") or file_contents[i].startswith("-")):
            continue
        line = file_contents[i].split()
        line[1] = line[1].split(",")[0]
        #converts the virutal address from the trace file to binary
        bit_string = convert_hex_to_bits(line[1])
        #takes the first 19 bits which is the virtual address
        pageNumber = bit_string[0: 19]
        #converts the page number to an integer
        pageNumInt = convert_bits_to_int(pageNumber)
        #loads the dictionary
        if pageNumInt not in positions:
            positions[pageNumInt] = {"positions": [], "current_index":0}
        positions[pageNumInt]["positions"].append(i)
    return positions

def read_file(tracefile):
    """
    This function reads in the tracefile
    tracefile: the name of the file from the command line that holds 
    the information about the instructions
    returns:
        the list containing each line as an element in the file
    """
    file = open(tracefile, "r")
    file_contents = file.readlines()
    return file_contents

def opt_algo(positions, instruction_index):
    """
    This function implements the Opt algoritm, predicting the future of the frame that will be used last
    positions: the dicitionary created in the preprocessing function which stores the indexes of the page numbers
    instruction_index: the index in the file that we are current trying to add to RAM
    returns:
        frame, which is the frame needing to be swapped out of RAM
        index, which is the index in RAM that the frame sits in 
    """
    next_frame_position = []
    for index_frame, frame in enumerate(RAM):
        positions_list = positions[frame.page.page_num]["positions"]
        index = positions[frame.page.page_num]["current_index"]
        while index < len(positions_list) and positions_list[index] < instruction_index:
            positions[frame.page.page_num]["current_index"]+=1
            index+=1
        if index == len(positions_list):
            return frame, index_frame
        next_frame_position.append(positions_list[index])

    maxs = next_frame_position[0]
    max_index = 0
    for i in range(1, len(next_frame_position)):
        if (next_frame_position[i] > maxs):
            maxs = next_frame_position[i]
            max_index = i
    return RAM[max_index], max_index

    
def clock_algo():
    """
    This function implements the clock algorithm, loops through RAM until it reaches a frame with 0 accesses
    returns:
        frame, which is the frame needing to be swapped out of RAM
        index, which is the index in RAM that the frame sits in 
    """
    global CLOCK_INDEX
    frame_selected = 0
    index_selected = 0 
    while True:
        CLOCK_INDEX = (CLOCK_INDEX + 1) % NUM_FRAMES
        frame = RAM[CLOCK_INDEX]
        if frame.num_access == 0:
            frame_selected = frame
            index_selected = CLOCK_INDEX
            return frame_selected, index_selected
        else:
            frame.num_access = 0


def lru_algo():
    """
    This function implements the lru algorithm, which finds the least recently used
    returns:
        frame, which is the frame needing to be swapped out of RAM
        index, which is the index in RAM that the frame sits in 
    """
    least = RAM[0].last_access
    least_RAM = RAM[0]
    index_element = 0
    for index in range(1,len(RAM)):
        if RAM[index].last_access < least:
            least = RAM[index].last_access
            least_RAM = RAM[index]
            index_element = index
    return least_RAM, index_element

def nfu_algo():
    """
    This function implements the nfu algorithm, which finds the not frequently used 
    returns:
        frame, which is the frame needing to be swapped out of RAM
        index, which is the index in RAM that the frame sits in 
    """
    least = RAM[0].num_access
    least_RAM = RAM[0]
    index_element = 0
    for index in range(1, len(RAM)):
        if RAM[index].num_access < least:
            least = RAM[index].num_access
            least_RAM = RAM[index]
            index_element = index
    return least_RAM, index_element

def parse_tracefile(tracefile, algo):
    """
    This function parses through the tracefile, and keeps track of the statistics from using each algorithm
    tracefile: which is the name of the file, needing to be read
    algo: which is which algorithm we are implementing
    """
    global MEMORY_ACCESSES, WRITES_TO_DISK, PAGE_FAULTS, DISK
    file_contents = read_file(tracefile)
    positions = preprocessing(file_contents)
    for index_file in range(len(file_contents)):
        if not (file_contents[index_file].startswith("=") or file_contents[index_file].startswith("-")):
            line = file_contents[index_file].split()
            line[1] = line[1].split(",")[0]

            #M instruction counts as 2 memory accesses for an S and an L
            if line[0] == "M":
                MEMORY_ACCESSES+=2
            else:
                MEMORY_ACCESSES+=1

            # Compute the page that the address is in.
            bit_string = convert_hex_to_bits(line[1])
            pageNumber = bit_string[0: 19]
            offset = bit_string[19:]

            # Convert the page and offset bits to integer.
            pageNumInt = convert_bits_to_int(pageNumber)
            offsetInt = convert_bits_to_int(offset)

            # With the page number check which frame that page is in.
            pageindex = pageNumInt % 2 ** 19
            page = PAGE_TABLE[pageindex]

            # If the page has a frame in RAM then it is a hit
            if page.in_frame == True:
                RAM[page.frame_num].last_access = index_file
                RAM[page.frame_num].num_access += 1
                #update frame to be dirty if the instruction is M or S
                if (line[0] == "S" or line[0] == "M"):
                    RAM[page.frame_num].dirty = True
            # Page Fault occurred
            else:
                page.in_frame = True
                PAGE_FAULTS+=1
                # Checks if there is an empty spot in RAM for the frame
                # which is a no eviction page fault
                if len(RAM) < NUM_FRAMES:
                    page.frame_num = len(RAM)
                    #create new RAM obj as a dirty frame and append to RAM
                    frame_ram = RAMFrame(pageNumInt, True, 1, index_file, page)
                    RAM.append(frame_ram)
                # Needs to implement an aglorithm to swap out a frame from RAM
                else:
                    if algo == "opt":
                        frame, index = opt_algo(positions, index_file)
                    elif algo == "clock":
                        frame, index = clock_algo()
                    elif algo == "lru":
                        frame, index= lru_algo()
                    elif algo == "nfu":
                        frame, index = nfu_algo()

                    page.frame_num = index
                    # Mark old PTE as no longer being in frame.
                    frame.page.in_frame = False
                    frame.page.frame_num = -1
                    if frame.dirty is True:
                        WRITES_TO_DISK+=1
                        if frame.page not in DISK:
                            DISK.append(frame.page)
                    #replace frame in RAM with page
                    RAM[index] = RAMFrame(frame.start_address, False, 1, index_file, page)
                    if page not in DISK:
                        RAM[index].dirty = True

                    if (line[0] == "S" or line[0] == "M"):
                        RAM[index].dirty = True

def print_results(algo):
    """
    This function prints the statistics from the implementing the 
    specified algorithm 
    algo: the name of specified algorithm 
    """
    print("Algorithm: ", algo)
    print("Number of frames: ", NUM_FRAMES)
    print("Total memory accesses: ", MEMORY_ACCESSES)
    print("Total page faults: ", PAGE_FAULTS)
    print("Total writes to disk: ", WRITES_TO_DISK)
    print("Total size of page table: ", SIZE_TABLE, "bytes")

def main():
    if (len(sys.argv) == 6):
        global NUM_FRAMES
        NUM_FRAMES = int(sys.argv[2])
        algo = sys.argv[4]
        tracefile = sys.argv[5]
    else:
        return "Not enough arguments"

    # Initialize Page Table with Page Table Entries
    for i in range(0, 2 ** 19):
        PAGE_TABLE.append(PageTableEntry(False, -1, i))

    parse_tracefile(tracefile, algo)
    print_results(algo)


main()