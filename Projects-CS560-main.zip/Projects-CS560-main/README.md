# Projects-CS560


## Minibase Components


![Minibase](image.png)
